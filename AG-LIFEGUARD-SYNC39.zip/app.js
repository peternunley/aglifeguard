// src/main.jsx
import React2 from "react";
import { createRoot } from "react-dom/client";

// src/App.jsx
import React, { useState, useMemo, useRef, useEffect } from "react";
import { Check, Eye, X, Users, Clock, Search, Trash2, ChevronDown, Loader2, UserPlus, Cloud, CloudOff, Printer, Download, ArrowRightLeft, LayoutGrid, AlertCircle, Settings, Lock, Unlock, Plus, Calendar, ChevronLeft, ChevronRight, Pencil, Waves, Timer, Play, RotateCcw, LifeBuoy, Coffee, Sun, Moon, ClipboardCheck } from "lucide-react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { createClient } from "@supabase/supabase-js";
var h = React.createElement;
var SB_URL = "https://vjmawnmopndlrmruchhs.supabase.co";
var SB_ANON_KEY = "sb_publishable_dz4NIUQxtOROwgc0Hkrxhw_C4sLUn1v";
var supa = createClient(SB_URL, SB_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
    storage: (typeof window !== "undefined" && window.localStorage) ? window.localStorage : void 0,
    // supabase-js uses navigator.locks to coordinate token refresh. On mobile
    // Safari that lock can hang forever, freezing getSession(). This no-op lock
    // just runs the function immediately without waiting on a global lock.
    lock: async (_name, _acquireTimeout, fn) => fn()
  }
});
// One-time cleanup: older versions stored role/PIN/identity in localStorage.
// Those are no longer trusted (auth is server-side now) — wipe any leftovers.
try {
  ["sb_pin", "ag_entry_ok", "ag_role", "ag_inst_name", "ag_user_id", "sb_url", "sb_key"].forEach((k) => localStorage.removeItem(k));
} catch {}
// ---- Auth + data layer (server-enforced via RLS) ----
async function authSignIn(email, password) {
  const { data, error } = await supa.auth.signInWithPassword({ email: String(email || "").trim(), password: String(password || "") });
  if (error) throw error;
  return data;
}
async function authSignOut() {
  try { await supa.auth.signOut(); } catch {}
  // Clear the offline PII cache so student names/guardians/ages/balances do not
  // linger in localStorage on a shared or lost device after sign-out.
  try { localStorage.removeItem("roster_cache"); } catch {}
  // Also drop any queued owner payload — it holds the full roster PII too. RLS is
  // server-side, so discarding an unflushed edit on explicit sign-out is safe (the
  // beforeunload warning already prompts the owner before they leave unsynced).
  try { localStorage.removeItem("roster_pending"); } catch {}
}
async function getMyProfile() {
  const { data: u } = await supa.auth.getUser();
  if (!u || !u.user) return null;
  const { data, error } = await supa.from("profiles").select("id,username,role,active").eq("id", u.user.id).maybeSingle();
  if (error) return { id: u.user.id, username: (u.user.email || "").split("@")[0], role: "instructor", active: true };
  return data || { id: u.user.id, username: (u.user.email || "").split("@")[0], role: "instructor", active: true };
}
async function loadAllProfiles() {
  const { data, error } = await supa.from("profiles").select("id,username,role,active,created_at").order("username", { ascending: true });
  if (error) throw error;
  if (!Array.isArray(data)) return [];
  // Dedupe by id: a single profile row must never appear twice (guards against
  // any duplicate the query could return). Same-username rows with different
  // ids are intentionally KEPT so the owner can see and remove them.
  const byId = new Map();
  for (const row of data) {
    if (row && row.id && !byId.has(row.id)) byId.set(row.id, row);
  }
  return [...byId.values()];
}
// Map a raw account-op error to a short, friendly, user-facing message. Used by
// rename / disable / delete so failures are never confusing or swallowed.
function friendlyAccountError(e) {
  const msg = String(e && e.message || e || "Something went wrong.");
  if (/timed out|didn't respond|too long/i.test(msg)) return msg;
  if (/owner permissions|is_owner/i.test(msg)) return msg;
  if (/cannot delete your own|own account|self/i.test(msg)) return "You can't delete your own account.";
  if (/network|fetch|failed to fetch/i.test(msg)) return "Network problem — please check your connection and try again.";
  return msg;
}
async function ownerSetProfileActive(id, active) {
  const { error } = await withTimeout(
    supa.from("profiles").update({ active: !!active }).eq("id", id),
    ACCOUNT_OP_TIMEOUT_MS,
    "Updating the account took too long — please check your connection and try again."
  );
  if (error) throw error;
}
async function ownerRenameProfile(id, username) {
  const { data, error } = await withTimeout(
    supa.from("profiles").update({ username: String(username || "").trim() }).eq("id", id).select("id"),
    ACCOUNT_OP_TIMEOUT_MS,
    "Renaming the account took too long — please check your connection and try again."
  );
  if (error) throw error;
  if (!data || data.length === 0) throw new Error("The rename was blocked. Your account may not have owner permissions in the database (is_owner returned false).");
}
// Owner creates an instructor login without leaving the app.
// Delegates to the owner-gated `create-instructor` Edge Function, which runs
// server-side with the service_role key. Public signup stays OFF, so the
// browser can no longer self-register accounts.
// Create an instructor/owner account. PRIMARY path is fully client-side and
// needs NO Edge Function: a throwaway Supabase client calls auth.signUp (so the
// owner's own session is never touched), then the owner's client inserts the
// matching profile row. This removes the long-broken Edge Function from the
// critical path. If signUp is disabled on the project (public signups off), we
// fall back to the owner-gated `create-instructor` Edge Function.
//
// Requirements for the client-side path to fully succeed:
//   • Auth → "Allow new users to sign up" = ON (lets signUp create the user).
//   • Auth → "Confirm email" = OFF (so the account is usable immediately).
//   • profiles RLS: the owner may INSERT a row (policy below if missing).
// Each of these, if not met, surfaces a precise message instead of a vague one.
async function ownerCreateInstructor(username, email, password, role) {
  const nm = String(username || "").trim();
  const em = String(email || "").trim();
  const pw = String(password || "");
  const rl = role === "owner" ? "owner" : "instructor";

  // Throwaway client: does NOT persist a session, so signing up here does not
  // replace the owner's logged-in session in this tab.
  let signupClient;
  try {
    signupClient = createClient(SB_URL, SB_ANON_KEY, {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false, storage: void 0, lock: async (_n, _t, fn) => fn() }
    });
  } catch (e) {
    signupClient = null;
  }

  if (signupClient) {
    const signUpRun = signupClient.auth.signUp({
      email: em,
      password: pw,
      options: { data: { username: nm, role: rl } }
    });
    const { data, error } = await Promise.race([
      signUpRun,
      new Promise((_, reject) => setTimeout(() => reject(new Error("Sign-up timed out — check your connection and try again.")), ACCOUNT_OP_TIMEOUT_MS))
    ]);

    if (!error) {
      const newId = data && data.user && data.user.id;
      if (!newId) {
        // signUp succeeded but returned no user — almost always because email
        // confirmation is ON and the user must confirm before the row exists.
        throw new Error("Account started, but email confirmation is ON in Supabase, so it isn't usable yet. Turn OFF Auth → Confirm email, then create it again.");
      }
      // Insert the profile row with the OWNER's client (RLS must allow owner
      // inserts). upsert so a DB trigger that already created the row is fine.
      const { error: pErr } = await supa.from("profiles")
        .upsert({ id: newId, username: nm, role: rl, active: true }, { onConflict: "id" });
      if (pErr) {
        const m = String(pErr.message || pErr);
        if (/row-level security|permission denied|violates/i.test(m)) {
          throw new Error("User was created, but saving their profile was blocked by a database policy. Run the one-line profiles INSERT policy, then it'll work.");
        }
        throw new Error("User created, but couldn't save their profile: " + m);
      }
      try { await signupClient.auth.signOut(); } catch {}
      return { id: newId };
    }

    // signUp errored. If it's specifically "signups disabled", fall through to
    // the Edge Function. Anything else (e.g. email already registered) is real.
    const sm = String(error.message || error);
    if (!/signups? not allowed|signup is disabled|disabled/i.test(sm)) {
      if (/already registered|already been|already exists/i.test(sm)) {
        throw new Error("That email already has an account.");
      }
      throw new Error(sm);
    }
    // else: fall through to Edge Function fallback below.
  }

  // ── Fallback: owner-gated Edge Function (only reached if client signUp is
  // disabled on the project). ─────────────────────────────────────────────
  const call = supa.functions.invoke("create-instructor", {
    body: { username: nm, email: em, password: pw, role: rl }
  });
  const { data, error } = await Promise.race([
    call,
    new Promise((_, reject) => setTimeout(() => reject(new Error("Public signups are off AND the create-instructor Edge Function didn't respond. Either turn ON Auth → Allow new users to sign up, or deploy the function with Verify JWT off.")), ACCOUNT_OP_TIMEOUT_MS))
  ]);
  if (error) {
    let msg = (error && error.message) || "Could not create the account.";
    let status = error && (error.status || (error.context && error.context.status));
    try {
      const ctx = error && error.context;
      if (ctx && typeof ctx.json === "function") {
        const j = await ctx.json();
        if (j && j.error) msg = j.error;
      }
    } catch {}
    if (status) msg = msg + " (HTTP " + status + ")";
    throw new Error(msg);
  }
  if (data && data.error) throw new Error(data.error);
  return data;
}
// Owner permanently deletes an account via the same owner-gated Edge Function.
// Deleting the auth user cascades to their profile + instructor_writes rows.
// Mirrors ownerCreateInstructor's invoke + error-surfacing pattern.
async function ownerDeleteAccount(userId) {
  const { data, error } = await withTimeout(
    supa.functions.invoke("create-instructor", { body: { action: "delete", userId } }),
    ACCOUNT_OP_TIMEOUT_MS,
    "The account service didn't respond — make sure the Edge Function is deployed, then try again."
  );
  if (error) {
    // FunctionsHttpError carries the server's Response; surface its {error} text.
    let msg = (error && error.message) || "Could not delete the account.";
    try {
      const ctx = error && error.context;
      if (ctx && typeof ctx.json === "function") {
        const j = await ctx.json();
        if (j && j.error) msg = j.error;
      }
    } catch {}
    throw new Error(msg);
  }
  if (data && data.error) throw new Error(data.error);
  return data;
}
// --- Scan roster (photo -> students) -------------------------------------
// Owner takes/picks photos of printed class rosters; each photo is one class.
// We downscale client-side, then the owner-gated `scan-roster` Edge Function
// asks Gemini Vision to read it and return { level, time, students }.
var SCAN_MAX_EDGE = 1600;          // longest side after downscale, px
var SCAN_JPEG_QUALITY = 0.8;       // JPEG quality for the upload
var SCAN_THROTTLE_MS = 4500;       // delay between photos (Gemini free tier ~15/min)
// Read a File into a downscaled JPEG; resolves { base64, mimeType }.
// base64 has the `data:...;base64,` prefix stripped so the body stays small.
function downscaleImageFile(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const w = img.naturalWidth || img.width;
        const h = img.naturalHeight || img.height;
        if (!w || !h) { URL.revokeObjectURL(url); reject(new Error("Empty image.")); return; }
        const scale = Math.min(1, SCAN_MAX_EDGE / Math.max(w, h));
        const cw = Math.max(1, Math.round(w * scale));
        const ch = Math.max(1, Math.round(h * scale));
        const canvas = document.createElement("canvas");
        canvas.width = cw;
        canvas.height = ch;
        const ctx = canvas.getContext("2d");
        if (!ctx) { URL.revokeObjectURL(url); reject(new Error("Canvas unsupported.")); return; }
        ctx.drawImage(img, 0, 0, cw, ch);
        const dataUrl = canvas.toDataURL("image/jpeg", SCAN_JPEG_QUALITY);
        URL.revokeObjectURL(url);
        const comma = dataUrl.indexOf(",");
        const base64 = comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
        if (!base64) { reject(new Error("Couldn't encode image.")); return; }
        resolve({ base64, mimeType: "image/jpeg" });
      } catch (e) {
        URL.revokeObjectURL(url);
        reject(e instanceof Error ? e : new Error(String(e)));
      }
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Couldn't open that image.")); };
    img.src = url;
  });
}
// Invoke the owner-gated Edge Function for one downscaled photo.
// Returns { level, time, students }. Mirrors ownerCreateInstructor's
// invoke + timeout + {error}-surfacing pattern.
async function scanRosterPhoto(imageBase64, mimeType) {
  const call = supa.functions.invoke("scan-roster", { body: { imageBase64, mimeType: mimeType || "image/jpeg" } });
  const { data, error } = await Promise.race([
    call,
    new Promise((_, reject) => setTimeout(() => reject(new Error("The scan service didn't respond — make sure scan-roster is deployed with Verify JWT off, then try again.")), 4e4))
  ]);
  if (error) {
    let msg = (error && error.message) || "Couldn't read that photo.";
    try {
      const ctx = error && error.context;
      if (ctx && typeof ctx.json === "function") {
        const j = await ctx.json();
        if (j && j.error) msg = j.error;
      }
    } catch {}
    throw new Error(msg);
  }
  if (data && data.error) throw new Error(data.error);
  return data || { level: "", time: "", students: [] };
}
// Shared timeout wrapper for every roster_data network call. A hung request
// rejects after ROSTER_TIMEOUT_MS so the sync badge falls back to "offline"
// (with auto-retry) instead of being pinned on "Saving…" indefinitely.
const ROSTER_TIMEOUT_MS = 8000;
function rosterTimeout(p, label) {
  return Promise.race([
    p,
    new Promise((_, reject) => setTimeout(
      () => reject(new Error((label || "Sync") + " timed out — check your connection.")),
      ROSTER_TIMEOUT_MS
    ))
  ]);
}
// roster_data: single owner-written blob. Any authed user can read.
async function loadRosterData() {
  const { data, error } = await supa.from("roster_data").select("data").eq("id", "current").maybeSingle();
  if (error) throw error;
  return data ? data.data : null;
}
async function saveRosterData(blob) {
  const run = supa.from("roster_data").upsert({ id: "current", data: blob, updated_at: new Date().toISOString() }, { onConflict: "id" });
  const { error } = await rosterTimeout(run, "Saving roster");
  if (error) throw error;
}
// ── Owner blob persistence ───────────────────────────────────────────────
// Single-owner model: the owner is the SOLE writer of the canonical roster
// blob, so we use plain last-write-wins instead of optimistic concurrency.
// A monotonic `rev` counter lives INSIDE the blob; every owner write bumps it.
// The poll compares revs (cheap, exact) to decide if the server is newer than
// what this device has — no timestamp string-matching, no JSON diffing. Every
// network call is wrapped in a timeout so a hung request surfaces as "offline"
// (and auto-retries) instead of pinning the badge on "Saving…" forever.
// Load the blob plus its row metadata (rev + updated_at) so callers can detect
// newer server state without re-fetching.
async function loadRosterRow() {
  const run = supa.from("roster_data").select("data,updated_at").eq("id", "current").maybeSingle();
  const { data, error } = await rosterTimeout(run, "Loading roster");
  if (error) throw error;
  const blob = data ? data.data : null;
  const rev = blob && typeof blob === "object" && Number.isFinite(blob.rev) ? blob.rev : 0;
  return { data: blob, updatedAt: data ? data.updated_at : null, rev };
}
// Last-write-wins owner save. Stamps a fresh, strictly-increasing rev onto the
// blob and upserts it. Returns the rev that was written so the caller can track
// the row version locally. The owner is the only writer, so there is no lost-
// update race to guard against — and crucially, nothing here can spin forever.
async function saveRosterBlob(blob, nextRev) {
  const stamped = { ...blob, rev: nextRev };
  // NOTE: deliberately NO .select() here. Returning the written row requires the
  // SELECT/read-back RLS policy to pass on the representation, which can make a
  // successful write surface as an error. The write only needs INSERT/UPDATE
  // permission; we already know the rev we wrote, so we just return it.
  const run = supa.from("roster_data")
    .upsert({ id: "current", data: stamped, updated_at: new Date().toISOString() }, { onConflict: "id" });
  const { error } = await rosterTimeout(run, "Saving roster");
  if (error) throw error;
  return nextRev;
}
// instructor_writes: per-user attendance + requests. Owner reads all.
async function loadInstructorWrites() {
  const run = supa.from("instructor_writes").select("user_id,attendance,requests,shifts");
  const { data, error } = await rosterTimeout(run, "Loading attendance");
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}
async function saveMyInstructorWrites(userId, attendance, requests) {
  const run = supa.from("instructor_writes").upsert({ user_id: userId, attendance, requests, updated_at: new Date().toISOString() }, { onConflict: "user_id" });
  const { error } = await rosterTimeout(run, "Saving attendance");
  if (error) throw error;
}
// ── Time clock ───────────────────────────────────────────────────────────
// Punches live in a `shifts` jsonb column on the SAME per-user row, so they
// reuse the proven sync channel: each person writes only their own row (RLS),
// the owner reads everyone via loadInstructorWrites, and the 15s poll carries
// updates to every device. Punches write IMMEDIATELY (no debounce) — a time
// clock must confirm on the spot. Note the payload names ONLY the shifts
// column: Postgres upsert updates just the provided columns, so a punch can
// never clobber the row's attendance or requests (and vice versa).
async function saveMyShifts(userId, shifts) {
  const run = supa.from("instructor_writes").upsert({ user_id: userId, shifts, updated_at: new Date().toISOString() }, { onConflict: "user_id" });
  const { error } = await rosterTimeout(run, "Saving the time clock");
  if (error) throw error;
}
// ── End-of-season export ─────────────────────────────────────────────────
// One tap packages the whole summer: a printable HTML report (rosters,
// attendance rates, staff hours) plus the raw JSON for safekeeping. Pure
// function so it's testable; escaping mirrors the print sheet's rules.
function buildSeasonExport({ weeks, freeSwim, switchRequests, accounts, staff, instrRows }) {
  const esc = (v) => String(v ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const wkKeys = Object.keys(weeks || {}).sort();
  const rows = Array.isArray(instrRows) ? instrRows : [];
  const nameOf = (uid) => {
    const a = (accounts || []).find((x) => x.id === uid);
    if (a && a.name) return a.name;
    const r = rows.find((x) => x && x.user_id === uid);
    const t = r && r.attendance && typeof r.attendance.__name === "string" ? r.attendance.__name.trim() : "";
    return t || "Staff";
  };
  let students = 0;
  const weekSections = wkKeys.map((wk) => {
    const w = weeks[wk] || {};
    const roster = Array.isArray(w.roster) ? w.roster : [];
    students += roster.length;
    const att = w.attendance && typeof w.attendance === "object" ? w.attendance : {};
    const days = Object.keys(att).sort();
    const lines = roster.map((s) => {
      let present = 0, marked = 0;
      days.forEach((d) => {
        const m = att[d] && att[d][s.id];
        if (m === true || m === false) { marked++; if (m === true) present++; }
      });
      const rate = marked ? Math.round(present / marked * 100) + "%" : "\u2014";
      return `<tr><td>${esc(s.name)}</td><td>${esc(s.time)}</td><td>${esc(s.level)}</td><td>${present}/${marked} (${rate})</td></tr>`;
    }).join("");
    return `<h2>Week of ${esc(wk)} \u00B7 ${roster.length} swimmers</h2>
<table><tr><th>Swimmer</th><th>Time</th><th>Level</th><th>Attendance</th></tr>${lines || '<tr><td colspan="4">No swimmers</td></tr>'}</table>`;
  }).join("");
  const hoursRows = rows.map((r) => {
    const list = sanitizeShifts(r.shifts);
    if (!list.length) return "";
    const ms = list.reduce((t, s) => t + shiftMs(s, Date.now()), 0);
    return `<tr><td>${esc(nameOf(r.user_id))}</td><td>${list.length}</td><td>${(ms / 36e5).toFixed(1)} h</td></tr>`;
  }).filter(Boolean).join("");
  const decided = (switchRequests || []).filter((r) => r && r.status !== "pending").length;
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>AG Lifeguard \u2014 Season report</title>
<style>body{font-family:Georgia,serif;color:#122;max-width:760px;margin:32px auto;padding:0 18px}h1{font-size:26px}h2{font-size:17px;margin-top:26px;border-bottom:2px solid #0B3C5D;padding-bottom:4px}table{width:100%;border-collapse:collapse;font-size:13px}td,th{border:1px solid #B8C7CC;padding:5px 8px;text-align:left}th{background:#EAF1F2}@media print{body{margin:8px auto}}</style>
</head><body>
<h1>AG Lifeguard \u00B7 Season report</h1>
<p>Generated ${esc(new Date().toLocaleDateString("en-US", { timeZone: "America/Los_Angeles", dateStyle: "long" }))} \u00B7 ${wkKeys.length} weeks \u00B7 ${students} swimmer-week entries \u00B7 ${decided} requests decided</p>
${weekSections}
<h2>Staff hours (season)</h2>
<table><tr><th>Staff</th><th>Shifts</th><th>Total</th></tr>${hoursRows || '<tr><td colspan="3">No punches recorded</td></tr>'}</table>
</body></html>`;
  const json = JSON.stringify({ exportedAt: new Date().toISOString(), weeks, freeSwim, switchRequests, accounts, staff, instructorRows: rows }, null, 2);
  return { html, json };
}
function downloadText(filename, text, mime) {
  const blob = new Blob([text], { type: mime || "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
// ── Push notifications ───────────────────────────────────────────────────
// Each person enables notifications on THEIR device (iOS requires the app
// installed to the home screen). The subscription is stored per-user; a tiny
// Supabase Edge Function does the actual sending (owner's device invokes it
// when deciding a request). Everything here fails silently — notifications
// are a bonus, never a blocker.
var VAPID_PUBLIC = "BBJzr2smDqahlNb1FGD3YsiwOx-5XOB-bqiomn3U52EHNVfXCls660SJmn5Qc9D0H_yRUNRHB_hPTkZWNz3ecOI";
function pushKeyBytes(b64u) {
  const pad = "=".repeat((4 - b64u.length % 4) % 4);
  const raw = atob((b64u + pad).replace(/-/g, "+").replace(/_/g, "/"));
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}
// Owner-set kiosk PINs are stored HASHED; the kiosk function recomputes the
// same hash server-side to verify. WebCrypto is available on https + localhost.
async function hashKioskPin(userId, pin) {
  const data = new TextEncoder().encode(`agpin:${userId}:${pin}`);
  const d = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function ownerSetPin(userId, pin) {
  const pin_hash = await hashKioskPin(userId, pin);
  const run = supa.from("profiles").update({ pin_hash }).eq("id", userId).select("id");
  const { data, error } = await rosterTimeout(run, "Saving the PIN");
  if (error) throw error;
  if (!data || !data.length) throw new Error("Couldn't save the PIN (permissions).");
}
async function saveMyPushSubscription(userId, sub) {
  const j = sub.toJSON ? sub.toJSON() : sub;
  const run = supa.from("push_subscriptions").upsert(
    { user_id: userId, endpoint: j.endpoint, keys: j.keys || {}, updated_at: new Date().toISOString() },
    { onConflict: "endpoint" }
  );
  const { error } = await rosterTimeout(run, "Saving notification setup");
  if (error) throw error;
}
async function deleteMyPushSubscription(endpoint) {
  try { await supa.from("push_subscriptions").delete().eq("endpoint", endpoint); } catch {}
}
// Fire-and-forget: tell the edge function to notify one user. If the function
// isn't deployed yet, this quietly does nothing.
function sendPush(toUserId, title, body) {
  try { supa.functions.invoke("push-notify", { body: { to: toUserId, title, body } }).catch(() => {}); } catch {}
}
// ── Daily backups ────────────────────────────────────────────────────────
// The entire roster lives in ONE row; these snapshots are the undo button.
// The owner's device writes at most one per day (insert-if-absent), right
// after a successful load — so each backup is "how yesterday ended". Restores
// ride the normal save engine (markEdit + rev+1), so every device adopts the
// restored data like any other edit. A pre-restore snapshot is taken first,
// so even a restore can be undone.
async function writeDailyBackup(day, blob, meta) {
  const run = supa.from("roster_backups").upsert(
    { day, kind: "daily", data: blob, meta: meta || {} },
    { onConflict: "day,kind", ignoreDuplicates: true }
  );
  const { error } = await rosterTimeout(run, "Writing the daily backup");
  if (error) throw error;
}
async function writePreRestoreBackup(blob, meta) {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const run = supa.from("roster_backups").insert({ day: stamp, kind: "prerestore", data: blob, meta: meta || {} });
  const { error } = await rosterTimeout(run, "Saving a safety copy");
  if (error) throw error;
}
async function listRosterBackups() {
  const run = supa.from("roster_backups").select("id,day,kind,created_at,meta").order("created_at", { ascending: false });
  const { data, error } = await rosterTimeout(run, "Loading backups");
  if (error) throw error;
  return Array.isArray(data) ? data.slice(0, 60) : [];
}
async function fetchRosterBackup(id) {
  const run = supa.from("roster_backups").select("data").eq("id", id).maybeSingle();
  const { data, error } = await rosterTimeout(run, "Loading the backup");
  if (error) throw error;
  return data ? data.data : null;
}
async function pruneRosterBackups() {
  const cutoff = new Date(Date.now() - 40 * 864e5).toISOString();
  try { await supa.from("roster_backups").delete().eq("kind", "daily").lt("created_at", cutoff); } catch {}
}
// Owner fixes anyone's clock (forgot to clock out, manual entry, corrections).
// Upsert so the owner can also seed a row for someone who never punched —
// this needs the owner INSERT policy from the setup SQL.
async function ownerSetShifts(userId, shifts) {
  const run = supa.from("instructor_writes").upsert({ user_id: userId, shifts, updated_at: new Date().toISOString() }, { onConflict: "user_id" });
  const { error } = await rosterTimeout(run, "Saving the adjustment");
  if (error) throw error;
}
// Owner updates a request's status inside the requester's own row.
async function ownerSetRequestStatus(rows, reqId, status) {
  for (const row of rows) {
    const reqs = Array.isArray(row.requests) ? row.requests : [];
    if (reqs.some((r) => r && r.id === reqId)) {
      const next = reqs.map((r) => r && r.id === reqId ? { ...r, status, decidedAt: Date.now() } : r);
      const run = supa.from("instructor_writes").update({ requests: next, updated_at: new Date().toISOString() }).eq("user_id", row.user_id);
      const { error } = await rosterTimeout(run, "Saving the decision");
      if (error) throw error;
      return;
    }
  }
}
var SB = {
  get configured() {
    return true;
  },
  get theme() {
    try {
      return localStorage.getItem("ag_theme") === "dark" ? "dark" : "light";
    } catch {
      return "light";
    }
  },
  saveTheme(t) {
    try {
      if (t === "dark") localStorage.setItem("ag_theme", "dark");
      else localStorage.removeItem("ag_theme");
    } catch {
    }
  },
  // Offline cache: last good payload so the roster still shows with no signal.
  cacheData(data) {
    try {
      localStorage.setItem("roster_cache", JSON.stringify(data));
    } catch {
    }
  },
  get cachedData() {
    try {
      const raw = localStorage.getItem("roster_cache");
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }
};
async function sbLoad() {
  return await loadRosterData();
}
async function sbSave(data) {
  return await saveRosterData(data);
}
var TIME_SLOTS = ["10am", "11am", "12pm", "1pm", "2pm"];
var LEVELS = ["Level 1", "Level 2", "Level 3", "Level 4", "Level 5", "Level 6", "Diving"];
var SLOT_HOURS = { "10am": 10, "11am": 11, "12pm": 12, "1pm": 13, "2pm": 14 };
var FREE_SWIM = "Free swim";
var DAY_OVER = "Day over";
var FREE_SWIM_START_HOUR = 14;
var FREE_SWIM_START_MIN = 14 * 60;
var FREE_SWIM_END_MIN = 15 * 60 + 25;
// Minutes since midnight PST when the instructor daily self check-in opens:
// 9:55 AM, five minutes before the 10:00 shift. (9 * 60 + 55 = 595.)
var CHECK_IN_OPEN_MIN = 9 * 60 + 55;
var SWITCH_MIN = 15;
var FREE_SWIM_DURATION_MS = (FREE_SWIM_END_MIN - FREE_SWIM_START_MIN) * 6e4;
var FREE_SWIM_PERIODS = Math.ceil((FREE_SWIM_END_MIN - FREE_SWIM_START_MIN) / SWITCH_MIN);
var FREE_SWIM_STALE_MS = 3 * 36e5;
// Sync-timing constants (named for clarity; see use sites below).
var SAVE_DEBOUNCE_MS = 600;
var POLL_INTERVAL_MS = 15000;
var JUST_SAVED_GUARD_MS = 4000;
// JUST_SAVED_GUARD_MS must stay < POLL_INTERVAL_MS
var SLOT_TICK_MS = 30000;
var SUPABASE_TIMEOUT_MS = 8000;
var ACCOUNT_OP_TIMEOUT_MS = 2e4;
var ACCOUNT_REFRESH_TIMEOUT_MS = 1e4;
// Race a promise against a timeout so a hung Supabase call can't spin a button
// forever. Rejects with a friendly message after `ms`. Reused by every account
// data-layer op (rename, disable, delete, refresh).
function withTimeout(p, ms, msg) {
  return Promise.race([
    p,
    new Promise((_, reject) => setTimeout(() => reject(new Error(msg || "That took too long — please check your connection and try again.")), ms))
  ]);
}
function liveStartedAt(rawStart, nowMs) {
  if (!rawStart) return 0;
  if (nowMs - rawStart > FREE_SWIM_STALE_MS) return 0;
  return rawStart;
}
var DEFAULT_STATIONS = ["Shallow End", "Middle", "Diving / Deep End"];
var STATION_COLORS = ["#0E9F8E", "#1D7A8C", "#0B3C5D", "#7C5CFF", "#E8A02C"];
var DEFAULT_GUARDS = ["Guard 1", "Guard 2", "Guard 3", "Guard 4", "Guard 5", "Guard 6"];
function pstNowParts(now = /* @__PURE__ */ new Date()) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/Los_Angeles",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23"
  }).formatToParts(now);
  const h = Number(parts.find((p) => p.type === "hour").value);
  const m = Number(parts.find((p) => p.type === "minute").value);
  return { h, m };
}
function isFreeSwimNow(now = /* @__PURE__ */ new Date()) {
  const m = pstMinutes(now);
  return m >= FREE_SWIM_START_MIN && m < FREE_SWIM_END_MIN;
}
function pstMinutes(now = /* @__PURE__ */ new Date()) {
  const { h, m } = pstNowParts(now);
  return h * 60 + m;
}
function currentSlot(now = /* @__PURE__ */ new Date()) {
  if (isFreeSwimNow(now)) return FREE_SWIM;
  if (pstMinutes(now) >= FREE_SWIM_END_MIN) return DAY_OVER;
  const { h } = pstNowParts(now);
  if (h < 10) return TIME_SLOTS[0];
  return TIME_SLOTS.find((t) => SLOT_HOURS[t] === h) || "2pm";
}
function rotationForPeriod(guards, stations, period, blockLen = 2) {
  const S = stations.length, G = guards.length;
  if (!G || !S) return { assign: stations.map((name) => ({ station: name, guard: null })), breaks: [] };
  const len = blockLen >= 1 ? blockLen : 1;
  const block = Math.floor(period / len);
  const withinBlock = period % len;
  const onCount = Math.min(G, S);
  const benchSize = G - onCount;
  const bench = /* @__PURE__ */ new Set();
  for (let k = 0; k < benchSize; k++) bench.add((block * benchSize + k) % G);
  const onGuards = [];
  for (let i = 0; i < G; i++) if (!bench.has(i)) onGuards.push(guards[i]);
  const rot = (withinBlock + block) % onCount;
  const assign = stations.map((name, s) => {
    if (s >= onCount) return { station: name, guard: null };
    return { station: name, guard: onGuards[(s + rot) % onCount] };
  });
  const breaks = [];
  bench.forEach((i) => breaks.push(guards[i]));
  return { assign, breaks };
}
function planForPeriod(freeSwim, activeGuards, stations, period, blockLen) {
  if (freeSwim && freeSwim.mode === "manual") {
    const row = freeSwim.manual && freeSwim.manual[period] || [];
    const knownGuards = Array.isArray(freeSwim.guards) ? freeSwim.guards : [];
    const assign = stations.map((name, s) => {
      const g = row[s];
      // A manually-placed guard shows as long as they're a real guard on the
      // roster — placing someone at a station counts as putting them on duty,
      // so we don't also require the separate on-duty toggle (that mismatch made
      // manual placements silently vanish).
      const ok = g && (activeGuards.includes(g) || knownGuards.includes(g));
      return { station: name, guard: ok ? g : null };
    });
    const onSet = /* @__PURE__ */ new Set();
    assign.forEach((a) => {
      if (a.guard) onSet.add(a.guard);
    });
    const breaks = activeGuards.filter((g) => !onSet.has(g));
    return { assign, breaks };
  }
  return rotationForPeriod(activeGuards, stations, period, blockLen);
}
function buildManualFromAuto(activeGuards, stations, blockLen) {
  return Array.from({ length: FREE_SWIM_PERIODS }, (_, p) => {
    const r = rotationForPeriod(activeGuards, stations, p, blockLen);
    return r.assign.map((a) => a.guard || null);
  });
}
function freeSwimPeriodIndex(startedAt, nowMs) {
  if (!startedAt) return -1;
  const elapsed = nowMs - startedAt;
  if (elapsed < 0) return -1;
  if (elapsed >= FREE_SWIM_DURATION_MS) return FREE_SWIM_PERIODS;
  return Math.floor(elapsed / (SWITCH_MIN * 60000));
}
function fmtClock(ms) {
  const d = new Date(ms);
  let hh = d.getHours();
  const mm = String(d.getMinutes()).padStart(2, "0");
  const ap = hh >= 12 ? "pm" : "am";
  hh = hh % 12;
  if (hh === 0) hh = 12;
  return `${hh}:${mm}${ap}`;
}
function fmtCountdown(ms) {
  if (ms < 0) ms = 0;
  const total = Math.ceil(ms / 1e3);
  const m = Math.floor(total / 60);
  const s = String(total % 60).padStart(2, "0");
  return `${m}:${s}`;
}
function todayAt(hour) {
  const d = /* @__PURE__ */ new Date();
  d.setHours(hour, 0, 0, 0);
  return d.getTime();
}
function defaultFreeSwim() {
  // Neutral placeholder used only for first paint / empty-blob fallback before the
  // saved rotation loads from Supabase. Intentionally contains no real staff names
  // or day-specific schedule; the live rotation is the owner-written blob.
  return { guards: [], onDuty: [], stations: DEFAULT_STATIONS.slice(), startedAt: 0, groupMin: 30, mode: "auto", manual: [] };
}
function sanitizeFreeSwim(fs) {
  if (!fs || typeof fs !== "object") return defaultFreeSwim();
  const guards = Array.isArray(fs.guards) ? fs.guards.filter((g) => typeof g === "string") : DEFAULT_GUARDS.slice();
  const stations = Array.isArray(fs.stations) && fs.stations.length ? fs.stations.filter((s) => typeof s === "string") : DEFAULT_STATIONS.slice();
  // Keep an on-duty entry if its person is in guards. Match by NORMALIZED name
  // (case/space-insensitive) to mirror toggleOnDuty's de-dupe — exact-string
  // equality here was silently dropping on-duty people whose guards entry
  // differed in case/spacing, so "on duty today" never persisted.
  const guardKeys = new Set(guards.map((g) => normName(g)));
  const onDuty = Array.isArray(fs.onDuty)
    ? fs.onDuty.filter((g) => typeof g === "string" && guardKeys.has(normName(g)))
    : [];
  const startedAt = Number(fs.startedAt) || 0;
  const groupMin = fs.groupMin === 15 ? 15 : 30;
  const mode = fs.mode === "manual" ? "manual" : "auto";
  const manual = Array.isArray(fs.manual) ? fs.manual.map((r) => Array.isArray(r) ? r.map((v) => typeof v === "string" ? v : null) : []) : [];
  return { guards, onDuty, stations, startedAt, groupMin, mode, manual };
}
function sanitizeSwitchRequests(list) {
  if (!Array.isArray(list)) return [];
  return list.filter((r) => r && typeof r === "object" && r.id).map((r) => ({
    id: String(r.id),
    kind: r.kind === "pickup" || r.kind === "drop" || r.kind === "trade" || r.kind === "timeEdit" || r.kind === "lessonEdit" ? r.kind : "switch",
    studentId: String(r.studentId || ""),
    studentName: String(r.studentName || ""),
    // Trades carry the OTHER instructor's name; dropping it here silently broke
    // the trade feature (requestTrade/TradeModal) on every sanitize pass.
    withName: typeof r.withName === "string" ? r.withName : "",
    // timeEdit (arrival-time fix) fields — same silent-drop hazard as withName.
    shiftId: String(r.shiftId || ""),
    day: typeof r.day === "string" && /^\d{4}-\d{2}-\d{2}$/.test(r.day) ? r.day : "",
    oldIn: Number(r.oldIn) || 0,
    newIn: Number(r.newIn) || 0,
    // lessonEdit (fix the daily "which lessons" answer): comma-joined slots.
    fromSlots: String(r.fromSlots || ""),
    toSlots: String(r.toSlots || ""),
    fromTime: String(r.fromTime || ""),
    fromLevel: String(r.fromLevel || ""),
    toTime: String(r.toTime || ""),
    toLevel: String(r.toLevel || ""),
    week: String(r.week || ""),
    by: String(r.by || ""),
    byId: String(r.byId || ""),
    reason: String(r.reason || ""),
    status: r.status === "approved" || r.status === "rejected" ? r.status : "pending",
    createdAt: Number(r.createdAt) || 0,
    decidedAt: Number(r.decidedAt) || 0
  }));
}
function normName(s) {
  return String(s || "").trim().toLowerCase();
}
// First word of a name, normalized. "Jordan Lee" -> "jordan".
function firstName(s) {
  return normName(s).split(/\s+/)[0] || "";
}
// Display the first name with original capitalization. "Jordan Lee" -> "Jordan".
function firstNameCap(s) {
  return String(s || "").trim().split(/\s+/)[0] || "";
}
// Join a list of instructor names as compact first names for tight UI.
function instrFirstNames(list) {
  return (Array.isArray(list) ? list : []).map(firstNameCap).join(", ");
}
// Does a name written on a lesson refer to this account?
// Exact full-name match always wins; otherwise match on first name.
// (e.g. lesson "Jordan" links to account "Jordan Lee".)
function nameMatchesAccount(lessonName, accountName) {
  const ln = normName(lessonName), an = normName(accountName);
  if (!ln || !an) return false;
  if (ln === an) return true;
  return firstName(ln) === firstName(an) && firstName(ln) !== "";
}
function sanitizeAccounts(list) {
  if (!Array.isArray(list)) return [];
  const seen = /* @__PURE__ */ new Set();
  return list.filter((a) => a && typeof a === "object" && a.id).map((a) => ({
    id: String(a.id),
    name: String(a.name || "").trim(),
    pin: String(a.pin || "").replace(/[^0-9]/g, "").slice(0, 6),
    active: a.active === false ? false : true,
    createdAt: Number(a.createdAt) || 0
  })).filter((a) => {
    if (!a.name) return false;
    const k = normName(a.name);
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}
// ---- Staff coverage & daily attendance ----
// The synced blob gains a `staff` field: capabilities the owner sets per person,
// manually-added people who have no login, and a date-keyed ABSENT map (present =
// NOT in the map, so a fresh day key naturally shows everyone present again).
var STAFF_ROLES = ["instructor", "lifeguard", "both"];
function defaultStaff() {
  return { roles: {}, extra: [], attendance: {}, autoClockOut: "", schedule: {}, adminIds: [] };
}
function sanitizeStaff(s) {
  if (!s || typeof s !== "object") return defaultStaff();
  // Time-clock closing time ("HH:MM", empty = feature off) and the weekly
  // schedule map ({ personName: { MO: "10:00-14:00", ... } }) ride the staff
  // object so they sync like every other owner field.
  const autoClockOut = typeof s.autoClockOut === "string" && /^\d{2}:\d{2}$/.test(s.autoClockOut) ? s.autoClockOut : "";
  const schedule = {};
  if (s.schedule && typeof s.schedule === "object") {
    for (const [nm, days] of Object.entries(s.schedule)) {
      if (!nm || !days || typeof days !== "object") continue;
      const d2 = {};
      for (const dk of ["MO", "TU", "WE", "TH", "FR", "SA", "SU"]) {
        const v = days[dk];
        if (typeof v === "string" && /^\d{2}:\d{2}-\d{2}:\d{2}$/.test(v)) d2[dk] = v;
      }
      if (Object.keys(d2).length) schedule[String(nm).slice(0, 60)] = d2;
    }
  }
  const roles = {};
  if (s.roles && typeof s.roles === "object") {
    for (const [name, role] of Object.entries(s.roles)) {
      const nm = String(name || "").trim();
      if (nm && STAFF_ROLES.includes(role)) roles[nm] = role;
    }
  }
  const seen = /* @__PURE__ */ new Set();
  const extra = Array.isArray(s.extra) ? s.extra.map((e) => {
    if (!e || typeof e !== "object") return null;
    return { name: String(e.name || "").trim() };
  }).filter((e) => {
    if (!e || !e.name) return false;
    const k = normName(e.name);
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  }) : [];
  const attendance = {};
  if (s.attendance && typeof s.attendance === "object") {
    for (const [day, marks] of Object.entries(s.attendance)) {
      if (!marks || typeof marks !== "object") continue;
      const dayOut = {};
      for (const [name, absent] of Object.entries(marks)) {
        const nm = String(name || "").trim();
        if (nm && absent === true) dayOut[nm] = true;
      }
      if (Object.keys(dayOut).length) attendance[String(day)] = dayOut;
    }
  }
  // Admin user ids ride the staff object so INSTRUCTOR devices can address a
  // push at the admins (they can't read the profiles table; the synced blob is
  // their only channel). Stamped by the owner's device on load.
  const adminIds = Array.isArray(s.adminIds) ? Array.from(new Set(s.adminIds.map((v) => String(v || "").trim()).filter(Boolean))).slice(0, 20) : [];
  return { roles, extra, attendance, autoClockOut, schedule, adminIds };
}
// Find lesson names that are ambiguous: their first name matches 2+ accounts
// and the lesson name isn't an exact full-name match to any account.
// Returns [{ lessonName, matches: [accountName,...] }].
function ambiguousLessonNames(accounts, instructors) {
  if (!accounts || !instructors) return [];
  const lessonNames = new Set();
  for (const names of Object.values(instructors)) {
    if (Array.isArray(names)) names.forEach((n) => { if (n && n.trim()) lessonNames.add(n.trim()); });
  }
  const out = [];
  for (const ln of lessonNames) {
    const exact = accounts.filter((a) => normName(a.name) === normName(ln));
    if (exact.length > 0) continue; // exact match wins, not ambiguous
    const fnMatches = accounts.filter((a) => firstName(a.name) === firstName(ln) && firstName(ln) !== "");
    if (fnMatches.length > 1) out.push({ lessonName: ln, matches: fnMatches.map((a) => a.name) });
  }
  return out;
}
function lessonsForName(name, instructors, roster) {
  const target = normName(name);
  if (!target || !instructors) return [];
  const keys = [];
  for (const [k, names] of Object.entries(instructors)) {
    if (Array.isArray(names) && names.some((n) => nameMatchesAccount(n, name))) {
      if (!roster || roster.some((s) => `${s.time}|${s.level}` === k)) keys.push(k);
    }
  }
  return keys;
}
// Free-swim duty for a person, mirroring lessonsForName. Returns
// { onDuty: bool, stations: [stationName,...] } where stations are the manual
// grid cells the person is placed in (deduped, in station order). Matched via
// nameMatchesAccount so a lesson-style first-name link works the same way.
function shiftsForName(name, freeSwim) {
  const target = normName(name);
  if (!target || !freeSwim || typeof freeSwim !== "object") return { onDuty: false, stations: [] };
  const stationNames = Array.isArray(freeSwim.stations) && freeSwim.stations.length ? freeSwim.stations : DEFAULT_STATIONS;
  const onDuty = Array.isArray(freeSwim.onDuty) && freeSwim.onDuty.some((g) => nameMatchesAccount(g, name));
  const seen = /* @__PURE__ */ new Set();
  const stations = [];
  const manual = Array.isArray(freeSwim.manual) ? freeSwim.manual : [];
  manual.forEach((row) => {
    if (!Array.isArray(row)) return;
    row.forEach((cell, idx) => {
      if (cell && nameMatchesAccount(cell, name)) {
        const st = stationNames[idx] || `Station ${idx + 1}`;
        if (!seen.has(st)) { seen.add(st); stations.push(st); }
      }
    });
  });
  return { onDuty, stations };
}
// Merge per-instructor request rows (from instructor_writes) with the owner's
// canonical request list (in the blob). Owner's decided status wins.
function mergeRequests(baseReqs, instrWrites) {
  const byId = /* @__PURE__ */ new Map();
  (Array.isArray(instrWrites) ? instrWrites : []).forEach((row) => {
    (Array.isArray(row.requests) ? row.requests : []).forEach((r) => {
      if (r && r.id) byId.set(r.id, r);
    });
  });
  (Array.isArray(baseReqs) ? baseReqs : []).forEach((r) => {
    if (r && r.id) byId.set(r.id, r);
  });
  return sanitizeSwitchRequests([...byId.values()]).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}
// Reserved key inside an instructor's own instructor_writes.attendance map that
// stores their daily self-check-in: attendance.__self = { [dateKey]: "present"|"absent" }.
// It is NOT a week key — every loop over instr-write attendance must skip it.
var SELF_KEY = "__self";
// Reserved key: the instructor's display name travels WITH their row so the
// owner can name a check-in even if the profiles lookup fails or mismatches.
var NAME_KEY = "__name";
// Reserved key: the instructor's daily "which lessons do I have today" answer,
// attendance.__lessons = { [dateKey]: "10am,11am" } (comma-joined TIME_SLOTS).
// Asked with the check-in question; changes after answering go through an
// admin-approved lessonEdit request. Like __self, never a week key.
var LESSONS_KEY = "__lessons";
// Owner applies an approved lessonEdit to the requester's own row. Reads the
// freshest local copy of the row, rewrites only the __lessons day entry.
async function ownerSetDayLessons(rows, userId, day, slots) {
  const row = (Array.isArray(rows) ? rows : []).find((r) => r && r.user_id === userId);
  const att = row && row.attendance && typeof row.attendance === "object" ? row.attendance : {};
  const cur = att[LESSONS_KEY] && typeof att[LESSONS_KEY] === "object" ? att[LESSONS_KEY] : {};
  const next = { ...att, [LESSONS_KEY]: { ...cur, [day]: String(slots || "") } };
  const run = supa.from("instructor_writes").upsert({ user_id: userId, attendance: next, updated_at: new Date().toISOString() }, { onConflict: "user_id" });
  const { error } = await rosterTimeout(run, "Saving the lesson change");
  if (error) throw error;
  return next;
}
// ── Time-clock pure helpers ─────────────────────────────────────────────
// A shift is { id, in: epochMs, out: epochMs (0 = still clocked in), day:
// "YYYY-MM-DD" (PST day it belongs to) }. Sanitize hard: punches sync between
// devices, so a malformed entry must never poison anyone's math or render.
function sanitizeShifts(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const s of list) {
    if (!s || typeof s !== "object") continue;
    const id = String(s.id || "").slice(0, 48);
    const tin = Number(s.in);
    const tout = Number(s.out) || 0;
    const day = typeof s.day === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s.day) ? s.day : "";
    if (!id || seen.has(id) || !Number.isFinite(tin) || tin <= 0 || !day) continue;
    if (tout && tout <= tin) continue;
    seen.add(id);
    out.push({ id, in: tin, out: tout > 0 ? tout : 0, day, ...s.auto ? { auto: true } : {}, ...s.manual ? { manual: true } : {} });
  }
  out.sort((a, b) => a.in - b.in);
  return out.slice(-2000);
}
// Payroll rounding for CLOCK-IN times (clock-outs stay exact):
//   • 9:00-9:59 snaps to 10:00 — the pool opens at 10, so early setup counts
//     from open, whether they punch just before or just after 9.
//   • Every other hour rounds to the nearest hour with :30 as the tipping
//     point: 11:26 → 11:00, 11:30+ → 12:00.
// Uses device-local time like the rest of the punch math (pool devices run PST).
function roundClockIn(ms) {
  const d = new Date(ms);
  const h = d.getHours();
  const hour = h === 9 ? 10 : d.getMinutes() >= 30 ? h + 1 : h;
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() + hour * 36e5;
}
function shiftMs(s, nowMs) {
  const end = s.out || nowMs;
  return Math.max(0, end - s.in);
}
// ── Quick hours ──────────────────────────────────────────────────────────
// Admins mostly assign known DURATIONS (3.5h, 5.5h), not clock times. These
// helpers turn "add 3.5h to Tuesday" into a normal shift block so every
// existing view (day totals, week totals, CSV, exports) just works.
// New blocks CHAIN after that day's latest end (first one anchors at 10:00),
// and are flagged `manual` so the list shows "Quick add" instead of fake
// clock times. Subtracting trims from the day's LAST closed block backward,
// deleting blocks it fully consumes; a running (open) shift is never touched.
function quickAddBlock(list, day, ms) {
  const dayShifts = list.filter((s) => s.day === day);
  const latestOut = dayShifts.reduce((t, s) => Math.max(t, s.out || 0), 0);
  const start = latestOut > 0 ? latestOut : (dayTimeToMs(day, "10:00") || Date.now());
  return [...list, { id: `qh-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, in: start, out: start + ms, day, manual: true }];
}
function quickSubtract(list, day, ms) {
  let left = ms;
  const closed = list.filter((s) => s.day === day && s.out > 0).sort((a, b) => b.out - a.out);
  const drop = new Set();
  const trim = new Map();
  for (const s of closed) {
    if (left <= 0) break;
    const dur = s.out - s.in;
    if (dur <= left) { drop.add(s.id); left -= dur; }
    else { trim.set(s.id, s.out - left); left = 0; }
  }
  return list.filter((s) => !drop.has(s.id)).map((s) => trim.has(s.id) ? { ...s, out: trim.get(s.id) } : s);
}
function shiftsMsForDay(list, day, nowMs) {
  let t = 0;
  for (const s of list) if (s.day === day) t += shiftMs(s, nowMs);
  return t;
}
function shiftsMsForWeek(list, weekKey, nowMs) {
  const days = /* @__PURE__ */ new Set();
  for (let i = 0; i < 7; i++) days.add(shiftDateKey(weekKey, i));
  let t = 0;
  for (const s of list) if (days.has(s.day)) t += shiftMs(s, nowMs);
  return t;
}
function fmtDur(ms) {
  const mins = Math.max(0, Math.round(ms / 6e4));
  const h2 = Math.floor(mins / 60);
  const m = mins % 60;
  return h2 > 0 ? `${h2}h ${String(m).padStart(2, "0")}m` : `${m}m`;
}
function fmtPunchTime(ms) {
  return new Date(ms).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZone: "America/Los_Angeles" });
}
// Convert a day key + "HH:MM" wall-clock string to epoch ms using the DEVICE's
// timezone (the pool's devices run in PST, matching the rest of the app).
function dayTimeToMs(day, hhmm) {
  const [y, m, d] = String(day || "").split("-").map(Number);
  const [hh, mm] = String(hhmm || "").split(":").map(Number);
  if (![y, m, d, hh, mm].every(Number.isFinite)) return 0;
  return new Date(y, m - 1, d, hh, mm, 0, 0).getTime();
}
function msToDayTime(ms) {
  const d = new Date(ms);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
var LONG_SHIFT_WARN_MS = 10 * 36e5;
function mergeAttendance(weeksObj, instrWrites) {
  if (!Array.isArray(instrWrites) || !instrWrites.length) return weeksObj;
  const out = {};
  for (const [wk, w] of Object.entries(weeksObj)) {
    out[wk] = { ...w, attendance: { ...(w.attendance || {}) } };
  }
  instrWrites.forEach((row) => {
    const att = row && row.attendance && typeof row.attendance === "object" ? row.attendance : {};
    for (const [wk, days] of Object.entries(att)) {
      // SELF_KEY ("__self") holds the instructor's own daily self-check-in, not a
      // week. It must NEVER be treated as a week key or it corrupts roster weeks.
      if (typeof wk === "string" && wk.startsWith("__")) continue;
      if (!out[wk]) out[wk] = { roster: [], instructors: {}, attendance: {} };
      out[wk].attendance = { ...(out[wk].attendance || {}) };
      for (const [day, marks] of Object.entries(days || {})) {
        out[wk].attendance[day] = { ...(out[wk].attendance[day] || {}), ...(marks || {}) };
      }
    }
  });
  return out;
}
// Pull the attendance maps out of weeks for an instructor to save to their row.
// NOTE: no longer used by the instructor save path — it snapshotted EVERYONE's
// merged marks into one row, so stale copies resurrected marks the owner had
// unmarked and rows grew without bound. Kept for reference/compat; the save now
// uses filterAttendanceToLocal + attendanceFromAuthored + unionAttendance below.
function extractMyAttendance(weeks) {
  const out = {};
  for (const [wk, w] of Object.entries(weeks || {})) {
    if (w && w.attendance && Object.keys(w.attendance).length) out[wk] = w.attendance;
  }
  return out;
}
// Keep only the entries of an instructor-row attendance map that are STILL
// true in the current local weeks — an unmark seen locally (owner's or their
// own) drops out instead of being re-asserted forever.
function filterAttendanceToLocal(att, weeks) {
  const out = {};
  for (const [wk, days] of Object.entries(att || {})) {
    // Reserved "__" keys (self check-in, travelling name) are re-attached by
    // the caller — they are never week keys.
    if (typeof wk === "string" && wk.startsWith("__")) continue;
    const local = (weeks && weeks[wk] && weeks[wk].attendance) || {};
    const keepDays = {};
    for (const [day, marks] of Object.entries(days || {})) {
      const localDay = local[day] || {};
      const keep = {};
      for (const id of Object.keys(marks || {})) {
        if (marks[id] && localDay[id]) keep[id] = true;
      }
      if (Object.keys(keep).length) keepDays[day] = keep;
    }
    if (Object.keys(keepDays).length) out[wk] = keepDays;
  }
  return out;
}
// Marks this instructor authored THIS session (Set of "week|date|studentId"),
// kept only while still true locally so their own unmark wins too.
function attendanceFromAuthored(authoredSet, weeks) {
  const out = {};
  for (const key of authoredSet || []) {
    const parts = String(key).split("|");
    if (parts.length < 3) continue;
    const wk = parts[0], day = parts[1], id = parts.slice(2).join("|");
    const localDay = (weeks && weeks[wk] && weeks[wk].attendance && weeks[wk].attendance[day]) || {};
    if (!localDay[id]) continue;
    if (!out[wk]) out[wk] = {};
    if (!out[wk][day]) out[wk][day] = {};
    out[wk][day][id] = true;
  }
  return out;
}
// Union of two attendance maps (week -> day -> id -> true). Immutable.
function unionAttendance(a, b) {
  const out = {};
  for (const src of [a, b]) {
    for (const [wk, days] of Object.entries(src || {})) {
      if (!out[wk]) out[wk] = {};
      for (const [day, marks] of Object.entries(days || {})) {
        out[wk][day] = { ...(out[wk][day] || {}), ...(marks || {}) };
      }
    }
  }
  return out;
}
var CLOSED_DATES = ["2026-06-19"];
function pstDateKey(d = /* @__PURE__ */ new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Los_Angeles",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(d);
  return parts;
}
function dowForKey(key) {
  const [y, m, day] = key.split("-").map(Number);
  return new Date(y, m - 1, day).getDay();
}
function isWeekend(key) {
  const d = dowForKey(key);
  return d === 0 || d === 6;
}
function isClosed(key) {
  return isWeekend(key) || CLOSED_DATES.includes(key);
}
function prettyDate(key) {
  const [y, m, day] = key.split("-").map(Number);
  return new Date(y, m - 1, day).toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric"
  });
}
function shiftDateKey(key, n) {
  const [y, m, day] = key.split("-").map(Number);
  const d = new Date(y, m - 1, day);
  d.setDate(d.getDate() + n);
  const yy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}
function weekKeyFor(dateKey) {
  const [y, m, day] = dateKey.split("-").map(Number);
  const d = new Date(y, m - 1, day);
  const dow = d.getDay();
  const back = dow === 0 ? 6 : dow - 1;
  d.setDate(d.getDate() - back);
  const yy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}
function weekLabel(weekKey) {
  const [y, m, day] = weekKey.split("-").map(Number);
  const mon = new Date(y, m - 1, day);
  const fri = new Date(y, m - 1, day + 4);
  const md = (d) => d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  return `${md(mon)} \u2013 ${md(fri)}`;
}
// weekLabel plus weekday names ("Mon Jul 6 \u2013 Fri Jul 10") for the scan-import
// destination, where "which week is this?" is the whole point.
function weekLabelWithDays(weekKey) {
  const [y, m, day] = weekKey.split("-").map(Number);
  const mon = new Date(y, m - 1, day);
  const fri = new Date(y, m - 1, day + 4);
  const wmd = (d) => d.toLocaleDateString("en-US", { weekday: "short" }) + " " + d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  return `${wmd(mon)} \u2013 ${wmd(fri)}`;
}
function weekdaysOf(weekKey) {
  return [0, 1, 2, 3, 4].map((n) => shiftDateKey(weekKey, n));
}
var LEVEL_COLORS = {
  "Level 1": "#2DD4BF",
  "Level 2": "#1D7A8C",
  "Level 3": "#0B3C5D",
  "Level 4": "#7C5CFF",
  "Level 4B": "#9B7DFF",
  "Level 5": "#FF6B5C",
  "Level 6": "#E8A02C",
  "Diving": "#0891B2"
};
// --- Dark-mode color legibility (Part 4) ---
// Some level/station hues (deep navy #0B3C5D, dark teal #1D7A8C) are nearly
// invisible as text/dots/borders on the dark navy surface. These helpers lift
// such colors toward the light in dark mode while keeping the hue, and return
// the original color untouched in light mode. Pure: read DOM at render time.
function isDarkTheme() {
  try {
    return document.documentElement.getAttribute("data-theme") === "dark";
  } catch {
    return false;
  }
}
function hexToRgb(hex) {
  let s = String(hex || "").trim().replace("#", "");
  if (s.length === 3) s = s.split("").map((c) => c + c).join("");
  if (s.length !== 6) return null;
  const n = parseInt(s, 16);
  if (Number.isNaN(n)) return null;
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}
function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let hVal = 0, sVal = 0;
  const lVal = (max + min) / 2;
  const d = max - min;
  if (d !== 0) {
    sVal = lVal > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) hVal = (g - b) / d + (g < b ? 6 : 0);
    else if (max === g) hVal = (b - r) / d + 2;
    else hVal = (r - g) / d + 4;
    hVal /= 6;
  }
  return { h: hVal, s: sVal, l: lVal };
}
function hslToHex(h, s, l) {
  let r, g, b;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p2, q2, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p2 + (q2 - p2) * 6 * t;
      if (t < 1 / 2) return q2;
      if (t < 2 / 3) return p2 + (q2 - p2) * (2 / 3 - t) * 6;
      return p2;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  const to2 = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, "0");
  return `#${to2(r)}${to2(g)}${to2(b)}`;
}
// Lift lightness ~+34% (clamped) and add a touch of saturation so the hue stays
// recognizable but reads clearly on a dark surface. Only the darker hues need it,
// but applying uniformly is safe — already-bright colors only nudge slightly.
function brightenForDark(hex) {
  const rgb = hexToRgb(hex);
  if (!rgb) return hex;
  const { h, s, l } = rgbToHsl(rgb.r, rgb.g, rgb.b);
  const newL = Math.min(0.72, l + 0.34);
  const newS = Math.min(1, s * 1.05 + 0.05);
  return hslToHex(h, newS, newL);
}
// Use these at color-as-content sites (text / dot / border / chip). They no-op
// in light mode so the light theme is pixel-identical.
function levelColor(level, dark) {
  const base = LEVEL_COLORS[level] || "#1D7A8C";
  return (dark == null ? isDarkTheme() : dark) ? brightenForDark(base) : base;
}
function stationColor(index, dark) {
  const base = STATION_COLORS[index % STATION_COLORS.length];
  return (dark == null ? isDarkTheme() : dark) ? brightenForDark(base) : base;
}
// Brighten any standalone hue (e.g. the hardcoded on-duty teal) for dark mode.
function legibleColor(hex, dark) {
  return (dark == null ? isDarkTheme() : dark) ? brightenForDark(hex) : hex;
}
var seedStudents = () => [
  { id: "p001", name: "Swimmer 1", guardian: "", age: 4, level: "Level 3", time: "10am", balance: 0, present: false, note: "" },
  { id: "p002", name: "Swimmer 2", guardian: "", age: 6, level: "Level 2", time: "11am", balance: 0, present: false, note: "" },
  { id: "p003", name: "Swimmer 3", guardian: "", age: 7, level: "Level 3", time: "11am", balance: 0, present: false, note: "" },
  { id: "p004", name: "Swimmer 4", guardian: "", age: 7, level: "Level 3", time: "11am", balance: 0, present: false, note: "" },
  { id: "p005", name: "Swimmer 5", guardian: "", age: 10, level: "Level 4", time: "11am", balance: 0, present: false, note: "" },
  { id: "p006", name: "Swimmer 6", guardian: "", age: 8, level: "Level 4", time: "11am", balance: 0, present: false, note: "" },
  { id: "p007", name: "Swimmer 7", guardian: "", age: 7, level: "Level 1", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p008", name: "Swimmer 8", guardian: "", age: 5, level: "Level 2", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p009", name: "Swimmer 9", guardian: "", age: 5, level: "Level 2", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p010", name: "Swimmer 10", guardian: "", age: 6, level: "Level 3", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p011", name: "Swimmer 11", guardian: "", age: 7, level: "Level 3", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p012", name: "Swimmer 12", guardian: "", age: 7, level: "Level 3", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p013", name: "Swimmer 13", guardian: "", age: 9, level: "Level 3", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p014", name: "Swimmer 14", guardian: "", age: 7, level: "Level 3", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p015", name: "Swimmer 15", guardian: "", age: 8, level: "Level 3", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p016", name: "Swimmer 16", guardian: "", age: 9, level: "Level 4", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p017", name: "Swimmer 17", guardian: "", age: 9, level: "Level 4", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p018", name: "Swimmer 18", guardian: "", age: 10, level: "Level 4", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p019", name: "Swimmer 19", guardian: "", age: 11, level: "Level 4", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p020", name: "Swimmer 20", guardian: "", age: 11, level: "Level 6", time: "12pm", balance: 0, present: false, note: "" },
  { id: "p021", name: "Swimmer 21", guardian: "", age: 10, level: "Level 4", time: "1pm", balance: 0, present: false, note: "" },
  { id: "p022", name: "Swimmer 22", guardian: "", age: 10, level: "Level 4", time: "1pm", balance: 0, present: false, note: "" },
  { id: "p023", name: "Swimmer 23", guardian: "", age: 6, level: "Level 4", time: "2pm", balance: 0, present: false, note: "" },
  { id: "p024", name: "Swimmer 24", guardian: "", age: 8, level: "Level 4", time: "2pm", balance: 0, present: false, note: "" },
  { id: "p025", name: "Swimmer 25", guardian: "", age: 7, level: "Level 4", time: "2pm", balance: 0, present: false, note: "" },
  { id: "p026", name: "Swimmer 26", guardian: "", age: 9, level: "Level 4", time: "2pm", balance: 0, present: false, note: "" },
  { id: "p027", name: "Swimmer 27", guardian: "", age: 9, level: "Level 4", time: "2pm", balance: 0, present: false, note: "" },
  { id: "p028", name: "Swimmer 28", guardian: "", age: 11, level: "Level 5", time: "2pm", balance: 0, present: false, note: "" },
  { id: "p029", name: "Swimmer 29", guardian: "", age: 11, level: "Level 5", time: "2pm", balance: 0, present: false, note: "" },
  { id: "p030", name: "Swimmer 30", guardian: "", age: 6, level: "Level 3", time: "11am", balance: 0, present: false, note: "" }
];
var seedInstructors = () => ({
  "10am|Level 3": [],
  "11am|Level 2": [],
  "11am|Level 3": [],
  "11am|Level 4": [],
  "12pm|Level 1": [],
  "12pm|Level 2": [],
  "12pm|Level 3": [],
  "12pm|Level 4": [],
  "12pm|Level 6": [],
  "1pm|Level 4": [],
  "2pm|Level 4": [],
  "2pm|Level 5": []
});
var LEVEL_4_12PM_GROUP_IDS = [];
var LEVEL_4_SEED_IDS = [];
function addSeedLevel4Students(weeksObj, migrations) {
  if (migrations.includes("add-seed-level4-students")) return { weeks: weeksObj, changed: false };
  // Photo-only seed: this migration's ID list is intentionally empty, so there's
  // nothing to add. Bail out without marking the weeks dirty (a false changed:true
  // would force an owner auto-save on every load).
  if (!LEVEL_4_SEED_IDS.length) return { weeks: weeksObj, changed: false };
  const seedById = new Map(seedStudents().filter((s) => LEVEL_4_SEED_IDS.includes(s.id)).map(({ present, ...s }) => [s.id, s]));
  const seedInst = seedInstructors();
  const nextWeeks = {};
  let changed = false;
  for (const [wk, w] of Object.entries(weeksObj)) {
    const roster = Array.isArray(w.roster) ? w.roster : [];
    const existingKeys = new Set(roster.map((s) => `${s.time}|${s.level}|${s.name.toLowerCase()}`));
    const missing = LEVEL_4_SEED_IDS.map((id) => seedById.get(id)).filter(
      (s) => s && !existingKeys.has(`${s.time}|${s.level}|${s.name.toLowerCase()}`)
    );
    const instructors = { ...w.instructors };
    for (const [k, names] of Object.entries(seedInst)) {
      if (!k.endsWith("|Level 4")) continue;
      if (!instructors[k] || instructors[k].length === 0) instructors[k] = names;
    }
    if (missing.length) changed = true;
    nextWeeks[wk] = {
      ...w,
      roster: missing.length ? [...roster, ...missing] : roster,
      instructors
    };
  }
  migrations.push("add-seed-level4-students");
  return { weeks: nextWeeks, changed: true };
}
function addLevel4GroupTo12pm(weeksObj, migrations) {
  if (migrations.includes("add-12pm-level4-group")) return { weeks: weeksObj, changed: false };
  // Photo-only seed: empty group list, nothing to add or relabel.
  if (!LEVEL_4_12PM_GROUP_IDS.length) return { weeks: weeksObj, changed: false };
  const seedById = new Map(
    seedStudents().filter((s) => LEVEL_4_12PM_GROUP_IDS.includes(s.id)).map(({ present, ...s }) => [s.id, s])
  );
  const seedInst = seedInstructors();
  const nextWeeks = {};
  let changed = false;
  for (const [wk, w] of Object.entries(weeksObj)) {
    const roster = Array.isArray(w.roster) ? w.roster : [];
    const haveIds = new Set(roster.map((s) => s.id));
    const have12pmNames = new Set(roster.filter((s) => s.time === "12pm").map((s) => s.name.toLowerCase()));
    // Relabel any existing group members (e.g. left in "Level 4B" by an earlier migration)
    // to Level 4 at 12pm and correct their age/balance from the seed.
    const relabeled = roster.map((s) => {
      if (!LEVEL_4_12PM_GROUP_IDS.includes(s.id)) return s;
      const seed = seedById.get(s.id);
      if (!seed) return s;
      if (s.level !== "Level 4" || s.time !== "12pm" || s.age !== seed.age || s.balance !== seed.balance) changed = true;
      return { ...s, level: "Level 4", time: "12pm", age: seed.age, balance: seed.balance };
    });
    // Add any group members missing from the roster entirely.
    const missing = LEVEL_4_12PM_GROUP_IDS
      .map((id) => seedById.get(id))
      .filter((s) => s && !haveIds.has(s.id) && !have12pmNames.has(s.name.toLowerCase()));
    if (missing.length) changed = true;
    const instructors = { ...w.instructors };
    if (!instructors["12pm|Level 4"] || instructors["12pm|Level 4"].length === 0) {
      instructors["12pm|Level 4"] = seedInst["12pm|Level 4"];
    }
    delete instructors["12pm|Level 4B"];
    nextWeeks[wk] = {
      ...w,
      roster: missing.length ? [...relabeled, ...missing] : relabeled,
      instructors
    };
  }
  migrations.push("add-12pm-level4-group");
  return { weeks: nextWeeks, changed: true };
}
function App() {
  const seededWeek = weekKeyFor(pstDateKey());
  const [weeks, setWeeks] = useState(() => ({
    [seededWeek]: { roster: seedStudents(), instructors: seedInstructors(), attendance: {} }
  }));
  // Land on the CURRENT lesson slot when the app opens mid-day (falls back to
  // the first slot outside lesson hours). Lazy so it's computed exactly once.
  const [activeTime, setActiveTime] = useState(() => {
    const slot = currentSlot();
    return TIME_SLOTS.includes(slot) ? slot : "10am";
  });
  const [view, setView] = useState("day");
  const [search, setSearch] = useState("");
  const [syncState, setSyncState] = useState("loading");
  const [showSettings, setShowSettings] = useState(false);
  const [sbVersion, setSbVersion] = useState(0);
  const [editUnlocked, setEditUnlocked] = useState(false);
  const [session, setSession] = useState(null);
  const lastAuthUserRef = useRef("");
  const [profile, setProfile] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [authError, setAuthError] = useState("");
  const [switchRequests, setSwitchRequests] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [staff, setStaff] = useState(defaultStaff);
  const [instrWrites, setInstrWrites] = useState([]);
  // Instructor's OWN daily self-check-in map: { [dateKey]: "present"|"absent" }.
  // Hydrated from their instructor_writes row's attendance.__self so the prompt
  // doesn't re-appear after a reload/poll once they've answered today.
  const [mySelfMap, setMySelfMap] = useState({});
  // Their daily "which lessons do I have" answer: { [dateKey]: "10am,11am" }.
  // Asked with the check-in; edits after answering go through admin approval.
  const [myLessonsMap, setMyLessonsMap] = useState({});
  // Per-minute tick used only to re-evaluate the 9:55 check-in gate without a
  // manual refresh. Bumped by a lightweight interval guarded to instructors.
  const [selfTick, setSelfTick] = useState(0);
  const [showReview, setShowReview] = useState(false);
  const [showAccounts, setShowAccounts] = useState(false);
  const [clockBusy, setClockBusy] = useState(false);
  const [updateReady, setUpdateReady] = useState(false);
  const [hasUnsaved, setHasUnsaved] = useState(false);
  const updateReadyRef = useRef(false);
  useEffect(() => { updateReadyRef.current = updateReady; }, [updateReady]);
  const wantReloadRef = useRef(false);
  useEffect(() => {
    const on = () => setUpdateReady(true);
    window.addEventListener("ag-update-ready", on);
    return () => window.removeEventListener("ag-update-ready", on);
  }, []);
  // ACTIVE update detection: every few minutes (and on tab-return/reconnect)
  // the app compares the tiny deployed version file against its own build. On
  // a mismatch it asks the service worker to pre-download the new bundle into
  // the cache FIRST, then announces — so the update tap is instant. Fetch
  // failures are silently ignored (offline just means "check later").
  useEffect(() => {
    let alive = true;
    const check = async () => {
      if (!alive || updateReadyRef.current) return;
      if (typeof document !== "undefined" && document.hidden) return;
      try {
        const res = await fetch("/version.txt", { cache: "no-store" });
        if (!res || !res.ok) return;
        const v = String(await res.text()).trim();
        // The Netlify SPA fallback answers 200 with index.html for ANY missing
        // path — without this guard, a deploy that forgot version.txt reads the
        // page HTML as a "new version" and loops the update banner forever.
        const ct = String(res.headers.get("content-type") || "");
        if (ct.includes("text/html") || !/^[A-Za-z0-9._-]{1,32}$/.test(v)) return;
        if (!alive || !v || v === APP_BUILD) return;
        const ctrl = typeof navigator !== "undefined" && navigator.serviceWorker && navigator.serviceWorker.controller;
        if (ctrl) ctrl.postMessage({ type: "ag-refresh-shell" });
        else setUpdateReady(true);
      } catch {}
    };
    const t0 = setTimeout(check, 12000);
    const iv = setInterval(check, 5 * 60 * 1000);
    const onVis = () => { if (document.visibilityState === "visible") check(); };
    window.addEventListener("visibilitychange", onVis);
    window.addEventListener("online", check);
    return () => { alive = false; clearTimeout(t0); clearInterval(iv); window.removeEventListener("visibilitychange", onVis); window.removeEventListener("online", check); };
  }, []);
  // Save-safe apply: if a save is queued or in flight, wait for "saved" (or
  // offline stash) before reloading so the tap can never eat an edit.
  const applyUpdate = () => {
    const busy = dirtyRef.current || saveTimerArmedRef.current || syncState === "saving";
    if (busy) {
      wantReloadRef.current = true;
      setSyncNotice("Finishing your save, then updating\u2026");
      return;
    }
    try { if (window.__agReload) { window.__agReload(); return; } } catch {}
    try { location.reload(); } catch {}
  };
  useEffect(() => {
    if (!wantReloadRef.current) return;
    if (syncState === "saved" || syncState === "offline") {
      wantReloadRef.current = false;
      try { if (window.__agReload) { window.__agReload(); return; } } catch {}
      try { location.reload(); } catch {}
    }
  }, [syncState]);
  // Bumped by the existing 30s tick so live "on the clock" durations stay fresh.
  const [clockTick, setClockTick] = useState(0);
  const [showScan, setShowScan] = useState(false);
  const [extraClasses, setExtraClasses] = useState([]);
  const [nowSlot, setNowSlot] = useState(currentSlot());
  const [activeDate, setActiveDate] = useState(pstDateKey());
  // Live offline indicator. The sync engine already listens for "online" to
  // flush pending saves; this state only drives the banner under the header.
  const [isOnline, setIsOnline] = useState(() => {
    try { return typeof navigator === "undefined" || navigator.onLine !== false; } catch { return true; }
  });
  useEffect(() => {
    const up = () => setIsOnline(true);
    const down = () => setIsOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => { window.removeEventListener("online", up); window.removeEventListener("offline", down); };
  }, []);
  const [freeSwim, setFreeSwim] = useState(defaultFreeSwim);
  const [theme, setTheme] = useState(SB.theme);
  useEffect(() => {
    try {
      document.documentElement.setAttribute("data-theme", theme === "dark" ? "dark" : "light");
    } catch {
    }
    SB.saveTheme(theme);
  }, [theme]);
  // Color theme (Settings → App color). Per-device, like light/dark.
  const [accent, setAccent] = useState(() => { try { return localStorage.getItem("ag_accent") || "pool"; } catch { return "pool"; } });
  useEffect(() => {
    try { document.documentElement.setAttribute("data-accent", accent); } catch {}
    try { if (accent === "pool") localStorage.removeItem("ag_accent"); else localStorage.setItem("ag_accent", accent); } catch {}
  }, [accent]);
  // --- PWA "Add to Home Screen" install support --------------------------
  // Chromium fires `beforeinstallprompt` when the app is installable; we
  // capture & defer the event so a Settings button can trigger the native
  // install dialog on demand. iOS Safari has no install API, so the button
  // falls back to a platform-instructions modal (handled in the UI below).
  const deferredInstallRef = useRef(null);
  const [canInstall, setCanInstall] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [installGuide, setInstallGuide] = useState(false);
  const isStandalone = (() => {
    try {
      return (typeof window !== "undefined" && (
        (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) ||
        window.navigator.standalone === true
      ));
    } catch {
      return false;
    }
  })();
  useEffect(() => {
    const onBeforeInstall = (e) => {
      // Prevent the mini-infobar; stash the event so we can prompt() later.
      e.preventDefault();
      deferredInstallRef.current = e;
      setCanInstall(true);
    };
    const onInstalled = () => {
      deferredInstallRef.current = null;
      setCanInstall(false);
      setIsInstalled(true);
    };
    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);
  const handleInstall = async () => {
    const evt = deferredInstallRef.current;
    if (evt && typeof evt.prompt === "function") {
      // Chromium path — native install dialog, true one-tap install.
      try {
        evt.prompt();
        await evt.userChoice;
      } catch {
      }
      deferredInstallRef.current = null;
      setCanInstall(false);
    } else {
      // No deferred event (iOS Safari, or already-dismissed) — show the guide.
      setInstallGuide(true);
    }
  };
  const loadedRef = useRef(false);
  const saveTimer = useRef(null);
  const justSavedRef = useRef(0);
  const migratedRef = useRef(null);
  const migrationsRef = useRef([]);
  const lastPstDateRef = useRef(pstDateKey());
  // Monotonic version of the owner blob we last loaded/saved. The poll compares
  // this against the server's rev to decide whether to adopt server state.
  const rosterRevRef = useRef(0);
  // (legacy) last-seen updated_at — retained only so older references resolve.
  const lastRosterUpdatedAtRef = useRef(null);
  // R2: owner has local edits not yet confirmed-saved — poll must not clobber them.
  const dirtyRef = useRef(false);
  // Instructor mirror of dirtyRef: a just-tapped attendance mark or request is
  // only debounce-deep, and a poll adopting server weeks in that window would
  // revert it — then the armed save persists the reverted state (silent loss).
  // Set in markEdit for non-owners, cleared when their row save confirms.
  const instrDirtyRef = useRef(false);
  // USER-EDIT GATE: true only when a state change was authored by the person on
  // this device (every edit path calls markEdit()). The save effect refuses to
  // run without it, so state adopted from the initial load, the cache fallback,
  // the 15s poll, or the accounts refresh can NEVER trigger a save. This is what
  // prevents: phantom rev bumps on open, a rev ping-pong loop between two open
  // devices, and an offline open stashing the stale cache as a pending save.
  const userEditRef = useRef(false);
  // True while a debounced save is scheduled but hasn't fired yet — lets the
  // reconnect/visibility flush skip work a fresher queued save will do anyway.
  const saveTimerArmedRef = useRef(false);
  const lastStashAtRef = useRef(0);
  // Throttles the mid-session profile re-check (disabled/role flips take effect
  // without waiting for the next full sign-in).
  const lastProfileCheckRef = useRef(0);
  // Last ADOPTED instructor_writes payload (serialized): identical polls skip
  // setInstrWrites so the whole tree isn't re-rendered every 15s for nothing.
  const lastIwJsonRef = useRef("");
  // True while a punch (saveMyShifts) is in flight — the poll must not adopt
  // the server's older copy of MY row over the optimistic punch, or a second
  // tap on the reverted state can permanently lose the first one.
  const shiftSaveInFlightRef = useRef(false);
  // Metadata of a roster_pending stash recovered from a PREVIOUS session
  // ({ baseRev, at }); null for stashes written this session. When set, the
  // flush asks before overwriting possibly-newer server data.
  const recoveredStashRef = useRef(null);
  // Marks THIS instructor authored this session ("week|date|studentId") — the
  // save path re-asserts only these plus their row's still-true history, not a
  // snapshot of everyone's merged marks (see filterAttendanceToLocal).
  const myAuthoredMarksRef = useRef(/* @__PURE__ */ new Set());
  // Fresh instrWrites for the debounced instructor save; the save effect's
  // closure can be a render behind (instrWrites isn't in its deps).
  const instrWritesRef = useRef(instrWrites);
  useEffect(() => { instrWritesRef.current = instrWrites; });
  // When the initial load hangs, a save doesn't have to wait forever: this
  // probe races a fresh row read against 5s just to learn the server's rev.
  // Success unblocks committing (LWW on top of that rev); failure means we're
  // genuinely offline and the payload stays safely stashed.
  const revProbe = async () => {
    try {
      const row = await Promise.race([
        loadRosterRow(),
        new Promise((_, rej) => setTimeout(() => rej(new Error("probe timeout")), 5000))
      ]);
      // Monotonic: a probe that resolves LATE must never drag the local rev
      // backward past a save that already landed.
      if ((row.rev || 0) >= rosterRevRef.current) {
        lastRosterUpdatedAtRef.current = row.updatedAt;
        rosterRevRef.current = row.rev || 0;
      }
      bootLoadingRef.current = false;
      return true;
    } catch {
      return false;
    }
  };
  const forceSaveRef = useRef(false);
  const bootWaitRef = useRef(0);
  // Points at the CURRENT debounce callback so "Save now" can fire the real
  // save path immediately (same closures, same serialization, same guards).
  const saveNowRef = useRef(null);
  // Serializes owner writes: each commit awaits the previous one, so two saves
  // can never land out of order (a late older write can't overwrite a newer one).
  const saveChainRef = useRef(Promise.resolve());
  // True while the FIRST network load of a session is still in flight. An owner
  // edit made on warm-start data defers its save until this clears, so the
  // write is stamped serverRev+1 instead of a bogus rev 1.
  const bootLoadingRef = useRef(false);
  // R3: payload of a failed owner save, retained for retry (also mirrored to localStorage).
  const pendingSaveRef = useRef(null);
  // R1: non-destructive notice shown near the SyncBadge (e.g. "reloaded newer data").
  const [syncNotice, setSyncNotice] = useState("");
  // Informational notices (imports, restores, adoptions) auto-dismiss after a
  // few seconds. The token guarantees an older timer can never clear a NEWER
  // notice that replaced this one in the meantime.
  const noticeTokenRef = useRef(0);
  const flashNotice = (text) => {
    const token = ++noticeTokenRef.current;
    setSyncNotice(text);
    setTimeout(() => {
      if (noticeTokenRef.current === token) setSyncNotice((cur) => cur === text ? "" : cur);
    }, 6000);
  };
  const activeWeek = weekKeyFor(activeDate);
  const activeWeekData = weeks[activeWeek] || { roster: [], instructors: {}, attendance: {} };
  const roster = activeWeekData.roster;
  const instructors = activeWeekData.instructors;
  const attendance = activeWeekData.attendance;
  const patchWeek = (field, valueOrFn) => {
    setWeeks((all) => {
      const wk = all[activeWeek] || { roster: [], instructors: {}, attendance: {} };
      const prev = wk[field];
      const next = typeof valueOrFn === "function" ? valueOrFn(prev) : valueOrFn;
      if (next === prev) return all;
      return { ...all, [activeWeek]: { ...wk, [field]: next } };
    });
  };
  const setRoster = (v) => patchWeek("roster", v);
  const setInstructors = (v) => patchWeek("instructors", v);
  const setAttendance = (v) => patchWeek("attendance", v);
  // ---- Instructor preview (admins only) ----
  // previewAs = { id, name } of the instructor being previewed. While set, the
  // derived isOwner/isInstructor flags flip, so every downstream surface (nav
  // tabs, guards, dialogs, My Lessons, punch card) renders the instructor
  // experience with LIVE data — but every write path is hard-blocked, so an
  // admin can never accidentally act as (or on) someone while just looking.
  const [previewAs, setPreviewAs] = useState(null);
  const isOwnerReal = !!profile && profile.role === "owner" && profile.active !== false;
  const previewing = isOwnerReal && !!previewAs;
  const isOwner = isOwnerReal && !previewing;
  const isInstructor = previewing ? true : !!profile && profile.role !== "owner" && profile.active !== false;
  const previewingRef = useRef(false);
  useEffect(() => { previewingRef.current = previewing; }, [previewing]);
  const didDefaultViewRef = useRef(false);
  useEffect(() => {
    if (didDefaultViewRef.current || !profile) return;
    didDefaultViewRef.current = true;
    // Instructors land on "My Lessons" first; owners keep the default.
    if (profile.role !== "owner") setView("mine");
  }, [profile]);
  const myUserId = profile ? profile.id : "";
  const myName = profile ? profile.username : "";
  const currentUser = previewing && previewAs ? { id: previewAs.id, name: previewAs.name } : isInstructor ? { id: myUserId, name: myName } : null;
  const myLessonKeys = currentUser ? lessonsForName(currentUser.name, instructors, roster) : [];
  const pendingCount = switchRequests.filter((r) => r.status === "pending").length;
  const isOwnerRef = useRef(false);
  useEffect(() => { isOwnerRef.current = isOwner; }, [isOwner]);
  const profileIsOwner = () => isOwnerRef.current;
  const myUserIdRef = useRef("");
  useEffect(() => { myUserIdRef.current = myUserId; }, [myUserId]);
  const myNameRef = useRef("");
  useEffect(() => { myNameRef.current = myName; }, [myName]);
  // Hydrate my own self-check-in map from my instructor_writes row whenever the
  // rows (re)load via initial load or poll, so "answered today" survives reload.
  const mySelfMapRef = useRef({});
  useEffect(() => { mySelfMapRef.current = mySelfMap; }, [mySelfMap]);
  useEffect(() => {
    if (!isInstructor || !myUserId) return;
    const mine = (Array.isArray(instrWrites) ? instrWrites : []).find((r) => r && r.user_id === myUserId);
    const self = mine && mine.attendance && typeof mine.attendance === "object" && mine.attendance[SELF_KEY] && typeof mine.attendance[SELF_KEY] === "object"
      ? mine.attendance[SELF_KEY] : null;
    if (self) setMySelfMap((prev) => {
      // Only adopt server values for days we don't already have locally, so a
      // just-answered "today" isn't clobbered by an in-flight poll.
      const next = { ...self, ...prev };
      const same = Object.keys(next).length === Object.keys(prev).length && Object.keys(next).every((k) => next[k] === prev[k]);
      return same ? prev : next;
    });
    const les = mine && mine.attendance && typeof mine.attendance === "object" && mine.attendance[LESSONS_KEY] && typeof mine.attendance[LESSONS_KEY] === "object"
      ? mine.attendance[LESSONS_KEY] : null;
    if (les) setMyLessonsMap((prev) => {
      const next = { ...les, ...prev }; // local wins, same rule as __self
      const same = Object.keys(next).length === Object.keys(prev).length && Object.keys(next).every((k) => next[k] === prev[k]);
      return same ? prev : next;
    });
  }, [instrWrites, myUserId, isInstructor]);
  const myLessonsMapRef = useRef({});
  useEffect(() => { myLessonsMapRef.current = myLessonsMap; }, [myLessonsMap]);
  // When an admin APPROVES a lessons change, adopt it into the local map so the
  // next instructor save persists it instead of re-asserting the old answer
  // (the hydrate above is local-wins, so this explicit adopt is the override).
  useEffect(() => {
    if (!isInstructor || !myUserId) return;
    // switchRequests is sorted newest-first; the first hit per day wins.
    const seen = new Set();
    const wins = [];
    for (const r of switchRequests) {
      if (r.kind !== "lessonEdit" || r.byId !== myUserId || r.status !== "approved" || !r.day || seen.has(r.day)) continue;
      seen.add(r.day);
      wins.push(r);
    }
    if (!wins.length) return;
    setMyLessonsMap((prev) => {
      let changed = false;
      const next = { ...prev };
      for (const r of wins) {
        if (next[r.day] !== r.toSlots) { next[r.day] = r.toSlots; changed = true; }
      }
      return changed ? next : prev;
    });
  }, [switchRequests, myUserId, isInstructor]);
  // Lightweight per-minute tick (instructors only) so the 9:55 check-in prompt
  // appears without a manual refresh even if the slot string hasn't changed.
  useEffect(() => {
    if (!isInstructor) return;
    const iv = setInterval(() => setSelfTick((t) => t + 1), 60000);
    return () => clearInterval(iv);
  }, [isInstructor]);
  // ---- Auth session: the single source of identity (server-verified) ----
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        // Guard against a hung network call: if Supabase doesn't answer in 8s,
        // stop waiting and show what happened instead of spinning forever.
        const withTimeout = (p, ms, label) => Promise.race([
          p,
          new Promise((_, rej) => setTimeout(() => rej(new Error("Timed out reaching Supabase (" + label + "). Check the project URL, network, and that the SQL setup ran.")), ms))
        ]);
        const { data } = await withTimeout(supa.auth.getSession(), SUPABASE_TIMEOUT_MS, "getSession");
        if (!alive) return;
        setSession(data.session || null);
        if (data.session) {
          const p = await withTimeout(getMyProfile(), SUPABASE_TIMEOUT_MS, "getMyProfile");
          if (!alive) return;
          setProfile(p);
          setEditUnlocked(!!(p && p.role === "owner"));
        }
      } catch (e) {
        if (alive) setAuthError(String(e && e.message || e));
      } finally {
        if (alive) setAuthReady(true);
      }
    })();
    const { data: sub } = supa.auth.onAuthStateChange(async (_evt, sess) => {
      if (!alive) return;
      // Supabase refreshes the access token about hourly and fires this with a
      // NEW session object for the SAME user. Re-setting state for that forced
      // a full reload cycle (profile fetch, roster load, realtime resubscribe)
      // every hour. Same user + token refresh => nothing to do; the client
      // keeps using the fresh token internally.
      if (_evt === "TOKEN_REFRESHED" && sess && sess.user && lastAuthUserRef.current === sess.user.id) return;
      lastAuthUserRef.current = sess && sess.user ? sess.user.id : "";
      setSession(sess || null);
      if (sess) {
        try {
          const p = await getMyProfile();
          if (!alive) return;
          setProfile(p);
          setEditUnlocked(!!(p && p.role === "owner"));
          setSbVersion((v) => v + 1);
        } catch (e) {
          if (alive) setAuthError(String(e && e.message || e));
        }
      } else {
        setProfile(null);
        setEditUnlocked(false);
      }
    });
    return () => { alive = false; try { sub.subscription.unsubscribe(); } catch {} };
  }, []);
  useEffect(() => {
    if (!session || !isOwner) return;
    let alive = true;
    (async () => {
      try {
        const profs = await loadAllProfiles();
        if (!alive) return;
        setAccounts(profs.filter((p) => p.id !== myUserId).map((p) => ({ id: p.id, name: p.username, active: p.active !== false, role: p.role === "owner" ? "owner" : "instructor" })));
      } catch {}
    })();
    return () => { alive = false; };
  }, [session, isOwner]);
  // Keep staff.adminIds (me + active co-admins) current in the synced blob so
  // instructor devices know who to push-notify about new requests — they can't
  // read the profiles table themselves. Writes only when the set changed.
  useEffect(() => {
    if (!isOwner || !myUserId) return;
    const ids = Array.from(new Set([myUserId, ...(accounts || []).filter((a) => a && a.role === "owner" && a.active !== false).map((a) => a.id)])).sort();
    const cur = Array.isArray(staff && staff.adminIds) ? staff.adminIds.slice().sort() : [];
    if (cur.length === ids.length && cur.every((v, i) => v === ids[i])) return;
    markEdit();
    setStaff((s) => ({ ...sanitizeStaff(s), adminIds: ids }));
  }, [isOwner, myUserId, accounts, staff]);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!session) {
        loadedRef.current = false;
        return;
      }
      setSyncState("loading");
      // WARM START: paint the last known data INSTANTLY from the local cache
      // while the fresh load runs. Reopening the app shows the roster in ~0ms
      // instead of a spinner; the network result replaces it the moment it
      // lands. The save-gate keeps this adoption from ever triggering a write,
      // and bootLoadingRef defers any owner save fired in this window until
      // the server's rev is known (so an early edit can't stamp rev 1).
      bootLoadingRef.current = true;
      try {
        const cacheBase = SB.cachedData;
        let pend0 = null;
        // Envelope-aware: newer stashes are { blob, baseRev, at }; a legacy
        // value IS the blob itself.
        try {
          const raw0 = localStorage.getItem("roster_pending");
          if (raw0) {
            pend0 = JSON.parse(raw0);
            if (pend0 && pend0.blob && typeof pend0.blob === "object") pend0 = pend0.blob;
          }
        } catch {}
        // Prefer the recovered pending (newer than the cache); keep the cache's
        // instructor rows since pending payloads don't carry them.
        const cached0 = pend0 && pend0.weeks && typeof pend0.weeks === "object"
          ? { ...pend0, iw: cacheBase && Array.isArray(cacheBase.iw) ? cacheBase.iw : void 0 }
          : cacheBase;
        if (cached0 && cached0.weeks && typeof cached0.weeks === "object" && !loadedRef.current) {
          migrationsRef.current = Array.isArray(cached0.migrations) ? cached0.migrations : [];
          setWeeks(cached0.weeks);
          if (cached0.freeSwim) setFreeSwim(sanitizeFreeSwim(cached0.freeSwim));
          if (cached0.staff) setStaff(sanitizeStaff(cached0.staff));
          if (cached0.switchRequests) setSwitchRequests(sanitizeSwitchRequests(cached0.switchRequests));
          if (Array.isArray(cached0.iw)) setInstrWrites(cached0.iw);
          const todayWk0 = weekKeyFor(pstDateKey());
          if (cached0.weeks[todayWk0]) setActiveDate(pstDateKey());
          else { const ks = Object.keys(cached0.weeks).sort(); if (ks.length) setActiveDate(ks[ks.length - 1]); }
          loadedRef.current = true;
        }
      } catch {}
      try {
        // R1: load the row WITH its updated_at so saves can compare-and-set.
        const row = await loadRosterRow();
        const data = row.data;
        if (cancelled) return;
        lastRosterUpdatedAtRef.current = row.updatedAt;
        rosterRevRef.current = row.rev || 0;
        bootLoadingRef.current = false;
        if (dirtyRef.current || pendingSaveRef.current) {
          // The owner edited the warm-start data before the fresh load landed:
          // their edit is authoritative (LWW) — fold in instructor rows only,
          // let the queued save stamp serverRev+1 on top.
          let iwB = [];
          try { iwB = await loadInstructorWrites(); } catch {}
          if (!cancelled) {
            setInstrWrites(iwB);
            setWeeks((prev) => mergeAttendance(prev, iwB));
            loadedRef.current = true;
          }
        } else if (data && typeof data === "object") {
          const migrations = Array.isArray(data.migrations) ? data.migrations : [];
          let weeksObj = null;
          if (data.weeks && typeof data.weeks === "object" && Object.keys(data.weeks).length) {
            weeksObj = {};
            for (const [wk, w] of Object.entries(data.weeks)) {
              weeksObj[wk] = {
                roster: (Array.isArray(w.roster) ? w.roster : []).map(({ present, ...s }) => s),
                instructors: w.instructors && typeof w.instructors === "object" ? w.instructors : {},
                attendance: w.attendance && typeof w.attendance === "object" ? w.attendance : {}
              };
            }
          } else if (Array.isArray(data.students)) {
            let students2 = data.students.map(({ present, ...s }) => s);
            let instructors2 = data.instructors || {};
            const attendance2 = data.attendance && typeof data.attendance === "object" ? data.attendance : {};
            if (!migrations.includes("add-11am")) {
              if (!students2.some((s) => s.time === "11am")) {
                students2 = [...students2, ...seedStudents().filter((s) => s.time === "11am").map(({ present, ...s }) => s)];
              }
              const seedInst = seedInstructors();
              const merged = { ...instructors2 };
              ["11am|Level 1", "11am|Level 2", "11am|Level 3", "11am|Level 4", "2pm|Level 5"].forEach((k) => {
                if (!merged[k] || merged[k].length === 0) merged[k] = seedInst[k];
              });
              instructors2 = merged;
              migrations.push("add-11am");
            }
            const wk = weekKeyFor(pstDateKey());
            weeksObj = { [wk]: { roster: students2, instructors: instructors2, attendance: attendance2 } };
            if (!migrations.includes("weeks-v1")) migrations.push("weeks-v1");
            migratedRef.current = true;
          }
          if (weeksObj) {
            const level4Migration = addSeedLevel4Students(weeksObj, migrations);
            weeksObj = level4Migration.weeks;
            if (level4Migration.changed) migratedRef.current = true;
            const level4GroupMigration = addLevel4GroupTo12pm(weeksObj, migrations);
            weeksObj = level4GroupMigration.weeks;
            if (level4GroupMigration.changed) migratedRef.current = true;
            migrationsRef.current = migrations;
            setWeeks(weeksObj);
            // Use the saved free-swim ONLY if it actually carries today's setup.
            // If the stored freeSwim is blank (nobody on duty and no manual
            // placements) — e.g. a prior save never landed — fall back to the
            // seeded default so today's lineup loads without touching Supabase.
            const savedFs = data.freeSwim ? sanitizeFreeSwim(data.freeSwim) : null;
            const savedFsEmpty = !savedFs || ((savedFs.onDuty || []).length === 0 && !(savedFs.manual || []).some((r) => Array.isArray(r) && r.some((c) => c)));
            setFreeSwim(savedFsEmpty ? defaultFreeSwim() : savedFs);
            setStaff(sanitizeStaff(data.staff));
            const baseReqs = sanitizeSwitchRequests(data.switchRequests);
            let iw = [];
            try { iw = await loadInstructorWrites(); } catch {}
            setInstrWrites(iw);
            const mergedReqs = mergeRequests(baseReqs, iw);
            setSwitchRequests(mergedReqs);
            const mergedWeeks = mergeAttendance(weeksObj, iw);
            setWeeks(mergedWeeks);
            SB.cacheData({ weeks: mergedWeeks, migrations, freeSwim: sanitizeFreeSwim(data.freeSwim), switchRequests: mergedReqs, accounts: sanitizeAccounts(data.accounts), staff: sanitizeStaff(data.staff), rev: row.rev, iw });
            // Daily safety net: snapshot how the roster looked when today
            // began. Insert-if-absent, fire-and-forget, and hardened so the
            // safety net can never break the boot it protects.
            if (profileIsOwner() && !previewingRef.current) {
              try {
                const snapBlob = { weeks: mergedWeeks, migrations, freeSwim: sanitizeFreeSwim(data.freeSwim), switchRequests: mergedReqs, accounts: sanitizeAccounts(data.accounts), staff: sanitizeStaff(data.staff) };
                const snapMeta = { weeks: Object.keys(mergedWeeks).length, students: Object.values(mergedWeeks).reduce((t, wkv) => t + ((wkv && Array.isArray(wkv.roster)) ? wkv.roster.length : 0), 0) };
                writeDailyBackup(pstDateKey(), snapBlob, snapMeta).catch(() => {});
                pruneRosterBackups();
              } catch (e) { try { console.warn("daily backup skipped:", e); } catch {} }
            }
            const todayWk = weekKeyFor(pstDateKey());
            const wkKeys = Object.keys(weeksObj).sort();
            if (weeksObj[todayWk]) setActiveDate(pstDateKey());
            else setActiveDate(wkKeys[wkKeys.length - 1]);
            if (migratedRef.current && profileIsOwner()) {
              try {
                // Rev-stamped + serialized, and MUST carry staff: the old rev-less
                // sbSave here dropped the staff field (silently resetting roles and
                // staff attendance to defaults) and reset rev to 0, which stopped
                // other devices from ever adopting the migrated blob.
                await commitOwnerSave({ weeks: weeksObj, migrations, freeSwim: sanitizeFreeSwim(data.freeSwim), switchRequests: baseReqs, accounts: sanitizeAccounts(data.accounts), staff: sanitizeStaff(data.staff) });
                justSavedRef.current = Date.now();
              } catch {
              }
              migratedRef.current = null;
            }
          }
        }
        loadedRef.current = true;
        setSyncState("saved");
        // A pending payload recovered from a prior crash/close can flush NOW that
        // the server rev is known — no need to wait for an online/visibility event.
        if (pendingSaveRef.current && profileIsOwner()) flushPendingRef.current();
      } catch {
        bootLoadingRef.current = false;
        if (!cancelled) {
          const cached = SB.cachedData;
          if (cached && cached.weeks && typeof cached.weeks === "object") {
            migrationsRef.current = Array.isArray(cached.migrations) ? cached.migrations : [];
            setWeeks(cached.weeks);
            if (cached.freeSwim) setFreeSwim(sanitizeFreeSwim(cached.freeSwim));
            if (cached.staff) setStaff(sanitizeStaff(cached.staff));
            if (cached.switchRequests) setSwitchRequests(sanitizeSwitchRequests(cached.switchRequests));
            if (Array.isArray(cached.iw)) setInstrWrites(cached.iw);
            const todayWk = weekKeyFor(pstDateKey());
            if (cached.weeks[todayWk]) setActiveDate(pstDateKey());
            else {
              const wkKeys = Object.keys(cached.weeks).sort();
              if (wkKeys.length) setActiveDate(wkKeys[wkKeys.length - 1]);
            }
          }
          loadedRef.current = true;
          setSyncState("offline");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [sbVersion, session]);
  // R1/R3: single owner-save path used by the debounce, the online/visibility
  // retry, and the conflict reconcile. Does compare-and-set; on a detected
  // concurrent write it reloads the server's latest and adopts it (never
  // clobbers), surfacing a non-destructive notice so the owner can re-apply.
  // Returns true on a confirmed write, false otherwise.
  // Owner save: last-write-wins. The owner is the sole writer of the canonical
  // blob, so there's no lost-update race to defend against — we just bump the
  // monotonic rev and upsert once. Exactly one network round-trip; it either
  // resolves (→ true) or throws (caught upstream → "offline" + auto-retry). It
  // can never sit half-finished, which is what pinned the badge on "Saving…".
  const commitOwnerSave = (blob) => {
    // Serialized: this commit starts only after every earlier commit settled, so
    // a slow rev-N write can never land AFTER (and silently overwrite) rev-N+1.
    const run = saveChainRef.current.then(async () => {
      const nextRev = (rosterRevRef.current || 0) + 1;
      await saveRosterBlob(blob, nextRev);
      rosterRevRef.current = nextRev;
      SB.cacheData({ ...blob, rev: nextRev });
      return true;
    });
    // Keep the chain alive on failure; the caller still sees the rejection.
    saveChainRef.current = run.catch(() => {});
    return run;
  };
  // R3: persist/clear the pending owner payload (survives reloads). Stored as
  // an envelope { blob, baseRev, at } so a recovery in a LATER session can tell
  // whether the stash is stale (server moved on, or it's simply old) and ask
  // before overwriting newer data. In-memory pendingSaveRef stays the raw blob.
  const stashPending = (blob) => {
    pendingSaveRef.current = blob;
    // A stash written this session is fresh by definition — no recovery prompt.
    recoveredStashRef.current = null;
    try { localStorage.setItem("roster_pending", JSON.stringify({ blob, baseRev: rosterRevRef.current || 0, at: Date.now() })); } catch {}
  };
  const clearPending = () => {
    pendingSaveRef.current = null;
    recoveredStashRef.current = null;
    try { localStorage.removeItem("roster_pending"); } catch {}
  };
  useEffect(() => {
    if (!loadedRef.current || !session) return;
    // GATE: only persist USER-AUTHORED changes. This effect also re-runs when
    // the initial load, cache fallback, 15s poll, or accounts refresh set these
    // same state atoms — those are adoptions of already-persisted data, and
    // saving them again caused (a) a phantom rev bump on every app open, (b) a
    // rev ping-pong feedback loop between two open devices, and (c) an offline
    // open stashing the stale CACHE as a pending save that would later
    // overwrite newer server data. Every real edit path calls markEdit().
    if (!userEditRef.current) return;
    if (previewingRef.current) return;
    if (profileIsOwner()) dirtyRef.current = true;
    setSyncState("saving");
    // Mirror the NEWEST owner payload to the pending stash immediately, so the
    // beforeunload warning covers the debounce + in-flight window and every
    // retry path (reconnect, visibility, badge tap) flushes the latest edit —
    // not a snapshot from whenever the save first failed.
    if (profileIsOwner()) {
      const nowT = Date.now();
      // Throttled: typing fires this per keystroke, and stringifying the full
      // roster each time can jank older phones. First edit stashes instantly;
      // the timer below re-stashes the FINAL payload before committing.
      if (nowT - lastStashAtRef.current > 250) {
        stashPending({ weeks, migrations: migrationsRef.current, freeSwim, switchRequests, accounts, staff });
        lastStashAtRef.current = nowT;
      }
    }
    clearTimeout(saveTimer.current);
    saveTimerArmedRef.current = true;
    const fire = async function fire() {
      // Warm-start guard: the server rev isn't known yet — hold this save
      // (payload is already stashed) briefly. If the load HANGS (bad hotel
      // wifi, iOS resume), we don't wait forever: after ~4s — or immediately
      // on a manual "Save now" tap — probe for just the rev and commit on top
      // of it, or go honestly offline (stashed, retryable) if even that fails.
      if (bootLoadingRef.current && profileIsOwner()) {
        bootWaitRef.current += 1;
        if (!forceSaveRef.current && bootWaitRef.current < 10) {
          saveTimer.current = setTimeout(fire, 400);
          return;
        }
        forceSaveRef.current = false;
        const known = await revProbe();
        if (!known) {
          bootWaitRef.current = 0;
          saveTimerArmedRef.current = false;
          // The stash IS this edit — consume the marker so the eventual flush
          // knows nothing newer is waiting and can clear cleanly.
          userEditRef.current = false;
          setSyncState("offline");
          setSyncNotice("Can't reach the server \u2014 your change is saved on this phone. Tap Save \u00B7 retry when you're back online.");
          return;
        }
      }
      bootWaitRef.current = 0;
      saveTimerArmedRef.current = false;
      // Consume the edit marker NOW: any edit that lands while this request is
      // in flight re-arms it and re-runs the effect, queueing a follow-up save.
      userEditRef.current = false;
      try {
        if (profileIsOwner()) {
          // Owner is the sole writer of the canonical blob — last-write-wins.
          const blob = { weeks, migrations: migrationsRef.current, freeSwim, switchRequests, accounts, staff };
          stashPending(blob);
          lastStashAtRef.current = Date.now();
          await commitOwnerSave(blob);
          // Only stand down if no NEWER edit arrived while this one was in
          // flight — otherwise the fresher payload must stay pending/dirty.
          if (!userEditRef.current) {
            dirtyRef.current = false;
            clearPending();
            // A confirmed save supersedes any lingering failure notice.
            setSyncNotice((n) => typeof n === "string" && n.startsWith("Save failed") ? "" : n);
          }
        } else if (myUserIdRef.current) {
          // Instructor: persist ONLY their own attendance marks + their own
          // pending requests to their row. RLS blocks everything else. The
          // reserved __self key carries their daily self-check-in; mergeAttendance
          // skips it so it never leaks into roster weeks.
          // Their row = (their OWN row's previous marks still true locally)
          // UNION (marks they authored this session, still true locally).
          // Snapshotting ALL merged attendance here resurrected marks the
          // owner unmarked and grew every row unboundedly.
          const myRow = (Array.isArray(instrWritesRef.current) ? instrWritesRef.current : []).find((r) => r && r.user_id === myUserIdRef.current);
          const keptOwn = filterAttendanceToLocal(myRow && myRow.attendance, weeks);
          const authored = attendanceFromAuthored(myAuthoredMarksRef.current, weeks);
          const myAtt = { ...unionAttendance(keptOwn, authored), [SELF_KEY]: { ...mySelfMapRef.current }, [LESSONS_KEY]: { ...myLessonsMapRef.current }, [NAME_KEY]: String(myNameRef.current || "") };
          const myReqs = switchRequests.filter((r) => r.byId === myUserIdRef.current && r.status === "pending");
          await saveMyInstructorWrites(myUserIdRef.current, myAtt, myReqs);
          // Mirrors the owner's stand-down above: only clear the instructor
          // dirty flag if no newer edit landed while this write was in flight.
          if (!userEditRef.current) instrDirtyRef.current = false;
          // A confirmed save supersedes any lingering failure notice.
          setSyncNotice((n) => typeof n === "string" && n.startsWith("Save failed") ? "" : n);
        }
        justSavedRef.current = Date.now();
        if (!userEditRef.current) setSyncState("saved");
      } catch (e) {
        // Owner save failed — retain the payload (and mirror to localStorage) so
        // the online/visibility retry can flush it. Surface the REAL error text
        // so a permission/policy/timeout cause is visible instead of guessed.
        if (profileIsOwner()) {
          stashPending({ weeks, migrations: migrationsRef.current, freeSwim, switchRequests, accounts, staff });
          const raw = String((e && (e.message || e.error_description || e.hint)) || e || "Unknown error");
          setSyncNotice("Save failed: " + raw.slice(0, 180));
        } else {
          // Instructor save failed: re-arm this effect's own timer so the write
          // auto-retries. Without a retry path instrDirtyRef stays raised for
          // the whole session and the poll never adopts server data again.
          userEditRef.current = true;
          saveTimerArmedRef.current = true;
          clearTimeout(saveTimer.current);
          saveTimer.current = setTimeout(fire, 8000);
          setSyncNotice("Save failed — will retry automatically. Your change is kept on this screen.");
        }
        setSyncState("offline");
      }
    };
    saveNowRef.current = fire;
    saveTimer.current = setTimeout(fire, SAVE_DEBOUNCE_MS);
    return () => clearTimeout(saveTimer.current);
  }, [weeks, freeSwim, switchRequests, accounts, staff, session, mySelfMap, myLessonsMap]);
  // Watchdog: the badge must never spin forever. If "saving" persists past this
  // window (e.g. some future edit re-arms the debounce in a tight loop, or a
  // request stalls beyond its own timeout), force the badge to a truthful,
  // retryable "offline" state and re-arm the pending payload so the next edit,
  // reconnect, or tap can flush it. This makes an endless spinner structurally
  // impossible regardless of root cause.
  const SYNC_WATCHDOG_MS = 12000;
  const syncStateRef = useRef(syncState);
  useEffect(() => { syncStateRef.current = syncState; }, [syncState]);
  useEffect(() => {
    if (syncState !== "saving") return;
    const t = setTimeout(() => {
      if (syncStateRef.current === "saving") {
        if (profileIsOwner() && !pendingSaveRef.current) {
          stashPending({ weeks, migrations: migrationsRef.current, freeSwim, switchRequests, accounts, staff });
        }
        setSyncNotice("Save is taking too long — tap the badge to retry.");
        setSyncState("offline");
      }
    }, SYNC_WATCHDOG_MS);
    return () => clearTimeout(t);
  }, [syncState]);
  // R3: flush a pending owner save when we regain connectivity or the tab
  // becomes visible again. Reuses the R1 compare-and-set path.
  const flushPending = async () => {
    if (previewingRef.current) return;
    // Warm-start guard: until the first load returns, the server rev is
    // unknown — flushing rev 1 over live data is forbidden. Probe for the rev
    // first; if even the probe fails we're offline and the stash waits.
    if (bootLoadingRef.current) {
      const known = await revProbe();
      if (!known) return;
    }
    if (!pendingSaveRef.current || !profileIsOwner()) return;
    if (typeof navigator !== "undefined" && navigator.onLine === false) return;
    // A debounced save is already scheduled with a payload at least as fresh as
    // the stash — let it do the work instead of double-writing here.
    if (saveTimerArmedRef.current) return;
    // A stash recovered from a PREVIOUS session may be stale: the server may
    // have moved past its base rev (another device saved), or it may simply be
    // old. Auto-flushing then would overwrite newer data, so ask once. A fresh
    // stash (rev unchanged, < 24h old) keeps auto-flushing exactly as before.
    const recovered = recoveredStashRef.current;
    if (recovered) {
      recoveredStashRef.current = null; // ask at most once per recovery
      const DAY_MS = 24 * 36e5;
      const revOk = recovered.baseRev >= 0 && (rosterRevRef.current || 0) <= recovered.baseRev;
      const ageOk = recovered.at > 0 && Date.now() - recovered.at <= DAY_MS;
      if (!revOk || !ageOk) {
        const keep = window.confirm("Recover an unsaved edit from this device? It may replace newer changes made elsewhere.");
        if (!keep) {
          clearPending();
          dirtyRef.current = false;
          // The declined blob was already seeded into local state on warm
          // start — force a full re-adoption so the screen returns to the
          // server's newer truth instead of silently keeping stale data
          // that the next edit would commit.
          rosterRevRef.current = -1;
          setSyncState("loading");
          requestSyncRef.current("stash-declined");
          return;
        }
      }
    }
    setSyncState("saving");
    try {
      await commitOwnerSave(pendingSaveRef.current);
      if (!userEditRef.current) {
        dirtyRef.current = false;
        clearPending();
        setSyncState("saved");
        // A confirmed flush supersedes any lingering failure notice.
        setSyncNotice((n) => typeof n === "string" && n.startsWith("Save failed") ? "" : n);
      }
      justSavedRef.current = Date.now();
    } catch {
      setSyncState("offline");
    }
  };
  const flushPendingRef = useRef(flushPending);
  useEffect(() => { flushPendingRef.current = flushPending; });
  // R3: on mount, recover a pending owner payload dropped by a prior crash/close.
  // We do NOT auto-apply it to state — it's only re-armed so the online/visibility
  // retry (which runs once the row version is loaded) can safely flush it.
  useEffect(() => {
    try {
      const raw = localStorage.getItem("roster_pending");
      if (raw) {
        const parsed = JSON.parse(raw);
        const isEnv = parsed && typeof parsed === "object" && parsed.blob && typeof parsed.blob === "object";
        pendingSaveRef.current = isEnv ? parsed.blob : parsed;
        // Legacy (pre-envelope) stashes have unknown age/rev — the flush treats
        // them as stale and asks before writing over live data.
        recoveredStashRef.current = isEnv
          ? { baseRev: Number(parsed.baseRev) || 0, at: Number(parsed.at) || 0 }
          : { baseRev: -1, at: 0 };
        setSyncState("offline");
      }
    } catch {}
  }, []);
  // R3: once loaded and signed in, attempt to flush any recovered pending payload.
  useEffect(() => {
    if (loadedRef.current && session && pendingSaveRef.current) flushPendingRef.current();
  }, [session, sbVersion]);
  useEffect(() => {
    if (!session) return;
    const onOnline = () => { flushPendingRef.current(); requestSyncRef.current("online"); };
    const onVisible = () => { if (document.visibilityState === "visible") { flushPendingRef.current(); requestSyncRef.current("visible"); } };
    const onBeforeUnload = (e) => {
      // R3: warn the owner if there's an unsynced edit they might lose by leaving.
      if (pendingSaveRef.current) { e.preventDefault(); e.returnValue = ""; return ""; }
    };
    window.addEventListener("online", onOnline);
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => {
      window.removeEventListener("online", onOnline);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("beforeunload", onBeforeUnload);
    };
  }, [session]);
  // ── Global sync engine ──────────────────────────────────────────────────
  // ONE shared refresh path — syncFromServer() — used by four triggers:
  //   1. the 15s poll (reliable backstop, visible tabs only),
  //   2. Supabase Realtime pushes (sub-second propagation between devices),
  //   3. returning to the tab (instant catch-up instead of waiting for a tick),
  //   4. regaining connectivity.
  // requestSync() coalesces bursts (a flurry of realtime events = one fetch),
  // never overlaps runs, and always honors the same dirty/just-saved guards the
  // poll used — so none of the ownership rules proven by the harness change.
  const syncInFlightRef = useRef(false);
  const syncQueuedRef = useRef(false);
  const syncTimerRef = useRef(null);
  const lastSyncAtRef = useRef(0);
  const rtUpRef = useRef(false);
  const SYNC_COALESCE_MS = 800;
  const syncFromServer = async () => {
    if (!loadedRef.current) return;
    // The initial load owns the first fetch; a realtime nudge or reconnect
    // during the warm-start window must not race it with a second adoption.
    if (bootLoadingRef.current) return;
    // Don't refresh on top of an in-flight or just-finished save: that's when
    // the server might momentarily lag our own write. A dirty owner still
    // syncs so other instructors' attendance keeps flowing in (handled below).
    if (!dirtyRef.current && Date.now() - justSavedRef.current < JUST_SAVED_GUARD_MS) return;
    try {
        const row = await loadRosterRow();
        const data = row.data;
        let iw = [];
        try { iw = await loadInstructorWrites(); } catch {}
        // Re-check MY profile at most once a minute so a mid-session disable or
        // role change actually gates this device (DisabledGate reads profile
        // state). A failed lookup must never disrupt the sync itself.
        try {
          if (Date.now() - lastProfileCheckRef.current > 60000) {
            lastProfileCheckRef.current = Date.now();
            const p = await getMyProfile();
            if (p) setProfile((prev) => prev && prev.role === p.role && prev.active === p.active ? prev : p);
          }
        } catch {}
        // Skip the adoption entirely when the payload is byte-identical to the
        // one we last adopted — no 15s whole-tree re-render churn.
        const iwJson = JSON.stringify(iw);
        if (iwJson !== lastIwJsonRef.current) {
          lastIwJsonRef.current = iwJson;
          if (shiftSaveInFlightRef.current && myUserIdRef.current) {
            // A punch save is mid-flight: adopting the server's (older) copy of
            // MY row would revert the optimistic punch, and a second tap on the
            // reverted state can permanently lose the first one. Adopt everyone
            // else's rows; keep my own from current state until the save lands.
            const uid = myUserIdRef.current;
            setInstrWrites((prev) => {
              const prevArr = Array.isArray(prev) ? prev : [];
              const mine = prevArr.find((p) => p && p.user_id === uid);
              const next = iw.map((r) => r && r.user_id === uid ? (mine || r) : r);
              if (mine && !iw.some((r) => r && r.user_id === uid)) next.push(mine);
              return next;
            });
          } else {
            setInstrWrites(iw);
          }
        }
        const owner = profileIsOwner();
        // INSTRUCTOR with an unsaved local edit (or an armed debounce): mirrors
        // the owner guard below. Adopting server weeks/requests now would revert
        // a just-tapped mark, and the armed save would then persist the reverted
        // state — silent permanent loss. instrWrites above is still safe to
        // adopt; the poll right after the save completes adopts everything.
        if (!owner && (instrDirtyRef.current || saveTimerArmedRef.current)) return;
        // OWNER with unsaved local edits (or a queued pending save): never apply
        // server owner-fields and never advance our rev — the pending write must
        // win. Only merge other guards' attendance onto the CURRENT local weeks.
        if (owner && (dirtyRef.current || pendingSaveRef.current)) {
          setWeeks((prev) => {
            const merged = mergeAttendance(prev, iw);
            return JSON.stringify(prev) === JSON.stringify(merged) ? prev : merged;
          });
          return;
        }
        // OWNER, clean: adopt server owner-fields ONLY when the server is a
        // strictly newer revision than ours — i.e. it was edited on another
        // device. Our own just-saved rev equals the server's, so this is a
        // no-op for self-writes (no flicker, no fighting the user). When the
        // server isn't newer we still fold in attendance from instructor_writes.
        if (owner && !(row.rev > rosterRevRef.current)) {
          setWeeks((prev) => {
            const merged = mergeAttendance(prev, iw);
            return JSON.stringify(prev) === JSON.stringify(merged) ? prev : merged;
          });
          return;
        }
        // Either an instructor (who never authors the blob) or the owner seeing
        // genuinely newer server data: adopt it.
        rosterRevRef.current = row.rev || 0;
        lastRosterUpdatedAtRef.current = row.updatedAt;
        // Tell the owner why the screen just changed under them (auto-clears).
        if (owner) flashNotice("Loaded newer roster from another device.");
        if (data && data.weeks && typeof data.weeks === "object") {
          if (Array.isArray(data.migrations)) migrationsRef.current = data.migrations;
          const incoming = {};
          for (const [wk, w] of Object.entries(data.weeks)) {
            incoming[wk] = {
              roster: (Array.isArray(w.roster) ? w.roster : []).map(({ present, ...s }) => s),
              instructors: w.instructors && typeof w.instructors === "object" ? w.instructors : {},
              attendance: w.attendance && typeof w.attendance === "object" ? w.attendance : {}
            };
          }
          const mergedWeeks = mergeAttendance(incoming, iw);
          setWeeks((prev) => JSON.stringify(prev) === JSON.stringify(mergedWeeks) ? prev : mergedWeeks);
          if (data.freeSwim) {
            const fs = sanitizeFreeSwim(data.freeSwim);
            setFreeSwim((prev) => JSON.stringify(prev) === JSON.stringify(fs) ? prev : fs);
          }
          const reqs = mergeRequests(sanitizeSwitchRequests(data.switchRequests), iw);
          setSwitchRequests((prev) => JSON.stringify(prev) === JSON.stringify(reqs) ? prev : reqs);
          const st = sanitizeStaff(data.staff);
          setStaff((prev) => JSON.stringify(prev) === JSON.stringify(st) ? prev : st);
        }
    } catch {
    }
  };
  const syncFromServerRef = useRef(syncFromServer);
  useEffect(() => { syncFromServerRef.current = syncFromServer; });
  const requestSync = (reason) => {
    if (!session) return;
    if (syncInFlightRef.current) { syncQueuedRef.current = true; return; }
    if (syncTimerRef.current) return;
    const wait = reason === "poll" ? 0 : Math.max(0, SYNC_COALESCE_MS - (Date.now() - lastSyncAtRef.current));
    syncTimerRef.current = setTimeout(async () => {
      syncTimerRef.current = null;
      syncInFlightRef.current = true;
      try { await syncFromServerRef.current(); } catch {}
      syncInFlightRef.current = false;
      lastSyncAtRef.current = Date.now();
      if (syncQueuedRef.current) { syncQueuedRef.current = false; requestSyncRef.current(reason); }
    }, wait);
  };
  const requestSyncRef = useRef(requestSync);
  useEffect(() => { requestSyncRef.current = requestSync; });
  // Trigger 1: the 15s backstop poll. Hidden tabs skip it entirely (no battery
  // or data churn in a pocket); the visibility trigger below catches them up
  // the moment they return.
  useEffect(() => {
    if (!session) return;
    const iv = setInterval(() => {
      if (typeof document !== "undefined" && document.hidden) return;
      requestSyncRef.current("poll");
    }, POLL_INTERVAL_MS);
    return () => { clearInterval(iv); clearTimeout(syncTimerRef.current); syncTimerRef.current = null; };
  }, [session]);
  // Trigger 2: Realtime push. Any committed change to the roster blob or any
  // instructor row nudges every connected device to refresh within ~a second.
  // Purely additive: if the channel can't connect (Realtime not enabled, old
  // network, corporate wifi), everything still works on the poll.
  useEffect(() => {
    if (!session) return;
    let ch = null;
    let disposed = false;
    const arm = () => {
      if (disposed) return;
      try {
        if (supa && typeof supa.channel === "function") {
          try { if (ch && typeof supa.removeChannel === "function") supa.removeChannel(ch); } catch {}
          ch = supa.channel("ag-live")
            .on("postgres_changes", { event: "*", schema: "public", table: "roster_data" }, () => requestSyncRef.current("realtime"))
            .on("postgres_changes", { event: "*", schema: "public", table: "instructor_writes" }, () => requestSyncRef.current("realtime"))
            .subscribe((status) => { rtUpRef.current = status === "SUBSCRIBED"; });
        }
      } catch {}
    };
    arm();
    // A dropped socket never recovers on its own (rtUpRef was write-only before
    // sync-31) — re-arm when connectivity returns or the tab comes back, so a
    // wifi blip doesn't silently demote the device to the 15s poll for the
    // rest of the session.
    const rearm = () => { if (!rtUpRef.current) arm(); };
    const onVis = () => { if (document.visibilityState === "visible") rearm(); };
    window.addEventListener("online", rearm);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      disposed = true;
      rtUpRef.current = false;
      window.removeEventListener("online", rearm);
      document.removeEventListener("visibilitychange", onVis);
      try { if (ch && typeof supa.removeChannel === "function") supa.removeChannel(ch); } catch {}
    };
  }, [session]);
  const classKey = (t, l) => `${t}|${l}`;
  useEffect(() => {
    const iv = setInterval(() => {
      const s = currentSlot();
      setNowSlot((prev) => prev === s ? prev : s);
      setClockTick((t) => t + 1);
      try { autoCloseSweepRef.current(); } catch {}
      const todayPst = pstDateKey();
      if (todayPst !== lastPstDateRef.current) {
        const wasOnToday = activeDateRef.current === lastPstDateRef.current;
        // Only silently auto-advance the date when the tab isn't being actively
        // viewed, so a late-evening viewer isn't yanked to an empty next day.
        const hidden = typeof document !== "undefined" && document.hidden;
        if (wasOnToday && hidden) {
          lastPstDateRef.current = todayPst;
          setActiveDate(todayPst);
          const newWk = weekKeyFor(todayPst);
          setWeeks((all) => all[newWk] ? all : { ...all, [newWk]: { roster: [], instructors: {}, attendance: {} } });
        } else if (!wasOnToday) {
          lastPstDateRef.current = todayPst;
        }
      }
    }, SLOT_TICK_MS);
    return () => clearInterval(iv);
  }, []);
  const activeDateRef = useRef(activeDate);
  useEffect(() => {
    activeDateRef.current = activeDate;
  }, [activeDate]);
  const dayClosed = isClosed(activeDate);
  const dayMarks = attendance[activeDate] || {};
  const students = useMemo(
    () => roster.map((s) => ({ ...s, present: !dayClosed && !!dayMarks[s.id] })),
    [roster, dayMarks, dayClosed]
  );
  const grouped = useMemo(() => {
    const q = search.trim().toLowerCase();
    const map = {};
    students.filter((s) => s.time === activeTime).filter((s) => !q || s.name.toLowerCase().includes(q) || s.guardian.toLowerCase().includes(q)).forEach((s) => {
      (map[s.level] = map[s.level] || []).push(s);
    });
    return map;
  }, [students, activeTime, search]);
  const levelsInSlot = LEVELS.filter(
    (l) => grouped[l]?.length || (isOwner && extraClasses.includes(`${activeTime}|${l}`))
  );
  const counts = useMemo(() => {
    const c = {};
    TIME_SLOTS.forEach((t) => c[t] = students.filter((s) => s.time === t).length);
    return c;
  }, [students]);
  const dayStats = useMemo(() => {
    const total = students.length;
    const inSlot = students.filter((s) => s.time === nowSlot);
    const present = inSlot.filter((s) => s.present).length;
    const byLevel = {};
    LEVELS.forEach((l) => {
      const n = students.filter((s) => s.level === l).length;
      if (n) byLevel[l] = n;
    });
    const classes = new Set(students.map((s) => `${s.time}|${s.level}`)).size;
    const presentAll = students.filter((s) => s.present).length;
    const rate = total ? Math.round(presentAll / total * 100) : 0;
    const freeSwim = nowSlot === FREE_SWIM;
    const dayOver = nowSlot === DAY_OVER;
    return { total, present, byLevel, classes, rate, nowSlot, slotTotal: inSlot.length, presentAll, freeSwim, dayOver };
  }, [students, nowSlot]);
  const classGrid = useMemo(() => {
    const cells = {};
    students.forEach((s) => {
      const k = `${s.time}|${s.level}`;
      if (!cells[k]) cells[k] = { time: s.time, level: s.level, count: 0, present: 0 };
      cells[k].count++;
      if (s.present) cells[k].present++;
    });
    return cells;
  }, [students]);
  // Every user-authored mutation calls this (directly or via guard/attendGuard)
  // so the save effect can tell a real edit apart from load/poll adoptions.
  // Owners also raise dirtyRef so the 15s poll won't clobber the unsaved edit.
  const previewBlock = () => {
    if (!previewingRef.current) return false;
    setSyncNotice("Preview mode \u2014 actions are disabled. Tap Exit preview to make changes.");
    return true;
  };
  const markEdit = () => {
    if (previewingRef.current) return;
    userEditRef.current = true;
    if (isOwner) dirtyRef.current = true;
    else instrDirtyRef.current = true;
    // Drives the "Save now" pill: refs don't re-render, state does.
    setHasUnsaved(true);
  };
  const guard = (fn) => (...args) => {
    if (!isOwner) return;
    // Any owner mutation makes local state authoritative until the next confirmed
    // save. Mark dirty synchronously so the 15s poll won't overwrite owner fields
    // (freeSwim/weeks) or advance the version ref before the debounced save runs.
    markEdit();
    fn(...args);
  };
  // Attendance is allowed for the owner AND instructors (their core task).
  const attendGuard = (fn) => (...args) => {
    if (!isOwner && !isInstructor) return;
    if (previewBlock()) return;
    markEdit();
    fn(...args);
  };
  const togglePresent = attendGuard((id) => {
    if (dayClosed) return;
    // Remember which marks THIS instructor authored (and un-authored) in this
    // session, so their saved row only re-asserts their own work.
    if (!isOwner) {
      const key = `${activeWeek}|${activeDate}|${id}`;
      const marked = !!((attendance[activeDate] || {})[id]);
      if (marked) myAuthoredMarksRef.current.delete(key);
      else myAuthoredMarksRef.current.add(key);
    }
    setAttendance((p) => {
      const day = { ...p[activeDate] || {} };
      if (day[id]) delete day[id];
      else day[id] = true;
      return { ...p, [activeDate]: day };
    });
  });
  const removeStudent = guard((id) => {
    // confirm destructive delete
    const target = roster.find((s) => s.id === id);
    const nm = target && target.name ? target.name : "this swimmer";
    if (!window.confirm(`Remove ${nm} from the roster? This can't be undone.`)) return;
    setRoster((p) => p.filter((s) => s.id !== id));
  });
  const addClass = guard((time, level) => {
    const k = `${time}|${level}`;
    setExtraClasses((p) => p.includes(k) ? p : [...p, k]);
  });
  const addStudent = guard((time, level, fields) => {
    const name = (fields.name || "").trim();
    if (!name) return;
    const parsedAge = Number(fields.age);
    const age = Number.isFinite(parsedAge) && parsedAge >= 0 ? parsedAge : 0;
    setRoster((p) => [
      ...p,
      {
        id: `add-${Date.now()}`,
        name,
        guardian: (fields.guardian || "").trim(),
        age,
        level,
        time,
        balance: 0,
        note: ""
      }
    ]);
  });
  const updateNote = guard((id, note) => setRoster((p) => p.map((s) => s.id === id ? { ...s, note } : s)));
  // TEST HOOK (inert in production): only when a harness sets window.__AG_TEST__
  // BEFORE the app loads, expose the minimal handles automated sync tests need.
  // Regular visitors never set that flag, so this effect does nothing for them.
  useEffect(() => {
    if (typeof window === "undefined" || !window.__AG_TEST__) return;
    window.__agTestApi = {
      togglePresent,
      updateNote,
      answerSelfCheckIn,
      enterPreview,
      exitPreview,
      ownerRestoreBackup,
      listRosterBackups,
      buildSeasonExport: () => buildSeasonExport({ weeks, freeSwim, switchRequests, accounts, staff, instrRows: instrWrites }),
      quickAdd: (uid, day, ms) => ownerAdjustShifts(uid, (cur) => quickAddBlock(cur, day, ms)),
      quickSub: (uid, day, ms) => ownerAdjustShifts(uid, (cur) => quickSubtract(cur, day, ms)),
      punchClock,
      ownerAdjustShifts,
      getShifts: () => ({ mine: myShifts, open: myOpenShift, all: shiftRowsOf(instrWrites).map((r) => ({ user_id: r.user_id, shifts: sanitizeShifts(r.shifts) })) }),
      getState: () => ({
        previewing,
        syncState,
        rev: rosterRevRef.current,
        dirty: dirtyRef.current,
        pendingInStorage: (() => { try { return !!localStorage.getItem("roster_pending"); } catch { return false; } })(),
        weeks
      })
    };
  });
  const editStudent = guard((id, fields) => {
    const name = (fields.name || "").trim();
    if (!name) return;
    const rawAge = String(fields.age == null ? "" : fields.age).trim();
    const parsedAge = Number(rawAge);
    const validAge = rawAge !== "" && Number.isFinite(parsedAge) && parsedAge >= 0;
    setRoster(
      (p) => p.map(
        // Keep the prior age when the new value is blank/NaN/negative; don't silently zero it.
        (s) => s.id === id ? { ...s, name, guardian: (fields.guardian || "").trim(), age: validAge ? parsedAge : s.age } : s
      )
    );
  });
  const moveStudent = guard((id, time, level) => setRoster((p) => p.map((s) => s.id === id ? { ...s, time, level } : s)));
  // Import reviewed swimmers from a roster scan into weeks[targetWeek].roster.
  // Each row uses the SAME shape + id scheme as addStudent. Dedupe: skip a
  // swimmer already in that week with the same normalized name + level + time.
  // Returns { added, skipped } so the modal can show a summary.
  const importScannedStudents = guard((targetWeek, rows) => {
    const result = { added: 0, skipped: 0 };
    const list = Array.isArray(rows) ? rows : [];
    if (!targetWeek || list.length === 0) return result;
    setWeeks((all) => {
      const wk = all[targetWeek] || { roster: [], instructors: {}, attendance: {} };
      const existing = Array.isArray(wk.roster) ? wk.roster : [];
      // Seed the dedupe set with what's already in the target week, then grow it
      // as we add so duplicates WITHIN the scan batch are skipped too.
      const seen = new Set(existing.map((s) => `${normName(s.name)}|${s.level}|${s.time}`));
      const additions = [];
      let i = 0;
      list.forEach((r) => {
        const name = String(r.name || "").trim();
        const level = String(r.level || "").trim();
        const time = String(r.time || "").trim();
        if (!name || !level || !time) { result.skipped++; return; }
        const key = `${normName(name)}|${level}|${time}`;
        if (seen.has(key)) { result.skipped++; return; }
        seen.add(key);
        const parsedAge = Number(r.age);
        const age = Number.isFinite(parsedAge) && parsedAge >= 0 ? parsedAge : 0;
        const parsedBal = Number(r.balance);
        const balance = Number.isFinite(parsedBal) && parsedBal >= 0 ? parsedBal : 0;
        additions.push({
          // Unique id even when many land in the same ms (Date.now collides).
          id: `add-${Date.now()}-${i++}`,
          name,
          guardian: String(r.guardian || "").trim(),
          age,
          level,
          time,
          balance,
          note: ""
        });
        result.added++;
      });
      if (additions.length === 0) return all;
      return { ...all, [targetWeek]: { ...wk, roster: [...existing, ...additions] } };
    });
    return result;
  });
  const reqMeta = () => ({
    by: myName || "Instructor",
    byId: myUserId || "",
    week: activeWeek,
    status: "pending",
    createdAt: Date.now(),
    decidedAt: 0
  });
  const newReqId = () => `req-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  // Best-effort ping to every admin device that turned notifications on (ids
  // travel in staff.adminIds). The in-app pending badge is the guaranteed path
  // if push isn't set up. No student names in push text — it hits lock screens.
  const pingAdmins = (title, body) => {
    const admins = (staff && Array.isArray(staff.adminIds) ? staff.adminIds : []).filter((id) => id && id !== myUserId);
    admins.forEach((id) => sendPush(id, title, body));
  };
  const requestSwitch = (id, time, level, reason) => {
    if (previewBlock()) return;
    markEdit();
    const stu = roster.find((s) => s.id === id);
    if (!stu) return;
    const req = { id: newReqId(), kind: "switch", studentId: id, studentName: stu.name, fromTime: stu.time, fromLevel: stu.level, toTime: time, toLevel: level, reason: (reason || "").trim(), ...reqMeta() };
    setSwitchRequests((p) => [req, ...p]);
    pingAdmins("Switch requested", `${myName || "An instructor"} asked to move a swimmer — open Requests to review.`);
  };
  const requestPickup = (time, level, reason) => {
    if (previewBlock()) return;
    markEdit();
    const req = { id: newReqId(), kind: "pickup", toTime: time, toLevel: level, reason: (reason || "").trim(), ...reqMeta() };
    setSwitchRequests((p) => [req, ...p]);
    pingAdmins("Pick-up requested", `${myName || "An instructor"} asked to pick up ${time} ${level} — open Requests to review.`);
  };
  const requestDrop = (time, level, reason) => {
    if (previewBlock()) return;
    markEdit();
    const req = { id: newReqId(), kind: "drop", fromTime: time, fromLevel: level, reason: (reason || "").trim(), ...reqMeta() };
    setSwitchRequests((p) => [req, ...p]);
    pingAdmins("Drop requested", `${myName || "An instructor"} asked to drop ${time} ${level} — open Requests to review.`);
  };
  // Tap-to-trade: requester gives up their (fromTime/fromLevel) class and wants
  // the target (toTime/toLevel) class currently taught by withName. On approval
  // the two instructors swap classes.
  const requestTrade = (fromTime, fromLevel, toTime, toLevel, withName, reason) => {
    if (previewBlock()) return;
    markEdit();
    const req = { id: newReqId(), kind: "trade", fromTime, fromLevel, toTime, toLevel, withName: (withName || "").trim(), reason: (reason || "").trim(), ...reqMeta() };
    setSwitchRequests((p) => [req, ...p]);
    pingAdmins("Shift trade requested", `${myName || "An instructor"} proposed a shift trade — open Requests to review.`);
  };
  // Arrival-time fix: staff propose a new clock-in for one of their own shifts;
  // nothing changes until an admin approves it in the requests dialog. The
  // shift's own day picks the request week — never the week being viewed.
  const requestTimeEdit = (shiftId, day, oldIn, newIn, reason) => {
    if (previewBlock()) return;
    markEdit();
    const req = { id: newReqId(), kind: "timeEdit", shiftId, day, oldIn, newIn, reason: (reason || "").trim(), ...reqMeta(), week: weekKeyFor(day) };
    setSwitchRequests((p) => [req, ...p]);
    pingAdmins("Clock-in fix requested", `${myName || "An instructor"} asked to change an arrival time — open Requests to approve or decline.`);
  };
  // Fix the daily "which lessons do I have" answer — admin approves before the
  // schedule changes. fromSlots/toSlots are comma-joined TIME_SLOTS strings.
  const requestLessonEdit = (day, fromSlots, toSlots, reason) => {
    if (previewBlock()) return;
    markEdit();
    const req = { id: newReqId(), kind: "lessonEdit", day, fromSlots: String(fromSlots || ""), toSlots: String(toSlots || ""), reason: (reason || "").trim(), ...reqMeta(), week: weekKeyFor(day) };
    setSwitchRequests((p) => [req, ...p]);
    pingAdmins("Lessons change requested", `${myName || "An instructor"} asked to change their lessons for the day — open Requests to approve or decline.`);
  };
  const approveSwitch = (reqId) => {
    if (!isOwner) return;
    markEdit();
    const req = switchRequests.find((r) => r.id === reqId);
    if (!req) return;
    if (req.kind === "lessonEdit") {
      // Applies to the requester's own row (attendance.__lessons[day]); their
      // device also adopts the approved value so its next save keeps it.
      const prevStatus3 = req.status, prevDecidedAt3 = req.decidedAt;
      setSwitchRequests((p) => p.map((r) => r.id === reqId ? { ...r, status: "approved", decidedAt: Date.now() } : r));
      (async () => {
        try {
          const nextAtt = await ownerSetDayLessons(instrWrites, req.byId, req.day, req.toSlots);
          setInstrWrites((rows) => (Array.isArray(rows) ? rows : []).map((r) => r && r.user_id === req.byId ? { ...r, attendance: nextAtt } : r));
          await ownerSetRequestStatus(instrWrites, reqId, "approved");
          if (req.byId) sendPush(req.byId, "Lessons change approved ✅", `Your lessons for ${prettyDate(req.day)} were updated.`);
        } catch (e) {
          markEdit();
          setSwitchRequests((p) => p.map((r) => r.id === reqId ? { ...r, status: prevStatus3, decidedAt: prevDecidedAt3 } : r));
          setSyncNotice("Couldn't save the lessons change. Please try again.");
        }
      })();
      return;
    }
    if (req.kind === "timeEdit") {
      // Applies to the requester's own shift row, not the roster weeks.
      // Validate against the CURRENT shift: sanitizeShifts silently drops any
      // shift whose out <= in, so a stale newIn must never reach the write.
      const curShifts = sanitizeShifts((shiftRowsOf(instrWrites).find((r2) => r2 && r2.user_id === req.byId) || {}).shifts);
      const target = curShifts.find((s) => s.id === req.shiftId);
      if (!target) { setSyncNotice("That shift no longer exists — decline the request instead."); return; }
      if (!(req.newIn > 0) || req.newIn >= (target.out || Date.now())) { setSyncNotice("That new time no longer fits the shift — decline it, or edit the shift by hand in Hours."); return; }
      const prevStatus2 = req.status, prevDecidedAt2 = req.decidedAt;
      setSwitchRequests((p) => p.map((r) => r.id === reqId ? { ...r, status: "approved", decidedAt: Date.now() } : r));
      (async () => {
        const res = await ownerAdjustShifts(req.byId, (list) => list.map((s) => s.id === req.shiftId ? { ...s, in: req.newIn } : s));
        if (!res || !res.ok) {
          markEdit();
          setSwitchRequests((p) => p.map((r) => r.id === reqId ? { ...r, status: prevStatus2, decidedAt: prevDecidedAt2 } : r));
          setSyncNotice((res && res.error) || "Couldn't save the time fix. Please try again.");
          return;
        }
        try {
          await ownerSetRequestStatus(instrWrites, reqId, "approved");
          if (req.byId) sendPush(req.byId, "Time fix approved ✅", `Your clock-in was updated to ${fmtPunchTime(req.newIn)}.`);
        } catch (e) {
          // The shift fix is saved; only the status write failed. Revert the
          // optimistic status like the other kinds — re-approving just writes
          // the same absolute time again, so it's safe.
          markEdit();
          setSwitchRequests((p) => p.map((r) => r.id === reqId ? { ...r, status: prevStatus2, decidedAt: prevDecidedAt2 } : r));
          setSyncNotice("Couldn't save the approval. Please try again.");
        }
      })();
      return;
    }
    setWeeks((all) => {
      const wk = all[req.week];
      if (!wk) return all;
      if (req.kind === "switch") {
        const roster2 = (wk.roster || []).map((s) => s.id === req.studentId ? { ...s, time: req.toTime, level: req.toLevel } : s);
        return { ...all, [req.week]: { ...wk, roster: roster2 } };
      }
      if (req.kind === "pickup" && req.by) {
        const k = `${req.toTime}|${req.toLevel}`;
        const inst = { ...wk.instructors || {} };
        const list = Array.isArray(inst[k]) ? inst[k].slice() : [];
        if (!list.some((n) => normName(n) === normName(req.by))) list.push(req.by);
        inst[k] = list;
        return { ...all, [req.week]: { ...wk, instructors: inst } };
      }
      if (req.kind === "drop" && req.by) {
        const k = `${req.fromTime}|${req.fromLevel}`;
        const inst = { ...wk.instructors || {} };
        const list = Array.isArray(inst[k]) ? inst[k].filter((n) => normName(n) !== normName(req.by)) : [];
        inst[k] = list;
        return { ...all, [req.week]: { ...wk, instructors: inst } };
      }
      if (req.kind === "trade" && req.by) {
        const fromK = `${req.fromTime}|${req.fromLevel}`;
        const toK = `${req.toTime}|${req.toLevel}`;
        const inst = { ...wk.instructors || {} };
        const me = req.by, them = req.withName;
        // Requester leaves their class, joins the target class.
        let fromList = (Array.isArray(inst[fromK]) ? inst[fromK] : []).filter((n) => normName(n) !== normName(me));
        let toList = (Array.isArray(inst[toK]) ? inst[toK] : []).filter((n) => normName(n) !== normName(them));
        if (!toList.some((n) => normName(n) === normName(me))) toList.push(me);
        // Target instructor (if named) takes the requester's old class.
        if (them && !fromList.some((n) => normName(n) === normName(them))) fromList.push(them);
        inst[fromK] = fromList;
        inst[toK] = toList;
        return { ...all, [req.week]: { ...wk, instructors: inst } };
      }
      return all;
    });
    const prev = switchRequests.find((r) => r.id === reqId);
    const prevStatus = prev ? prev.status : "pending";
    const prevDecidedAt = prev ? prev.decidedAt : 0;
    setSwitchRequests((p) => p.map((r) => r.id === reqId ? { ...r, status: "approved", decidedAt: Date.now() } : r));
    (async () => {
      try {
        await ownerSetRequestStatus(instrWrites, reqId, "approved");
        if (prev && prev.byId) sendPush(prev.byId, "Request approved \u2705", "Your shift request was approved \u2014 check My Lessons.");
      } catch (e) {
        // Revert the optimistic status; the roster/instructor change above is left
        // applied (reverting it cleanly is entangled). Owner can re-approve.
        markEdit();
        setSwitchRequests((p) => p.map((r) => r.id === reqId ? { ...r, status: prevStatus, decidedAt: prevDecidedAt } : r));
        setSyncNotice("Couldn't save the approval. Please try again.");
      }
    })();
  };
  const rejectSwitch = (reqId) => {
    if (!isOwner) return;
    markEdit();
    const prev = switchRequests.find((r) => r.id === reqId);
    const prevStatus = prev ? prev.status : "pending";
    const prevDecidedAt = prev ? prev.decidedAt : 0;
    setSwitchRequests((p) => p.map((r) => r.id === reqId ? { ...r, status: "rejected", decidedAt: Date.now() } : r));
    (async () => {
      try {
        await ownerSetRequestStatus(instrWrites, reqId, "rejected");
        if (prev && prev.byId) sendPush(prev.byId, "Request declined", "Your shift request wasn't approved \u2014 check the app.");
      } catch (e) {
        markEdit();
        setSwitchRequests((p) => p.map((r) => r.id === reqId ? { ...r, status: prevStatus, decidedAt: prevDecidedAt } : r));
        setSyncNotice("Couldn't save the rejection. Please try again.");
      }
    })();
  };
  const clearDecidedRequests = () => {
    if (!isOwner) return;
    markEdit();
    setSwitchRequests((p) => p.filter((r) => r.status === "pending"));
  };
  // Map a raw profiles row to the shape the AccountsDialog renders. `created_at`
  // is carried through so the dialog can disambiguate duplicate names (there's
  // no email column on profiles).
  const toAccount = (p) => ({ id: p.id, name: p.username, active: p.active !== false, role: p.role === "owner" ? "owner" : "instructor", createdAt: p.created_at || null });
  // Re-fetch profiles and reconcile local state — the server is the source of
  // truth, so any optimistic update gets corrected here. Bounded by a 10s
  // timeout so a hung request can't hang the caller. Returns true on success;
  // on failure surfaces a non-fatal note and returns false (caller decides what
  // to tell the user) instead of swallowing the error silently.
  const refreshAccounts = async () => {
    try {
      const profs = await withTimeout(loadAllProfiles(), ACCOUNT_REFRESH_TIMEOUT_MS, "Couldn't refresh the account list — pull to reload to see the latest.");
      setAccounts(profs.filter((p) => p.id !== myUserId).map(toAccount));
      return true;
    } catch (e) {
      setSyncNotice("Couldn't refresh the account list. Reload to see the latest.");
      return false;
    }
  };
  const addAccount = async (name, email, password, role) => {
    if (!isOwner) return { ok: false, error: "Not authorized." };
    const nm = (name || "").trim();
    const em = (email || "").trim();
    const pwOk = String(password || "").length >= 8;
    if (!nm) return { ok: false, error: "Enter a name." };
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) return { ok: false, error: "Enter a valid email." };
    if (!pwOk) return { ok: false, error: "Password must be at least 8 characters." };
    try {
      await ownerCreateInstructor(nm, em, password, role);
      // Account created — success is instant. Refresh the list in the BACKGROUND
      // so a slow or failed profile refresh can't leave the button stuck on
      // "Creating…". The refresh now reliably re-fetches (it has its own 10s
      // timeout) and reconciles; if it can't, refreshAccounts surfaces a
      // non-fatal note so the list is never silently stale.
      setTimeout(() => { refreshAccounts(); }, 600);
      return { ok: true };
    } catch (e) {
      const msg = String(e && e.message || e);
      if (/already registered|already been/i.test(msg)) return { ok: false, error: "That email already has an account." };
      return { ok: false, error: msg };
    }
  };
  // Rename and/or enable-disable. Optimistic: update local state immediately for
  // snappiness, then re-fetch to reconcile (server wins). On failure, revert the
  // optimistic change so the displayed state matches the server, and surface a
  // friendly error. Returns a short success note for the dialog to confirm.
  const updateAccount = async (id, fields) => {
    if (!isOwner) return { ok: false, error: "Not authorized." };
    markEdit();
    const prev = accounts.find((a) => a.id === id);
    const nextName = typeof fields.name === "string" && fields.name.trim() ? fields.name.trim() : null;
    const hasActive = typeof fields.active === "boolean";
    setAccounts((p) => p.map((a) => a.id === id ? { ...a, ...(nextName ? { name: nextName } : {}), ...(hasActive ? { active: fields.active } : {}) } : a));
    try {
      if (nextName) await ownerRenameProfile(id, nextName);
      if (hasActive) await ownerSetProfileActive(id, fields.active);
      // Shared name layer: once the profile rename succeeds, propagate the new
      // name to every other reference (lessons, free-swim guard/manual, staff)
      // so a single rename updates everywhere with no orphaned old names.
      if (nextName && prev && normName(prev.name) !== normName(nextName)) renamePerson(prev.name, nextName);
      await refreshAccounts();
      const note = nextName ? `Renamed to ${nextName}.` : hasActive ? (fields.active ? `${prev ? prev.name : "Account"} enabled.` : `${prev ? prev.name : "Account"} disabled.`) : "";
      return { ok: true, note };
    } catch (e) {
      // Revert the optimistic change — the server rejected it.
      markEdit();
      if (prev) setAccounts((p) => p.map((a) => a.id === id ? prev : a));
      return { ok: false, error: friendlyAccountError(e) };
    }
  };
  const removeAccount = async (id) => {
    if (!isOwner) return { ok: false, error: "Not authorized." };
    // Deleting an auth user requires admin privileges (service role), which the
    // browser must never hold. Disable the account instead — it blocks sign-in.
    return updateAccount(id, { active: false });
  };
  // delete account: hard-delete via the owner-gated Edge Function (service role).
  // The auth-user delete cascades to their profile + instructor_writes rows.
  // Optimistic: drop the row immediately, then reconcile; restore it on failure.
  const deleteAccount = async (id) => {
    if (!isOwner) return { ok: false, error: "Not authorized." };
    markEdit();
    const prev = accounts.find((a) => a.id === id);
    setAccounts((p) => p.filter((a) => a.id !== id));
    try {
      await ownerDeleteAccount(id);
      await refreshAccounts();
      return { ok: true, note: prev ? `Removed ${prev.name}.` : "Account removed." };
    } catch (e) {
      // Restore the row — the delete didn't go through.
      markEdit();
      if (prev) setAccounts((p) => p.some((a) => a.id === id) ? p : [...p, prev]);
      return { ok: false, error: friendlyAccountError(e) };
    }
  };
  const exportCSV = (scope) => {
    const rows = (scope === "day" ? students : students.filter((s) => s.time === scope)).slice();
    // Say WHY nothing happened instead of a silent no-op.
    if (!rows.length) { flashNotice("Nothing to export for this slot yet."); return; }
    rows.sort((a2, b) => TIME_SLOTS.indexOf(a2.time) - TIME_SLOTS.indexOf(b.time) || LEVELS.indexOf(a2.level) - LEVELS.indexOf(b.level) || a2.name.localeCompare(b.name));
    const head = ["Time", "Level", "Swimmer", "Age", "Parent/Guardian", "Instructors", "Present", "Balance", "Note"];
    const esc = (v) => {
      let str = String(v ?? "");
      // Formula-injection guard: a leading = + - @ (or tab/CR) can execute in
      // Excel/Sheets. Prefix with a single quote so it's treated as text.
      if (/^[=+\-@\t\r]/.test(str)) str = "'" + str;
      return `"${str.replace(/"/g, '""')}"`;
    };
    const lines = rows.map(
      (s) => [
        s.time,
        s.level,
        s.name,
        s.age,
        s.guardian,
        (instructors[classKey(s.time, s.level)] || []).join(" / "),
        s.present ? "Yes" : "No",
        s.balance ? `$${s.balance.toFixed(2)}` : "$0.00",
        s.note || ""
      ].map(esc).join(",")
    );
    const csv = [head.map(esc).join(","), ...lines].join("\n");
    // UTF-8 BOM so Excel decodes accents/emoji instead of mangling them.
    const blob = new Blob([String.fromCharCode(65279) + csv], { type: "text/csv" }); // 65279 = U+FEFF byte-order mark
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `swim-roster-${activeDate}-${scope === "day" ? "full-day" : scope}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const printSheet = (scope) => {
    const slots = scope === "day" ? TIME_SLOTS : [scope];
    const all = students.filter((s) => slots.includes(s.time));
    // Say WHY nothing happened instead of a silent no-op.
    if (!all.length) { flashNotice("Nothing to print for this slot yet."); return; }
    const date = (() => {
      const [y, m, dd] = activeDate.split("-").map(Number);
      return new Date(y, m - 1, dd).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" });
    })();
    function esc(v) {
      return String(v ?? "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]);
    }
    const slotBlocks = slots.map((slot) => {
      const rows = all.filter((s) => s.time === slot);
      if (!rows.length) return "";
      const byLevel = {};
      rows.forEach((s) => (byLevel[s.level] = byLevel[s.level] || []).push(s));
      const levelBlocks = LEVELS.filter((l) => byLevel[l]?.length).map((level) => {
        const inst = (instructors[classKey(slot, level)] || []).map((n) => esc(n)).join(" / ") || "\u2014";
        const list = byLevel[level].map((s) => `<tr><td class="chk"></td><td>${esc(s.name)}</td><td>${esc(s.age)}</td><td>${esc(s.guardian)}</td><td>${esc(s.note || "")}</td></tr>`).join("");
        return `<section><h2>${esc(level)} <span>\xB7 ${inst}</span></h2>
              <table><thead><tr><th class="chk">\u2713</th><th>Swimmer</th><th>Age</th><th>Parent / Guardian</th><th>Notes</th></tr></thead>
              <tbody>${list}</tbody></table></section>`;
      }).join("");
      const slotHeader = scope === "day" ? `<div class="slot-head">${slot}</div>` : "";
      return `<div class="slot">${slotHeader}${levelBlocks}</div>`;
    }).join("");
    const title = scope === "day" ? "Full day" : scope;
    const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Attendance \u2014 ${title}</title>
      <style>
        body{font-family:-apple-system,system-ui,sans-serif;color:var(--text,#0A2233);margin:32px;}
        header{display:flex;justify-content:space-between;align-items:baseline;border-bottom:3px solid #0B3C5D;padding-bottom:10px;margin-bottom:18px;}
        h1{font-size:22px;margin:0;color:#0B3C5D;} .meta{font-size:13px;color:var(--muted,#5B7A88);}
        .slot{margin-bottom:30px;} .slot-head{font-size:18px;font-weight:800;color:#1D7A8C;border-bottom:2px solid #2DD4BF;padding-bottom:4px;margin:0 0 12px;}
        .slot+.slot{break-before:page;}
        section{margin-bottom:20px;break-inside:avoid;}
        h2{font-size:15px;background:#0B3C5D;color:#fff;padding:6px 12px;border-radius:6px;margin:0 0 8px;}
        h2 span{font-weight:400;opacity:.85;}
        table{width:100%;border-collapse:collapse;font-size:13.5px;}
        th,td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--border,#DCE6E8);}
        th{font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted,#5B7A88);}
        .chk{width:34px;text-align:center;} td.chk{border:1px solid var(--faint,#B9CDD3);height:26px;}
        @media print{body{margin:14px;} button{display:none;}}
      </style></head><body>
      <header><h1>LMUSD Summer Swim 2026</h1><div class="meta">${title} \xB7 ${date}</div></header>
      ${slotBlocks}
      <button id="pbtn" style="margin-top:16px;padding:10px 18px;background:#0B3C5D;color:#fff;border:none;border-radius:8px;font-size:14px;cursor:pointer;">Print</button>
      </body></html>`;
    const w = window.open("", "_blank");
    if (w) {
      w.document.write(html);
      w.document.close();
      // Wire the button from THIS window: the popup inherits our CSP, which no
      // longer allows inline handlers, so an onclick attribute would be blocked.
      try { const b = w.document.getElementById("pbtn"); if (b) b.addEventListener("click", () => w.print()); } catch {}
    } else {
      // Common in iOS standalone mode — explain instead of doing nothing.
      flashNotice("Pop-up blocked — allow pop-ups to print.");
    }
  };
  const addInstructor = guard((t, l, name) => {
    if (!name.trim()) return;
    setInstructors((p) => {
      const k = classKey(t, l);
      return { ...p, [k]: [...p[k] || [], name.trim()] };
    });
  });
  const removeInstructor = guard((t, l, idx) => {
    // confirm destructive delete
    const list = instructors[classKey(t, l)] || [];
    const nm = list[idx] || "this instructor";
    if (!window.confirm(`Remove instructor ${nm}?`)) return;
    setInstructors((p) => {
      const k = classKey(t, l);
      return { ...p, [k]: (p[k] || []).filter((_, i) => i !== idx) };
    });
  });
  const startFreeSwim = guard((ms) => setFreeSwim((f) => ({ ...f, startedAt: ms })));
  const stopFreeSwim = guard(() => setFreeSwim((f) => ({ ...f, startedAt: 0 })));
  const addGuard = guard((name) => {
    const n = (name || "").trim();
    if (!n) return;
    setFreeSwim((f) => f.guards.includes(n) ? f : { ...f, guards: [...f.guards, n] });
  });
  const removeGuard = guard((idx) => {
    // confirm destructive delete
    const nm = (freeSwim.guards && freeSwim.guards[idx]) || "this guard";
    if (!window.confirm(`Remove ${nm} from the rotation?`)) return;
    setFreeSwim((f) => {
      const name = f.guards[idx];
      return { ...f, guards: f.guards.filter((_, i) => i !== idx), onDuty: f.onDuty.filter((g) => g !== name) };
    });
  });
  const moveGuard = guard((idx, dir) => setFreeSwim((f) => {
    const arr = f.guards.slice();
    const j = idx + dir;
    if (j < 0 || j >= arr.length) return f;
    const tmp = arr[idx];
    arr[idx] = arr[j];
    arr[j] = tmp;
    return { ...f, guards: arr };
  }));
  // Toggle a person on/off duty. If they're a role-lifeguard who isn't yet in the
  // guard roster, putting them on duty also adds them to guards so the rotation
  // (activeGuards = guards on the onDuty list) includes them. Taking them off duty
  // leaves the roster intact (removal stays an explicit Edit-roster action).
  const toggleOnDuty = guard((name) => setFreeSwim((f) => {
    const isOn = (f.onDuty || []).includes(name);
    if (isOn) return { ...f, onDuty: f.onDuty.filter((g) => g !== name) };
    const inRoster = (f.guards || []).some((g) => normName(g) === normName(name));
    return {
      ...f,
      guards: inRoster ? f.guards : [...(f.guards || []), name],
      onDuty: [...(f.onDuty || []), name]
    };
  }));
  // "All on" puts every candidate (roster + role-lifeguards) on duty, adding any
  // role-only people to the roster so they actually rotate. "Clear" empties onDuty.
  const setAllDuty = guard((on) => setFreeSwim((f) => {
    if (!on) return { ...f, onDuty: [] };
    const guards = (f.guards || []).slice();
    (guardCandidates || []).forEach((n) => {
      if (!guards.some((g) => normName(g) === normName(n))) guards.push(n);
    });
    return { ...f, guards, onDuty: guards.slice() };
  }));
  const setStationCount = guard((n) => setFreeSwim((f) => ({
    ...f,
    stations: n === 2 ? ["Shallow End", "Diving / Deep End"] : DEFAULT_STATIONS.slice()
  })));
  const setGroupMin = guard((n) => setFreeSwim((f) => ({ ...f, groupMin: n === 15 ? 15 : 30 })));
  const setScheduleMode = guard((m) => setFreeSwim((f) => {
    if (m !== "manual") return { ...f, mode: "auto" };
    const stations = f.stations && f.stations.length ? f.stations : DEFAULT_STATIONS;
    const active = (f.guards || []).filter((g) => (f.onDuty || []).includes(g));
    const blockLen = f.groupMin === 15 ? 1 : 2;
    const hasManual = Array.isArray(f.manual) && f.manual.length;
    const manual = hasManual ? f.manual : buildManualFromAuto(active, stations, blockLen);
    return { ...f, mode: "manual", manual };
  }));
  const fillManualFromAuto = guard(() => setFreeSwim((f) => {
    const stations = f.stations && f.stations.length ? f.stations : DEFAULT_STATIONS;
    const active = (f.guards || []).filter((g) => (f.onDuty || []).includes(g));
    const blockLen = f.groupMin === 15 ? 1 : 2;
    return { ...f, manual: buildManualFromAuto(active, stations, blockLen) };
  }));
  const setManualCell = guard((period, idx, name) => {
    // Mark dirty immediately (not in the post-render save effect) so the 15s poll
    // can't overwrite freeSwim / advance the version ref before this save fires.
    if (profileIsOwner()) dirtyRef.current = true;
    setFreeSwim((f) => {
      const rows = Array.isArray(f.manual) ? f.manual.map((r) => Array.isArray(r) ? r.slice() : []) : [];
      while (rows.length < FREE_SWIM_PERIODS) rows.push([]);
      const row = rows[period] ? rows[period].slice() : [];
      row[idx] = name || null;
      rows[period] = row;
      return { ...f, manual: rows };
    });
  });
  // ---- Self check-in: instructors answer "are you here today?" and the answer
  // lives in their own instructor_writes.attendance.__self. The owner can't write
  // it, so we MERGE every row's __self[activeDate] into staff presence, keyed by
  // the account's display name (user_id -> accounts.username -> normName). ----
  const selfPresence = useMemo(() => {
    const byName = {};
    const lessonsByName = {}; // "which lessons today" answers, same name keys
    const unlinked = [];
    // Candidate staff names (same sources as staffList) for smart linking.
    const candidates = [];
    (accounts || []).forEach((a) => { if (a && a.name && a.name.trim()) candidates.push(a.name.trim()); });
    ((freeSwim && freeSwim.guards) || []).forEach((g) => { if (g && String(g).trim()) candidates.push(String(g).trim()); });
    ((staff && staff.extra) || []).forEach((e) => { if (e && e.name && e.name.trim()) candidates.push(e.name.trim()); });
    const candNorm = new Set(candidates.map((n) => normName(n)));
    const firstOf = (n) => normName(String(n).trim().split(/\s+/)[0] || "");
    (Array.isArray(instrWrites) ? instrWrites : []).forEach((row) => {
      const self = row && row.attendance && typeof row.attendance === "object" ? row.attendance[SELF_KEY] : null;
      const mark = self && typeof self === "object" ? self[activeDate] : null;
      if (mark !== "present" && mark !== "absent") return;
      const lesMap = row.attendance[LESSONS_KEY];
      const dayLessons = lesMap && typeof lesMap === "object" && typeof lesMap[activeDate] === "string" ? lesMap[activeDate] : null;
      // Resolution chain: the account's current username, else the name the
      // instructor's own device stamped onto the row when they answered.
      const acct = (accounts || []).find((a) => a.id === row.user_id);
      const travelling = row.attendance && typeof row.attendance[NAME_KEY] === "string" ? row.attendance[NAME_KEY].trim() : "";
      const rawName = (acct && acct.name && acct.name.trim()) || travelling;
      if (rawName && candNorm.has(normName(rawName))) { byName[normName(rawName)] = mark; if (dayLessons != null) lessonsByName[normName(rawName)] = dayLessons; return; }
      // First-name link: attach to a staff name iff EXACTLY ONE candidate
      // shares the first name (same rule the lesson linker uses).
      if (rawName) {
        const fn = firstOf(rawName);
        const matches = candidates.filter((c) => firstOf(c) === fn);
        if (fn && matches.length === 1) { byName[normName(matches[0])] = mark; if (dayLessons != null) lessonsByName[normName(matches[0])] = dayLessons; return; }
      }
      // Couldn't attach: surface it so the owner can fix the account name,
      // instead of the answer silently doing nothing.
      unlinked.push({ label: rawName || `an unnamed account (id ${String(row.user_id || "").slice(0, 6)})`, mark });
    });
    return { byName, lessonsByName, unlinked };
  }, [instrWrites, accounts, freeSwim, staff, activeDate]);
  const selfPresenceByName = selfPresence.byName;
  const selfLessonsByName = selfPresence.lessonsByName;
  const unlinkedCheckIns = selfPresence.unlinked;
  // Answer the self check-in. Immutable update of mySelfMap; the save effect
  // (dep: mySelfMap) flushes it to the instructor's own __self row, and the
  // hydrate keeps it sticky across reload/poll. Owners never call this.
  const answerSelfCheckIn = (status, slots) => {
    if (!isInstructor) return;
    if (previewBlock()) return;
    markEdit();
    const key = pstDateKey();
    setMySelfMap((prev) => prev[key] === status ? prev : { ...prev, [key]: status });
    // The lessons answer rides along ("" = none today); edits after this go
    // through an admin-approved lessonEdit request.
    if (typeof slots === "string") setMyLessonsMap((prev) => prev[key] === slots ? prev : { ...prev, [key]: slots });
    setSelfTick((t) => t + 1);
    setView("mine"); // after answering, land instructors on My Lessons (not Day)
  };
  // ── Auto clock-out at closing time ──
  // Runs on the shared 30s tick. Any shift still open past close (+30 min
  // grace), or left open from a previous day, is closed AT the closing time
  // and flagged `auto` so it appears in the Hours "needs review" list until
  // an admin confirms or edits it. Each device closes its OWN shift; the
  // owner's device also closes everyone else's. Never runs in preview.
  const AUTO_CLOSE_GRACE_MS = 30 * 6e4;
  const lastAutoSweepRef = useRef(0);
  const autoCloseSweep = async () => {
    if (previewingRef.current || !session) return;
    const closeStr = staff && staff.autoClockOut;
    if (!closeStr) return;
    const now = Date.now();
    if (now - lastAutoSweepRef.current < 4 * 6e4) return;
    lastAutoSweepRef.current = now;
    const todayKey = pstDateKey();
    const targets = [];
    for (const row of shiftRowsOf(instrWrites)) {
      if (!row || !row.user_id) continue;
      const list = sanitizeShifts(row.shifts);
      let changed = false;
      const next = list.map((s) => {
        if (s.out) return s;
        const closeMs = dayTimeToMs(s.day, closeStr);
        if (!closeMs || s.in >= closeMs) return s; // evening shift after close: leave it
        const due = s.day < todayKey || now > closeMs + AUTO_CLOSE_GRACE_MS;
        if (!due) return s;
        changed = true;
        return { ...s, out: Math.max(closeMs, s.in + 6e4), auto: true };
      });
      if (changed) targets.push({ userId: row.user_id, next });
    }
    if (!targets.length) return;
    for (const t of targets) {
      const mine = t.userId === myUserId;
      if (!mine && !isOwner) continue;
      setInstrWrites((rows) => applyShiftsLocally(rows, t.userId, t.next));
      // Same in-flight guard as punchClock: don't let a poll revert my own row.
      if (mine) shiftSaveInFlightRef.current = true;
      try {
        if (mine) await saveMyShifts(t.userId, t.next);
        else await ownerSetShifts(t.userId, t.next);
      } catch {
        // Write failed: bust the no-op-adoption cache so the next poll re-syncs
        // this row from the server instead of trusting the optimistic close.
        lastIwJsonRef.current = "";
      } finally {
        if (mine) shiftSaveInFlightRef.current = false;
      }
    }
  };
  const autoCloseSweepRef = useRef(autoCloseSweep);
  useEffect(() => { autoCloseSweepRef.current = autoCloseSweep; });
  // Owner sets the closing time from Staff Hours; syncs like any owner field.
  const setAutoClockOut = guard((v) => {
    const val = typeof v === "string" && /^\d{2}:\d{2}$/.test(v) ? v : "";
    setStaff((st) => ({ ...sanitizeStaff(st), autoClockOut: val }));
  });
  // ── Weekly schedule (feature: schedule vs actual) ──
  const setPersonSchedule = guard((name, dayKey, range) => {
    setStaff((st) => {
      const s2 = sanitizeStaff(st);
      const sch = { ...s2.schedule };
      // Migration: fold any legacy '"Name (you)"' keys (a display label that
      // once leaked into the data) into their raw name; raw values win.
      for (const k of Object.keys(sch)) {
        if (k.endsWith(" (you)")) {
          const raw = k.slice(0, -" (you)".length);
          sch[raw] = { ...sch[k], ...(sch[raw] || {}) };
          delete sch[k];
        }
      }
      const person = { ...sch[name] || {} };
      if (range) person[dayKey] = range; else delete person[dayKey];
      if (Object.keys(person).length) sch[name] = person; else delete sch[name];
      return { ...s2, schedule: sch };
    });
  });
  // Restore a backup: safety copy of the CURRENT roster first, then adopt the
  // snapshot and let the normal engine save it (rev+1) so every device syncs.
  const [backupBusy, setBackupBusy] = useState(false);
  const ownerRestoreBackup = async (id) => {
    if (!isOwner || backupBusy) return { ok: false, error: "Not available right now." };
    setBackupBusy(true);
    try {
      const blob = await fetchRosterBackup(id);
      if (!blob || typeof blob !== "object" || !blob.weeks) throw new Error("That backup looks empty.");
      const current = { weeks, migrations: migrationsRef.current, freeSwim, switchRequests, accounts, staff };
      try { await writePreRestoreBackup(current, {}); } catch {}
      markEdit();
      migrationsRef.current = Array.isArray(blob.migrations) ? blob.migrations : migrationsRef.current;
      setWeeks(blob.weeks && typeof blob.weeks === "object" ? blob.weeks : {});
      setFreeSwim(sanitizeFreeSwim(blob.freeSwim));
      setStaff(sanitizeStaff(blob.staff));
      setSwitchRequests(sanitizeSwitchRequests(blob.switchRequests));
      flashNotice("Backup restored \u2014 saving it to every device now.");
      return { ok: true };
    } catch (e) {
      return { ok: false, error: String(e && e.message || e).slice(0, 140) };
    } finally {
      setBackupBusy(false);
    }
  };
  // Enter/exit instructor preview. Entry requires a clean sync state so the
  // poll (which adopts freely while "instructor") can never overwrite an
  // unsaved admin edit. Exit restores the admin's previous tab.
  const prevViewRef = useRef("day");
  const [showPreviewPick, setShowPreviewPick] = useState(false);
  const enterPreview = (acct) => {
    if (!isOwnerReal || !acct) return;
    if (dirtyRef.current || pendingSaveRef.current || syncState === "saving") {
      setSyncNotice("Hang on \u2014 wait for saving to finish, then start the preview.");
      return;
    }
    prevViewRef.current = view;
    setPreviewAs({ id: acct.id, name: acct.name });
    setShowPreviewPick(false);
    setView("mine");
  };
  const exitPreview = () => {
    setPreviewAs(null);
    setView(prevViewRef.current || "day");
  };
  // ---- Time clock: punches + owner adjustments ----
  // Everyone's shifts already arrive via instrWrites (load + 15s poll). These
  // handlers write immediately (no debounce): update local state optimistically
  // for an instant button response, persist with the shared timeout, and revert
  // with the REAL error in the sync notice if the write is rejected/hangs.
  const clockNow = () => Date.now();
  const shiftRowsOf = (rows) => Array.isArray(rows) ? rows : [];
  const myShifts = sanitizeShifts((shiftRowsOf(instrWrites).find((r) => r && r.user_id === myUserId) || {}).shifts);
  const myOpenShift = myShifts.find((s) => !s.out) || null;
  const onClockCount = shiftRowsOf(instrWrites).filter((r) => sanitizeShifts(r && r.shifts).some((s) => !s.out)).length;
  const applyShiftsLocally = (rows, userId, nextShifts) => {
    const arr = shiftRowsOf(rows).slice();
    const i = arr.findIndex((r) => r && r.user_id === userId);
    if (i >= 0) arr[i] = { ...arr[i], shifts: nextShifts };
    else arr.push({ user_id: userId, attendance: {}, requests: [], shifts: nextShifts });
    return arr;
  };
  const punchClock = async (dir) => {
    if (previewBlock()) return;
    if (!myUserId || clockBusy) return;
    const cur = sanitizeShifts((shiftRowsOf(instrWrites).find((r) => r && r.user_id === myUserId) || {}).shifts);
    const open = cur.find((s) => !s.out);
    let next;
    if (dir === "in") {
      if (open) return;
      next = [...cur, { id: `sh-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, in: roundClockIn(clockNow()), out: 0, day: pstDateKey() }];
    } else {
      if (!open) return;
      next = cur.map((s) => s.id === open.id ? { ...s, out: Math.max(clockNow(), s.in + 1000) } : s);
    }
    setClockBusy(true);
    const prevRows = instrWrites;
    setInstrWrites((rows) => applyShiftsLocally(rows, myUserId, next));
    // The poll must not adopt the server's older copy of my row mid-flight.
    shiftSaveInFlightRef.current = true;
    try {
      await saveMyShifts(myUserId, next);
    } catch (e) {
      setInstrWrites(prevRows);
      setSyncNotice((dir === "in" ? "Clock-in" : "Clock-out") + " didn't save: " + String(e && e.message || e).slice(0, 140));
    } finally {
      shiftSaveInFlightRef.current = false;
      setClockBusy(false);
    }
  };
  // Owner rewrites one person's shift list (fix a forgotten clock-out, edit
  // times, delete a bad punch, add a manual entry). `mutate` gets the current
  // sanitized list and returns the next one. Optimistic + revert, like accounts.
  const ownerAdjustShifts = async (userId, mutate) => {
    if (!isOwner || !userId) return { ok: false, error: "Not authorized." };
    const cur = sanitizeShifts((shiftRowsOf(instrWrites).find((r) => r && r.user_id === userId) || {}).shifts);
    let next;
    try { next = sanitizeShifts(mutate(cur.map((s) => ({ ...s })))); } catch { return { ok: false, error: "Bad adjustment." }; }
    const prevRows = instrWrites;
    setInstrWrites((rows) => applyShiftsLocally(rows, userId, next));
    try {
      await ownerSetShifts(userId, next);
      return { ok: true };
    } catch (e) {
      setInstrWrites(prevRows);
      return { ok: false, error: friendlyAccountError(e) };
    }
  };
  // ---- Staff coverage & daily attendance ----
  // Derived list of every staff member by name from three sources: login accounts
  // (default instructor), free-swim guards (default lifeguard), and manually-added
  // extras (default instructor). An explicit staff.roles[name] always wins. Dedupe
  // is case-insensitive on the trimmed name; the first source to claim a name owns
  // its display capitalization. present = the name isn't in today's ABSENT map,
  // unless a self check-in overrides it (self "absent" wins; self "present" shows
  // confirmed). selfChecked flags people who self-reported so the owner can tell
  // confirmed presence from assumed.
  const staffList = useMemo(() => {
    const byKey = /* @__PURE__ */ new Map();
    const roles = staff.roles || {};
    const todayAbsent = (staff.attendance && staff.attendance[activeDate]) || {};
    const add = (rawName, fallbackRole, accountId) => {
      const name = String(rawName || "").replace(/\u00A0/g, " ").trim();
      // Skip accounts whose username is blank/whitespace — they'd render a
      // nameless card. The owner should rename them in Instructor accounts.
      if (!name) return;
      const key = normName(name);
      const role = roles[name] || (byKey.has(key) ? byKey.get(key).role : fallbackRole);
      if (byKey.has(key)) {
        // Keep the first-seen display name; only let an explicit role upgrade it.
        const cur = byKey.get(key);
        if (roles[name]) cur.role = roles[name];
        // Carry an account id if this source supplies one and we don't have it yet.
        if (accountId && !cur.accountId) cur.accountId = accountId;
        return;
      }
      byKey.set(key, { name, role, accountId: accountId || null });
    };
    (accounts || []).forEach((a) => add(a.name, "instructor", a.id));
    ((freeSwim && freeSwim.guards) || []).forEach((g) => add(g, "lifeguard"));
    ((staff.extra) || []).forEach((e) => add(e.name, "instructor"));
    // MERGE PASS: the same person often enters twice under two spellings —
    // e.g. an account "Jordan Lee" plus a free-swim guard entry "Jordan".
    // Both cards then display the first name and the board shows "two
    // Jordans". Rule: a first-name-only entry folds into the ONE full-name
    // entry sharing that first name (kept as an alias so old absence marks
    // and check-ins under the short spelling still land on the merged card).
    // If two or more FULL names share a first name, they're different people
    // and are all kept.
    const firstOfName = (n) => normName(String(n).trim().split(/\s+/)[0] || "");
    const entries = [...byKey.values()].map((p) => ({ ...p, aliases: [p.name] }));
    const byFirst = /* @__PURE__ */ new Map();
    entries.forEach((p) => {
      const f = firstOfName(p.name);
      if (!byFirst.has(f)) byFirst.set(f, []);
      byFirst.get(f).push(p);
    });
    const drop = /* @__PURE__ */ new Set();
    for (const group of byFirst.values()) {
      if (group.length < 2) continue;
      const fulls = group.filter((p) => p.name.trim().includes(" "));
      const shorts = group.filter((p) => !p.name.trim().includes(" "));
      if (fulls.length === 1 && shorts.length >= 1) {
        const keep = fulls[0];
        shorts.forEach((s) => {
          drop.add(s);
          keep.aliases.push(s.name);
          if (s.accountId && !keep.accountId) keep.accountId = s.accountId;
          // An explicit role set on either spelling wins; lifeguard+instructor => both.
          if (roles[s.name]) keep.role = roles[s.name];
          else if ((s.role === "lifeguard" && keep.role === "instructor") || (s.role === "instructor" && keep.role === "lifeguard")) keep.role = "both";
        });
      }
    }
    const merged = entries.filter((p) => !drop.has(p));
    // When two DIFFERENT people share a first name, show full names so the
    // owner can tell the cards apart.
    const firstCounts = {};
    merged.forEach((p) => { const f = firstOfName(p.name); firstCounts[f] = (firstCounts[f] || 0) + 1; });
    return merged.map((p) => {
      const ownerAbsent = p.aliases.some((n) => !!todayAbsent[n]);
      let self = null;
      for (const n of p.aliases) { const m = selfPresenceByName[normName(n)]; if (m) { self = m; break; } }
      let todayLessons = null;
      for (const n of p.aliases) { const L = selfLessonsByName[normName(n)]; if (typeof L === "string") { todayLessons = L; break; } }
      // Owner-marked absent OR self-reported absent => absent. Self "present"
      // shows present (unless owner overrode to absent). Else existing default.
      const present = ownerAbsent ? false : self === "present" ? true : self === "absent" ? false : true;
      return {
        name: p.name,
        displayFull: firstCounts[firstOfName(p.name)] > 1,
        role: STAFF_ROLES.includes(p.role) ? p.role : "instructor",
        accountId: p.accountId || null,
        present,
        selfChecked: self === "present" || self === "absent",
        todayLessons
      };
    }).sort((a, b) => a.name.localeCompare(b.name));
  }, [accounts, freeSwim, staff, activeDate, selfPresenceByName, selfLessonsByName]);
  // "Scheduled but hasn't clocked in" — computed live for admins: on the
  // schedule today, 15+ min past their start, not punched in, not marked or
  // self-reported absent, and their scheduled window hasn't ended.
  const DAY_KEYS = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];
  const lateToday = useMemo(() => {
    if (!isOwner) return [];
    const sch = (staff && staff.schedule) || {};
    const names = Object.keys(sch);
    if (!names.length) return [];
    const now = Date.now();
    const todayKey = pstDateKey();
    const dk = DAY_KEYS[new Date(now).getDay()];
    const out = [];
    for (const name of names) {
      const range = sch[name] && sch[name][dk];
      if (!range) continue;
      const [a, b] = range.split("-");
      const startMs = dayTimeToMs(todayKey, a);
      const endMs = dayTimeToMs(todayKey, b);
      if (!startMs || !endMs || now < startMs + 15 * 6e4 || now > endMs) continue;
      const person = staffList.find((p) => p.name === name || (p.aliases || []).includes(name));
      if (person && person.present === false) continue; // owner-marked or self-reported absent
      // punched in today? match their user row via account name or travelling name
      const acct = (accounts || []).find((x) => x.name === name);
      const row = shiftRowsOf(instrWrites).find((r) => {
        if (!r) return false;
        if (acct && r.user_id === acct.id) return true;
        const trav = r.attendance && typeof r.attendance.__name === "string" ? r.attendance.__name.trim() : "";
        return trav && normName(trav) === normName(name);
      });
      const punchedToday = row && sanitizeShifts(row.shifts).some((s) => s.day === todayKey);
      // Carry the user id (account match first, else their punch row) so the
      // Hours warning can offer a one-tap admin clock-in.
      if (!punchedToday) out.push({ name, sched: range, userId: acct ? acct.id : row && row.user_id || "" });
    }
    return out;
  }, [isOwner, staff, staffList, accounts, instrWrites, clockTick]);
  // "Save now": jump the debounce. If a save is queued, fire it this instant;
  // if we're offline with a stashed payload, retry the flush. Anything already
  // in flight is left alone — the serialized chain keeps order either way.
  const saveNow = () => {
    if (previewing) return;
    if (saveTimerArmedRef.current && saveNowRef.current) {
      forceSaveRef.current = true; // a tap skips any remaining boot-wait
      clearTimeout(saveTimer.current);
      saveNowRef.current();
      return;
    }
    if (pendingSaveRef.current) flushPendingRef.current();
  };
  useEffect(() => { if (syncState === "saved") setHasUnsaved(false); }, [syncState]);
  const needsSave = !previewing && loadedRef.current && (
    hasUnsaved || syncState === "saving" || syncState === "offline"
  );
  // Free-swim guard candidate pool: every name already in the guard roster PLUS
  // anyone whose staff role is lifeguard/both. Setting a role to lifeguard in the
  // Today tab makes them appear in the "On duty today" toggle automatically —
  // without manually adding them as a guard. Deduped case-insensitively, guard
  // roster order first (preserves the rotation order), then role-only people.
  const guardCandidates = useMemo(() => {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    const push = (n) => {
      const name = String(n || "").trim();
      if (!name) return;
      const k = normName(name);
      if (seen.has(k)) return;
      seen.add(k);
      out.push(name);
    };
    ((freeSwim && freeSwim.guards) || []).forEach(push);
    staffList.forEach((p) => { if (p.role === "lifeguard" || p.role === "both") push(p.name); });
    return out;
  }, [freeSwim, staffList]);
  // Mark a person ABSENT (absent=true) or clear them back to present for today.
  const setStaffAbsent = guard((name, absent) => setStaff((s) => {
    const day = { ...((s.attendance && s.attendance[activeDate]) || {}) };
    if (absent) day[name] = true; else delete day[name];
    const attendance = { ...(s.attendance || {}) };
    if (Object.keys(day).length) attendance[activeDate] = day; else delete attendance[activeDate];
    return { ...s, attendance };
  }));
  const toggleStaffPresent = guard((name) => {
    const cur = staffList.find((p) => normName(p.name) === normName(name));
    setStaffAbsent(name, cur ? cur.present : true);
  });
  const setStaffRole = guard((name, role) => setStaff((s) => {
    const nm = String(name || "").trim();
    if (!nm || !STAFF_ROLES.includes(role)) return s;
    return { ...s, roles: { ...(s.roles || {}), [nm]: role } };
  }));
  const addExtraStaff = guard((name) => {
    const nm = String(name || "").trim();
    if (!nm) return;
    setStaff((s) => {
      const exists = (s.extra || []).some((e) => normName(e.name) === normName(nm)) ||
        (accounts || []).some((a) => normName(a.name) === normName(nm)) ||
        ((freeSwim && freeSwim.guards) || []).some((g) => normName(g) === normName(nm));
      if (exists) return s;
      return { ...s, extra: [...(s.extra || []), { name: nm }] };
    });
  });
  const removeExtraStaff = guard((name) => {
    // confirm destructive delete
    if (!window.confirm(`Remove ${name} from staff? Their login (if any) is unaffected.`)) return;
    setStaff((s) => ({
      ...s,
      extra: (s.extra || []).filter((e) => normName(e.name) !== normName(name)),
      roles: Object.fromEntries(Object.entries(s.roles || {}).filter(([k]) => normName(k) !== normName(name)))
    }));
  });
  // ---- Shared name layer: propagate a rename across every people reference ----
  // Immutably rewrites oldName -> newName everywhere a free-text name lives so a
  // single rename (usually from an account rename) never leaves orphans: lesson
  // instructor arrays (all weeks), free-swim guards/onDuty/manual cells, and the
  // staff roles map, extra list, and date-keyed attendance map. Owner-gated;
  // matched by normName so capitalization-only edits still re-key cleanly.
  const renamePerson = guard((oldName, newName) => {
    const from = normName(oldName);
    const to = String(newName || "").trim();
    if (!from || !to) return;
    const isFrom = (n) => normName(n) === from;
    // 1) Lesson instructor arrays across EVERY week.
    setWeeks((all) => {
      let changed = false;
      const out = {};
      for (const [wk, data] of Object.entries(all || {})) {
        const instr = data && data.instructors;
        if (!instr || typeof instr !== "object") { out[wk] = data; continue; }
        let wkChanged = false;
        const nextInstr = {};
        for (const [k, names] of Object.entries(instr)) {
          if (Array.isArray(names) && names.some(isFrom)) {
            nextInstr[k] = names.map((n) => isFrom(n) ? to : n);
            wkChanged = true;
          } else {
            nextInstr[k] = names;
          }
        }
        if (wkChanged) { out[wk] = { ...data, instructors: nextInstr }; changed = true; }
        else out[wk] = data;
      }
      return changed ? out : all;
    });
    // 2) Free-swim guards, onDuty, and every manual grid cell.
    setFreeSwim((f) => {
      const guards = (f.guards || []).map((g) => isFrom(g) ? to : g);
      const onDuty = (f.onDuty || []).map((g) => isFrom(g) ? to : g);
      const manual = Array.isArray(f.manual)
        ? f.manual.map((row) => Array.isArray(row) ? row.map((c) => c && isFrom(c) ? to : c) : row)
        : f.manual;
      return { ...f, guards, onDuty, manual };
    });
    // 3) Staff roles (re-key), extra[].name, attendance (re-key per day), and
    // the weekly schedule (re-key — a rename must not orphan their schedule).
    setStaff((s) => {
      const roles = {};
      for (const [k, v] of Object.entries(s.roles || {})) roles[isFrom(k) ? to : k] = v;
      const extra = (s.extra || []).map((e) => e && isFrom(e.name) ? { ...e, name: to } : e);
      const attendance = {};
      for (const [day, marks] of Object.entries(s.attendance || {})) {
        const dayOut = {};
        for (const [k, v] of Object.entries(marks || {})) dayOut[isFrom(k) ? to : k] = v;
        attendance[day] = dayOut;
      }
      const schedule = {};
      for (const [k, v] of Object.entries(s.schedule || {})) schedule[isFrom(k) ? to : k] = v;
      return { ...s, roles, extra, attendance, schedule };
    });
  });
  // Reassign a lesson slot: drop the absent name, add the replacement (immutably).
  const replaceLessonInstructor = guard((time, level, absentName, replacement) => {
    const repl = String(replacement || "").trim();
    if (!repl) return;
    setInstructors((p) => {
      const k = classKey(time, level);
      const list = (p[k] || []).filter((n) => normName(n) !== normName(absentName));
      if (!list.some((n) => normName(n) === normName(repl))) list.push(repl);
      return { ...p, [k]: list };
    });
  });
  // Swap an absent lifeguard for a replacement in the free-swim guard pool + onDuty.
  const replaceGuard = guard((absentName, replacement) => {
    const repl = String(replacement || "").trim();
    if (!repl) return;
    setFreeSwim((f) => {
      const guards = (f.guards || []).map((g) => normName(g) === normName(absentName) ? repl : g);
      if (!guards.some((g) => normName(g) === normName(repl))) guards.push(repl);
      const onDuty = (f.onDuty || []).map((g) => normName(g) === normName(absentName) ? repl : g);
      return { ...f, guards, onDuty };
    });
  });
  if (!authReady) {
    return /* @__PURE__ */ jsxs("div", { style: styles.page, children: [
      /* @__PURE__ */ jsx("style", { children: css }),
      /* @__PURE__ */ jsxs("div", { style: styles.gateWrap, children: [
        authError
          ? h("div", { style: { maxWidth: 420, textAlign: "center", padding: "0 20px" } }, [
              h(AlertCircle, { size: 30, style: { color: "#D9534F" }, key: "ic" }),
              h("p", { style: { ...styles.gateSub, marginTop: 12, fontWeight: 700 }, key: "t" }, "Couldn't reach the server"),
              h("p", { style: { ...styles.gateSub, marginTop: 6, fontSize: 13, color: "#8A4B4B", wordBreak: "break-word" }, key: "m" }, authError),
              h("button", { style: { ...styles.gateBtn, marginTop: 16 }, key: "r", onClick: () => location.reload() }, "Try again")
            ])
          : h(Fragment, null, [
              /* @__PURE__ */ jsx(Loader2, { size: 28, style: { color: "#1D7A8C" }, className: "spin", key: "s" }),
              /* @__PURE__ */ jsx("p", { style: styles.gateSub, children: "Starting up\u2026", key: "p" })
            ])
      ] })
    ] });
  }
  if (!session) {
    return h(AuthGate, { topError: authError });
  }
  if (profile && profile.active === false) {
    return h(DisabledGate, { onSignOut: async () => { await authSignOut(); } });
  }
  const stillLoading = syncState === "loading" && !loadedRef.current;
  if (stillLoading) {
    return /* @__PURE__ */ jsxs("div", { style: styles.page, children: [
      /* @__PURE__ */ jsx("style", { children: css }),
      /* @__PURE__ */ jsxs("div", { style: styles.gateWrap, children: [
        /* @__PURE__ */ jsx(Loader2, { size: 28, style: { color: legibleColor("#1D7A8C") }, className: "spin" }),
        /* @__PURE__ */ jsx("p", { style: styles.gateSub, children: "Loading rosters\u2026" })
      ] })
    ] });
  }
  // Instructor-only self check-in gate. Show ONLY when: instructor (not owner),
  // today isn't closed, it's >= 9:55 AM PST (595 min), and not yet answered today.
  // Reading selfTick ties this to the per-minute instructor tick so it appears at
  // 9:55 without a manual refresh; mySelfMap (hydrated from __self) keeps it from
  // re-showing once answered, across reloads/polls. CHECK_IN_OPEN_MIN = 9:55.
  void selfTick;
  const todayKeyForCheckIn = pstDateKey();
  // Only prompt instructors whose own account has a real name. A blank/whitespace
  // username can't be matched back to a named card on the owner's view, so we skip
  // the question for them entirely — every answer that comes in maps to a name.
  const myNameOk = String(myName || "").replace(/\u00A0/g, " ").trim().length > 0;
  // Never prompt until the user is authenticated: require an active session and a
  // loaded profile. isInstructor already implies a profile, but gating on session
  // explicitly guarantees the question can't appear on the login/landing screen.
  const loggedIn = !!session && !!profile;
  const showCheckIn = loggedIn && !previewing && isInstructor && myNameOk && !isClosed(todayKeyForCheckIn) && pstMinutes() >= CHECK_IN_OPEN_MIN && !mySelfMap[todayKeyForCheckIn];
  return /* @__PURE__ */ jsxs("div", { style: styles.page, children: [
    /* @__PURE__ */ jsx("style", { children: css }),
    showCheckIn && h(CheckInPrompt, {
      key: "checkIn",
      onAnswer: answerSelfCheckIn,
      // Pre-select the time slots of the lessons they're assigned this week.
      defaultSlots: Array.from(new Set((myLessonKeys || []).map((k) => String(k).split("|")[0]))).filter((t) => TIME_SLOTS.includes(t))
    }),
    /* @__PURE__ */ jsx("header", { style: styles.header, children: /* @__PURE__ */ jsxs("div", { className: "ag-hd-in", style: styles.headerInner, children: [
      /* @__PURE__ */ jsxs("div", { style: styles.brand, children: [
        /* @__PURE__ */ jsx("div", { className: "ag-hd-wave", style: styles.wave, "aria-hidden": true, children: /* @__PURE__ */ jsx("img", { src: "/favicon.svg", alt: "", style: { width: "100%", height: "100%", objectFit: "cover", display: "block", borderRadius: "inherit" } }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "ag-hd-kick", style: { ...styles.kicker, color: "#A9D7DB" }, children: "LMUSD \xB7 Summer Swim 2026" }),
          /* @__PURE__ */ jsx("h1", { className: "ag-hd-h1", style: styles.h1, children: "Lesson Rosters" }),
          h(HeaderClock, { key: "clk" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "ag-hd-act", style: styles.headerActions, children: [
        // Warm time-of-day greeting, top-right of the banner (centered on
        // phones to match the toolbar). Hour is PST like the rest of the app.
        h("div", { key: "greet", className: "ag-hd-greet", style: { width: "100%", textAlign: "right", fontFamily: "var(--display)", fontSize: 13.5, fontWeight: 700, color: "#A9D7DB", letterSpacing: 0.2 } }, (() => {
          const hr = Math.floor(pstMinutes() / 60);
          const g = hr < 12 ? "Good morning" : hr < 17 ? "Good afternoon" : "Good evening";
          const nm = (myName && myName.split(" ")[0]) || "";
          const ico = hr < 12 ? "☀️" : hr < 17 ? "🌤️" : "🌙";
          return nm ? `${g}, ${nm} ${ico}` : `${g} ${ico}`;
        })()),
        // R4: offline badge is tappable to force a retry of any pending owner save.
        /* @__PURE__ */ jsx(SyncBadge, { state: syncState, onRetry: () => { setSyncNotice(""); flushPendingRef.current(); } }),
        needsSave && (() => {
          // Queued (debounce armed) = tappable "Save now". Truly in flight
          // (request on the wire) = brief disabled "Saving…". Offline = retry.
          const queued = saveTimerArmedRef.current || pendingSaveRef.current && syncState !== "saving";
          const inFlight = syncState === "saving" && !saveTimerArmedRef.current;
          return h("button", {
            key: "saveBtn",
            style: { border: "none", borderRadius: 999, background: syncState === "offline" ? "#B23A2C" : "#0A7568", color: "#fff", fontWeight: 800, fontSize: 11.5, padding: "6px 11px", cursor: inFlight ? "default" : "pointer", fontFamily: "inherit", whiteSpace: "nowrap", opacity: inFlight ? 0.75 : 1 },
            disabled: inFlight,
            onClick: saveNow,
            "aria-label": syncState === "offline" ? "Save failed or offline. Tap to retry now." : inFlight ? "Saving your changes." : "Unsaved changes. Tap to save now."
          }, inFlight ? "Saving\u2026" : syncState === "offline" ? "Save \u00B7 retry" : "Save now");
        })(),
        updateReady && h("button", {
          key: "updBtn",
          className: "agpulse",
          role: "status",
          style: { border: "none", borderRadius: 999, background: "#E8A02C", color: "#3A2206", fontWeight: 800, fontSize: 11.5, padding: "6px 11px", cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap" },
          onClick: applyUpdate,
          "aria-label": "A new version is ready. Tap to update."
        }, "Update ready \u00B7 tap"),
        // R1: non-destructive notice (e.g. "reloaded newer data") shown by the badge.
        // A real button (keyboard-dismissable) in a tint that reads on the navy
        // header — the old #B23A2C measured 1.94:1 there.
        syncNotice && h("button", {
          key: "syncNotice",
          style: { background: "none", border: "none", fontFamily: "inherit", fontSize: 11.5, color: "#FFB4AC", fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap", maxWidth: 220, overflow: "hidden", textOverflow: "ellipsis", padding: "7px 4px" },
          title: syncNotice + " (tap to dismiss)",
          onClick: () => setSyncNotice("")
        }, syncNotice),
        // A4: a PERSISTENT live region announces sync notices — one that mounts
        // already holding text is never announced by most screen readers.
        h("span", { key: "syncLive", role: "status", style: { position: "absolute", width: 1, height: 1, overflow: "hidden", clipPath: "inset(50%)" } }, syncNotice || ""),
        isOwner && h("button", {
          key: "previewBtn",
          style: styles.gearBtn,
          onClick: () => setShowPreviewPick(true),
          "aria-label": "Preview as an instructor",
          title: "Preview the instructor view"
        }, h(Eye, { size: 18 })),
        isOwner && h("button", {
          key: "scanBtn",
          style: styles.gearBtn,
          onClick: () => setShowScan(true),
          "aria-label": "Scan a roster photo to import swimmers",
          title: "Scan roster photo"
        }, h(ClipboardCheck, { size: 18 })),
        isOwner && h("button", {
          key: "acctBtn",
          style: styles.gearBtn,
          onClick: () => setShowAccounts(true),
          "aria-label": "Manage instructor accounts",
          title: "Manage instructor accounts"
        }, h(UserPlus, { size: 18 })),
        (isOwner || isInstructor) && h("button", {
          key: "reqBtn",
          style: { ...styles.gearBtn, position: "relative" },
          onClick: () => setShowReview(true),
          "aria-label": "Requests",
          title: isOwner ? "Review staff requests" : "Your requests"
        }, [
          h(ArrowRightLeft, { size: 17, key: "i" }),
          isOwner && pendingCount > 0 && h("span", { key: "b", style: styles.reqBadge, "aria-label": `${pendingCount} pending requests` }, pendingCount)
        ]),
        isOwner ? h("button", {
          key: "ownerBtn",
          style: styles.unlockedBtn,
          onClick: async () => {
            // One accidental tap must not destroy an unsaved edit — no
            // navigation happens here, so beforeunload never fires. Confirm,
            // with a stronger warning while something is unsaved/stashed.
            const unsaved = dirtyRef.current || instrDirtyRef.current || pendingSaveRef.current;
            if (!window.confirm(unsaved ? "You have an unsaved change that will be lost — sign out anyway?" : "Sign out?")) return;
            await authSignOut();
            if (view === "mine") setView("day");
          },
          title: "Signed in as owner \u2014 tap to sign out"
        }, [h(Unlock, { size: 15, key: "u" }), " ", (myName && myName.split(" ")[0]) || "Owner"]) : h("button", {
          key: "instBtn",
          style: styles.instructorBtn,
          onClick: async () => {
            // One accidental tap must not destroy an unsaved edit — no
            // navigation happens here, so beforeunload never fires. Confirm,
            // with a stronger warning while something is unsaved/stashed.
            const unsaved = dirtyRef.current || instrDirtyRef.current || pendingSaveRef.current;
            if (!window.confirm(unsaved ? "You have an unsaved change that will be lost — sign out anyway?" : "Sign out?")) return;
            await authSignOut();
            if (view === "mine") setView("day");
          },
          title: "Signed in \u2014 tap to sign out"
        }, [h(Users, { size: 15, key: "u" }), " ", (myName && myName.split(" ")[0]) || "Instructor"]),
        h("button", { key: "themeBtn", style: styles.gearBtn, onClick: () => {
          const next = theme === "dark" ? "light" : "dark";
          // Set the attribute synchronously BEFORE the state update: the color
          // helpers read data-theme during render, so the effect-only path
          // painted one full frame in the wrong theme. The effect stays as a
          // backstop for every other way the theme can change.
          try { document.documentElement.setAttribute("data-theme", next); } catch {}
          setTheme(next);
        }, "aria-label": "Toggle dark mode", title: theme === "dark" ? "Switch to light mode" : "Switch to dark mode" }, theme === "dark" ? h(Sun, { size: 18 }) : h(Moon, { size: 18 })),
        /* @__PURE__ */ jsx("button", { style: styles.gearBtn, onClick: () => setShowSettings(true), "aria-label": "Sync settings", title: "Sync settings", children: /* @__PURE__ */ jsx(Settings, { size: 18 }) })
      ] })
    ] }) }),
    // Slim amber strip while offline — same visual language as the preview bar.
    !isOnline && h("div", { key: "offlineBar", role: "status", style: { display: "flex", alignItems: "center", gap: 9, padding: "8px 14px", background: "#FFF4DE", borderBottom: "1.5px solid #E8A02C", color: "#7A5A14", fontWeight: 700, fontSize: 12.5 } }, "Offline — showing last synced roster. Changes send when you're back."),
    previewing && h("div", { key: "previewBar", role: "status", style: { display: "flex", alignItems: "center", gap: 9, padding: "9px 14px", background: "#FFF4DE", borderBottom: "1.5px solid #E8A02C", color: "#7A5A14", fontWeight: 700, fontSize: 13 } }, [
      h(Eye, { size: 15, key: "i", style: { flexShrink: 0 } }),
      h("span", { key: "t", style: { flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, `Previewing as ${previewAs ? previewAs.name : "instructor"} \u2014 this is the instructor view. Actions are disabled.`),
      h("button", { key: "x", style: { border: "none", borderRadius: 8, background: "#E8A02C", color: "#fff", fontWeight: 800, fontSize: 12.5, padding: "7px 12px", cursor: "pointer", fontFamily: "inherit", flexShrink: 0 }, onClick: exitPreview, "aria-label": "Exit preview" }, "Exit preview")
    ]),
    h(RailScroller, { key: "railScroller" }, /* @__PURE__ */ jsxs("nav", { style: styles.rail, children: [
      isOwner && h("button", {
        key: "dash",
        onClick: () => setView("dashboard"),
        style: { ...styles.slot, ...styles.slotMine, ...view === "dashboard" ? styles.slotMineActive : {} },
        title: "Owner dashboard",
        "aria-current": view === "dashboard" ? "page" : void 0
      }, [
        h(LayoutGrid, { size: 15, key: "i", style: { opacity: 0.85 } }),
        h("span", { style: styles.slotTime, key: "t" }, "Dashboard"),
        pendingCount > 0 && h("span", { style: styles.reqBadge, key: "c", "aria-label": `${pendingCount} pending requests` }, pendingCount)
      ]),
      isOwner && h("span", { style: styles.railDivider, key: "dashdiv" }),
      isInstructor && h("button", {
        key: "mine",
        onClick: () => setView("mine"),
        style: { ...styles.slot, ...styles.slotMine, ...view === "mine" ? styles.slotMineActive : {} },
        title: "My assigned lessons",
        "aria-current": view === "mine" ? "page" : void 0
      }, [
        h(Waves, { size: 15, key: "i", style: { opacity: 0.85 } }),
        h("span", { style: styles.slotTime, key: "t" }, "My Lessons"),
        h("span", { style: { ...styles.slotCount, ...view === "mine" ? styles.slotCountActive : {} }, key: "c" }, myLessonKeys.length)
      ]),
      isInstructor && h("span", { style: styles.railDivider, key: "minediv" }),
      h("button", {
        key: "shifts",
        onClick: () => setView("shifts"),
        style: { ...styles.slot, ...view === "shifts" ? styles.slotActive : {} },
        title: "Everyone's shifts \u2014 tap to trade",
        "aria-current": view === "shifts" ? "page" : void 0
      }, [
        h(ArrowRightLeft, { size: 15, key: "i", style: { opacity: 0.75 } }),
        h("span", { style: styles.slotTime, key: "t" }, "Shifts")
      ]),
      h("span", { style: styles.railDivider, key: "shiftsdiv" }),
      /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => setView("day"),
          style: { ...styles.slot, ...view === "day" ? styles.slotActive : {} },
          "aria-current": view === "day" ? "page" : void 0,
          children: [
            /* @__PURE__ */ jsx(LayoutGrid, { size: 15, style: { opacity: 0.7 } }),
            /* @__PURE__ */ jsx("span", { style: styles.slotTime, children: "Day" }),
            /* @__PURE__ */ jsx("span", { style: { ...styles.slotCount, ...view === "day" ? styles.slotCountActive : {} }, children: dayStats.total })
          ]
        }
      ),
      /* @__PURE__ */ jsx("span", { style: styles.railDivider }),
      h("button", {
        key: "today",
        onClick: () => setView("today"),
        style: { ...styles.slot, ...view === "today" ? styles.slotActive : {} },
        title: "Staff check-in & coverage for today",
        "aria-current": view === "today" ? "page" : void 0
      }, [
        h(Calendar, { size: 15, key: "i", style: { opacity: 0.7 } }),
        h("span", { style: styles.slotTime, key: "t" }, "Today"),
        h("span", { style: { ...styles.slotCount, ...view === "today" ? styles.slotCountActive : {} }, key: "c" }, `${staffList.filter((p) => p.present).length}/${staffList.length}`)
      ]),
      h("span", { style: styles.railDivider, key: "todaydiv" }),
      isOwner && h("button", {
        key: "hoursbtn",
        onClick: () => setView("hours"),
        style: { ...styles.slot, ...view === "hours" ? styles.slotActive : {} },
        title: "Staff hours & time clock",
        "aria-label": "Staff hours",
        "aria-current": view === "hours" ? "page" : void 0
      }, [
        h(Timer, { size: 15, key: "i", style: { opacity: 0.7 } }),
        h("span", { style: styles.slotTime, key: "t" }, "Hours"),
        h("span", { style: { ...styles.slotCount, ...view === "hours" ? styles.slotCountActive : {} }, key: "c" }, onClockCount)
      ]),
      isOwner && h("span", { style: styles.railDivider, key: "hoursdiv" }),
      h("button", {
        key: "fsbtn",
        onClick: () => setView("free"),
        style: { ...styles.slot, ...styles.slotFree, ...view === "free" ? styles.slotFreeActive : {} },
        title: "Free swim lifeguard rotation",
        "aria-current": view === "free" ? "page" : void 0
      }, [
        h(LifeBuoy, { size: 15, key: "i", style: { opacity: 0.85 } }),
        h("span", { style: styles.slotTime, key: "t" }, "Free Swim"),
        nowSlot === FREE_SWIM ? h("span", { style: styles.fsRailDot, key: "d", title: "Happening now" }) : h("span", { style: { ...styles.slotCount, ...view === "free" ? styles.slotCountActive : {} }, key: "c" }, (freeSwim.onDuty || []).length)
      ]),
      h("span", { style: styles.railDivider, key: "fsdiv" }),
      TIME_SLOTS.map((t) => /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => {
            setActiveTime(t);
            setView(t);
          },
          style: { ...styles.slot, ...view === t ? styles.slotActive : {} },
          "aria-current": view === t ? "page" : void 0,
          children: [
            /* @__PURE__ */ jsx(Clock, { size: 15, style: { opacity: 0.55 } }),
            /* @__PURE__ */ jsx("span", { style: styles.slotTime, children: t }),
            /* @__PURE__ */ jsx("span", { style: { ...styles.slotCount, ...view === t ? styles.slotCountActive : {} }, children: counts[t] }),
            t === nowSlot && /* @__PURE__ */ jsx("span", { style: styles.fsRailDot, title: "Happening now" })
          ]
        },
        t
      ))
    ] })),
    /* @__PURE__ */ jsx(
      DateBar,
      {
        activeDate,
        activeWeek,
        isToday: activeDate === pstDateKey(),
        closed: dayClosed,
        onPrev: () => setActiveDate((d) => shiftDateKey(d, -1)),
        onNext: () => setActiveDate((d) => shiftDateKey(d, 1)),
        onToday: () => setActiveDate(pstDateKey()),
        onPrevWeek: () => setActiveDate(shiftDateKey(activeWeek, -7)),
        onNextWeek: () => setActiveDate(shiftDateKey(activeWeek, 7)),
        onPickDay: (d) => setActiveDate(d)
      }
    ),
    dayStats.freeSwim && activeDate === pstDateKey() && !dayClosed && h("button", { style: styles.freeBanner, onClick: () => setView("free") }, [
      h(LifeBuoy, { size: 18, key: "i" }),
      h("div", { key: "t", style: { flex: 1 } }, [
        h("strong", { key: "s" }, "Free swim now"),
        " \xB7 2:00\u20133:25pm \u2014 tap to open the lifeguard rotation."
      ]),
      h(ChevronRight, { size: 18, key: "c", style: { opacity: 0.9, flexShrink: 0 } })
    ]),
    dayStats.dayOver && activeDate === pstDateKey() && !dayClosed && /* @__PURE__ */ jsxs("div", { style: styles.overBanner, children: [
      /* @__PURE__ */ jsx(Clock, { size: 18 }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("strong", { children: "Day complete" }),
        " \xB7 lessons and free swim are over for today."
      ] })
    ] }),
    view !== "free" && view !== "mine" && view !== "today" && /* @__PURE__ */ jsxs("div", { style: styles.searchWrap, children: [
      /* @__PURE__ */ jsx(Search, { size: 17, style: { color: "var(--muted,#5B7A88)" } }),
      /* @__PURE__ */ jsx(
        "input",
        {
          style: styles.search,
          placeholder: "Search swimmers or parents\u2026",
          "aria-label": "Search swimmers or parents",
          value: search,
          onChange: (e) => setSearch(e.target.value)
        }
      ),
      search && /* @__PURE__ */ jsx("button", { style: styles.clearSearch, onClick: () => setSearch(""), "aria-label": "Clear search", children: /* @__PURE__ */ jsx(X, { size: 15 }) })
    ] }),
    view === "shifts" ? h(ShiftBoard, {
      weeks,
      activeWeek,
      instructors,
      myName,
      isOwner,
      requests: switchRequests,
      onTrade: requestTrade
    }) : view === "dashboard" && isOwner ? h(OwnerDashboard, {
      weeks,
      activeWeek,
      activeDate,
      instructors,
      accounts,
      staffList,
      requests: switchRequests,
      freeSwim,
      nowSlot,
      isToday: activeDate === pstDateKey(),
      onOpenSlot: (t) => { setActiveTime(t); setView(t); },
      onOpenRequests: () => setShowReview(true),
      onOpenAccounts: () => setShowAccounts(true),
      onOpenFree: () => setView("free"),
      hoursRows: instrWrites,
      schedule: (staff && staff.schedule) || {},
      myUserId,
      myName,
      onOpenHours: () => setView("hours")
    }) : view === "mine" ? h(Fragment, null, [
      isInstructor && (() => {
        const cardId = currentUser ? currentUser.id : myUserId;
        const cardShifts = previewing ? sanitizeShifts((shiftRowsOf(instrWrites).find((r) => r && r.user_id === cardId) || {}).shifts) : myShifts;
        // Arrival fixes target the open shift, else today's latest real punch
        // (manual quick-add blocks have no true arrival time to fix).
        const openShift = cardShifts.find((s) => !s.out) || null;
        const fixTarget = openShift || cardShifts.filter((s) => s.day === pstDateKey() && !s.manual).slice(-1)[0] || null;
        const pendingFix = fixTarget ? switchRequests.find((r) => r.kind === "timeEdit" && r.status === "pending" && r.byId === cardId && r.shiftId === fixTarget.id) || null : null;
        return h(ClockCard, {
          key: "clockCard",
          open: openShift,
          todayMs: shiftsMsForDay(cardShifts, pstDateKey(), Date.now()),
          weekMs: shiftsMsForWeek(cardShifts, weekKeyFor(pstDateKey()), Date.now()),
          busy: clockBusy,
          readOnly: previewing,
          clockTick,
          onIn: () => punchClock("in"),
          onOut: () => punchClock("out"),
          fixTarget,
          pendingFix,
          onRequestTimeEdit: previewing ? null : requestTimeEdit
        });
      })(),
      isInstructor && !previewing && (() => {
        // Today's declared lessons + admin-approved change requests. Only after
        // they've checked in "present" (absent days have no lessons to show).
        const tk = pstDateKey();
        if (mySelfMap[tk] !== "present") return null;
        const slots = typeof myLessonsMap[tk] === "string" ? myLessonsMap[tk] : "";
        const pending = switchRequests.find((r) => r.kind === "lessonEdit" && r.status === "pending" && r.byId === myUserId && r.day === tk) || null;
        return h(TodayLessonsCard, { key: "todayLessons", slots, pending, onRequest: (toSlots) => requestLessonEdit(tk, slots, toSlots, "") });
      })(),
      h(MyLessons, {
        key: "myLessons",
      user: currentUser,
      weeks,
      activeWeek,
      activeDate,
      lessonKeys: myLessonKeys,
      freeSwim,
      requests: switchRequests,
      onOpenSlot: (t) => { setActiveTime(t); setView(t); },
      onOpenFree: () => setView("free"),
      onRequestPickup: requestPickup,
      onRequestDrop: requestDrop,
      onOpenRequests: () => setShowReview(true)
      }),
      // Notifications setup is useful but secondary — it lives BELOW the
      // day's important info (clock, lessons, schedule) instructors open to.
      isInstructor && !previewing && h(NotifCard, { key: "notifCard", userId: myUserId })
    ]) : view === "hours" && isOwner ? h(HoursPanel, {
      rows: instrWrites,
      accounts,
      myUserId,
      myName,
      clockTick,
      selfPunch: {
        open: myOpenShift,
        todayMs: shiftsMsForDay(myShifts, pstDateKey(), Date.now()),
        weekMs: shiftsMsForWeek(myShifts, weekKeyFor(pstDateKey()), Date.now()),
        busy: clockBusy,
        clockTick,
        onIn: () => punchClock("in"),
        onOut: () => punchClock("out")
      },
      onAdjust: ownerAdjustShifts,
      autoClockOut: (staff && staff.autoClockOut) || "",
      onSetAutoClockOut: setAutoClockOut,
      schedule: (staff && staff.schedule) || {},
      onSetSchedule: setPersonSchedule,
      lateToday
    }) : view === "today" ? h(TodayView, {
      unlinkedCheckIns,
      staffList,
      staff,
      activeDate,
      isToday: activeDate === pstDateKey(),
      isOwner,
      instructors,
      roster,
      classKey,
      freeSwim,
      onTogglePresent: toggleStaffPresent,
      onSetRole: setStaffRole,
      onAddExtra: addExtraStaff,
      onRemoveExtra: removeExtraStaff,
      onReplaceInstructor: replaceLessonInstructor,
      onReplaceGuard: replaceGuard
    }) : view === "free" ? h(RotationBoard, {
      freeSwim,
      candidates: guardCandidates,
      unlocked: editUnlocked,
      onStart: startFreeSwim,
      onStop: stopFreeSwim,
      onAddGuard: addGuard,
      onRemoveGuard: removeGuard,
      onMoveGuard: moveGuard,
      onToggleDuty: toggleOnDuty,
      onSetAllDuty: setAllDuty,
      onSetStations: setStationCount,
      onSetGroupMin: setGroupMin,
      onSetScheduleMode: setScheduleMode,
      onSetManualCell: setManualCell,
      onFillManual: fillManualFromAuto
    }) : dayClosed ? /* @__PURE__ */ jsx(ClosedBanner, { activeDate }) : view === "day" ? /* @__PURE__ */ jsx(
      DayView,
      {
        stats: dayStats,
        grid: classGrid,
        instructors,
        counts,
        search,
        students,
        freeSwim,
        onOpenSlot: (t) => {
          setActiveTime(t);
          setView(t);
        },
        onOpenFree: () => setView("free"),
        onPrintDay: () => printSheet("day"),
        onExportDay: () => exportCSV("day")
      }
    ) : /* @__PURE__ */ jsxs(Fragment, { children: [
      levelsInSlot.length > 0 && /* @__PURE__ */ jsxs("div", { style: styles.toolbar, children: [
        /* @__PURE__ */ jsxs("span", { style: styles.toolbarLabel, children: [
          activeTime,
          " roster"
        ] }),
        /* @__PURE__ */ jsxs("div", { style: styles.toolbarBtns, children: [
          /* @__PURE__ */ jsxs("button", { style: styles.toolBtn, onClick: () => printSheet(activeTime), children: [
            /* @__PURE__ */ jsx(Printer, { size: 15 }),
            " Print sheet"
          ] }),
          /* @__PURE__ */ jsxs("button", { style: styles.toolBtn, onClick: () => exportCSV(activeTime), children: [
            /* @__PURE__ */ jsx(Download, { size: 15 }),
            " Export CSV"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("main", { style: styles.main, children: [
        levelsInSlot.length === 0 ? /* @__PURE__ */ jsxs("div", { style: styles.empty, children: [
          /* @__PURE__ */ jsx(Users, { size: 28, style: { color: "var(--faint,#9DB4BF)" } }),
          /* @__PURE__ */ jsxs("p", { style: styles.emptyTitle, children: [
            "No classes at ",
            activeTime,
            " yet"
          ] }),
          /* @__PURE__ */ jsx("p", { style: styles.emptySub, children: "Add a class below to start a roster for this time." })
        ] }) : levelsInSlot.map((level) => /* @__PURE__ */ jsx(
          ClassCard,
          {
            level,
            time: activeTime,
            roster: grouped[level] || [],
            instructors: instructors[classKey(activeTime, level)] || [],
            onToggle: togglePresent,
            onRemove: removeStudent,
            onNote: updateNote,
            onMove: moveStudent,
            onRequestSwitch: requestSwitch,
            isInstructor,
            requests: switchRequests,
            onAddStudent: addStudent,
            onEditStudent: editStudent,
            onAddInstructor: addInstructor,
            onRemoveInstructor: removeInstructor,
            startAdding: (grouped[level] || []).length === 0
          },
          level
        )),
        /* @__PURE__ */ jsx(
          AddClassControl,
          {
            existingLevels: levelsInSlot,
            onAddClass: (level) => addClass(activeTime, level)
          }
        )
      ] })
    ] }),
    showSettings && /* @__PURE__ */ jsx(
      SyncSettings,
      {
        canInstall,
        isInstalled: isInstalled || isStandalone,
        onInstall: handleInstall,
        accent,
        onSetAccent: setAccent,
        onClose: () => setShowSettings(false),
        onSaved: () => {
          setShowSettings(false);
          loadedRef.current = false;
          // R1/R2: forcing a fresh reload — reset version tracking and dirty flag
          // so the reload re-establishes lastRosterUpdatedAt from the server.
          lastRosterUpdatedAtRef.current = null;
          dirtyRef.current = false;
          setSyncState("loading");
          setSbVersion((v) => v + 1);
        }
      }
    ),
    installGuide && h(InstallGuideModal, { onClose: () => setInstallGuide(false) }),
    showReview && /* @__PURE__ */ jsx(
      ReviewDialog,
      {
        isOwner,
        requests: switchRequests,
        myId: myUserId,
        myName,
        onApprove: approveSwitch,
        onReject: rejectSwitch,
        onClear: clearDecidedRequests,
        onClose: () => setShowReview(false)
      }
    ),
    showPreviewPick && isOwner && h(PreviewPicker, {
      accounts,
      onPick: enterPreview,
      onClose: () => setShowPreviewPick(false)
    }),
    showAccounts && isOwner && h(AccountsDialog, {
      accounts,
      instructors,
      roster,
      freeSwim,
      onAdd: addAccount,
      onUpdate: updateAccount,
      onRemove: removeAccount,
      onDelete: deleteAccount,
      onRestoreBackup: ownerRestoreBackup,
      backupBusy,
      onSeasonExport: (kind) => {
        const built = buildSeasonExport({ weeks, freeSwim, switchRequests, accounts, staff, instrRows: instrWrites });
        if (kind === "report") downloadText(`season-report-${pstDateKey()}.html`, built.html, "text/html");
        else downloadText(`season-data-${pstDateKey()}.json`, built.json, "application/json");
      },
      onClose: () => setShowAccounts(false)
    }),
    showScan && isOwner && h(ScanRosterModal, {
      weeks,
      activeWeek,
      onImport: importScannedStudents,
      onClose: () => setShowScan(false),
      onDone: (added, skipped) => {
        flashNotice(`Imported ${added} swimmer${added === 1 ? "" : "s"}${skipped ? `; skipped ${skipped} duplicate${skipped === 1 ? "" : "s"}` : ""}.`);
        setShowScan(false);
      }
    })
  ] });
}
function DateBar({ activeDate, activeWeek, isToday, closed, onToday, onPrevWeek, onNextWeek, onPickDay }) {
  const todayKey = pstDateKey();
  const days = weekdaysOf(activeWeek);
  const dowLabels = ["Mon", "Tue", "Wed", "Thu", "Fri"];
  return /* @__PURE__ */ jsxs("div", { style: styles.dateWrap, children: [
    /* @__PURE__ */ jsxs("div", { style: styles.weekRow, children: [
      /* @__PURE__ */ jsx("button", { style: styles.dateNav, onClick: onPrevWeek, "aria-label": "Previous week", children: /* @__PURE__ */ jsx(ChevronLeft, { size: 18 }) }),
      /* @__PURE__ */ jsxs("div", { style: styles.weekMid, children: [
        /* @__PURE__ */ jsx(Calendar, { size: 15, style: { color: legibleColor("#1D7A8C") } }),
        /* @__PURE__ */ jsxs("span", { style: styles.weekLabel, children: [
          "Week of ",
          weekLabel(activeWeek)
        ] }),
        weekKeyFor(todayKey) === activeWeek && /* @__PURE__ */ jsx("span", { style: styles.todayTag, children: "This week" })
      ] }),
      /* @__PURE__ */ jsx("button", { style: styles.dateNav, onClick: onNextWeek, "aria-label": "Next week", children: /* @__PURE__ */ jsx(ChevronRight, { size: 18 }) }),
      !isToday && /* @__PURE__ */ jsx("button", { style: styles.todayBtn, onClick: onToday, children: "Today" })
    ] }),
    /* @__PURE__ */ jsx("div", { style: styles.dayPicker, children: days.map((d, i) => {
      const sel = d === activeDate;
      const isTod = d === todayKey;
      const clo = isClosed(d);
      return /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => onPickDay(d),
          style: {
            ...styles.dayChip,
            ...sel ? styles.dayChipSel : {},
            ...clo && !sel ? styles.dayChipClosed : {}
          },
          children: [
            /* @__PURE__ */ jsx("span", { style: styles.dayChipDow, children: dowLabels[i] }),
            /* @__PURE__ */ jsx("span", { style: styles.dayChipNum, children: Number(d.split("-")[2]) }),
            isTod && /* @__PURE__ */ jsx("span", { style: { ...styles.dayChipDot, background: sel ? "#fff" : "#2DD4BF" } })
          ]
        },
        d
      );
    }) })
  ] });
}
function ClosedBanner({ activeDate }) {
  const reason = CLOSED_DATES.includes(activeDate) ? "Holiday \u2014 pool closed" : "Weekend \u2014 no lessons";
  return /* @__PURE__ */ jsxs("div", { style: styles.closedWrap, children: [
    /* @__PURE__ */ jsx("div", { style: styles.closedIcon, children: /* @__PURE__ */ jsx(Calendar, { size: 30, style: { color: "#FF6B5C" } }) }),
    /* @__PURE__ */ jsxs("p", { style: styles.closedTitle, children: [
      "Closed ",
      prettyDate(activeDate)
    ] }),
    /* @__PURE__ */ jsxs("p", { style: styles.closedSub, children: [
      reason,
      ". Attendance is off today."
    ] }),
    /* @__PURE__ */ jsx("p", { style: styles.closedHint, children: "Lessons run Monday\u2013Friday. Use the arrows above to view another day." })
  ] });
}
function DayView({ stats, grid, instructors, counts, search, students, freeSwim, onOpenSlot, onOpenFree, onPrintDay, onExportDay }) {
  const classKey = (t, l) => `${t}|${l}`;
  const q = search.trim().toLowerCase();
  const matches = q ? students.filter((s) => s.name.toLowerCase().includes(q) || s.guardian.toLowerCase().includes(q)) : [];
  if (stats.total === 0) {
    return /* @__PURE__ */ jsx("main", { style: styles.main, children: /* @__PURE__ */ jsxs("div", { style: styles.empty, children: [
      /* @__PURE__ */ jsx(Users, { size: 28, style: { color: "var(--faint,#9DB4BF)" } }),
      /* @__PURE__ */ jsx("p", { style: styles.emptyTitle, children: "No swimmers yet" }),
      /* @__PURE__ */ jsx("p", { style: styles.emptySub, children: "Rosters will appear here once they're added." })
    ] }) });
  }
  return /* @__PURE__ */ jsxs("main", { style: styles.main, children: [
    /* @__PURE__ */ jsxs("div", { style: styles.statBand, children: [
      /* @__PURE__ */ jsx(Stat, { label: "Swimmers", value: stats.total }),
      /* @__PURE__ */ jsx(Stat, { label: "Classes", value: stats.classes }),
      stats.dayOver ? /* @__PURE__ */ jsx(Stat, { label: "Here now", value: "Closed", accent: "var(--faint,#9DB4BF)" }) : stats.freeSwim ? /* @__PURE__ */ jsx(Stat, { label: "Here now \xB7 free swim", value: "Free swim", accent: "#7C5CFF" }) : /* @__PURE__ */ jsx(Stat, { label: `Here now \xB7 ${stats.nowSlot}`, value: `${stats.present}/${stats.slotTotal}`, accent: "#2DD4BF" }),
      /* @__PURE__ */ jsx(Stat, { label: "Attendance", value: `${stats.rate}%`, accent: stats.rate >= 80 ? "#2DD4BF" : stats.rate >= 50 ? "#E8A02C" : "#FF6B5C" })
    ] }),
    h(RotationMini, { freeSwim, onOpen: onOpenFree }),
    /* @__PURE__ */ jsxs("div", { style: styles.attWrap, children: [
      /* @__PURE__ */ jsx("div", { style: styles.attTrack, children: /* @__PURE__ */ jsx("div", { style: { ...styles.attFill, width: `${stats.rate}%` } }) }),
      /* @__PURE__ */ jsxs("span", { style: styles.attText, children: [
        stats.presentAll,
        " of ",
        stats.total,
        " marked present today"
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { style: styles.levelDist, children: Object.entries(stats.byLevel).map(([lvl, n]) => /* @__PURE__ */ jsxs("span", { style: styles.distChip, children: [
      /* @__PURE__ */ jsx("span", { style: { ...styles.distDot, background: levelColor(lvl) } }),
      lvl,
      /* @__PURE__ */ jsx("strong", { style: styles.distNum, children: n })
    ] }, lvl)) }),
    /* @__PURE__ */ jsxs("div", { style: styles.toolbar, children: [
      /* @__PURE__ */ jsx("span", { style: styles.toolbarLabel, children: "Whole day" }),
      /* @__PURE__ */ jsxs("div", { style: styles.toolbarBtns, children: [
        /* @__PURE__ */ jsxs("button", { style: styles.toolBtn, onClick: onPrintDay, children: [
          /* @__PURE__ */ jsx(Printer, { size: 15 }),
          " Print packet"
        ] }),
        /* @__PURE__ */ jsxs("button", { style: styles.toolBtn, onClick: onExportDay, children: [
          /* @__PURE__ */ jsx(Download, { size: 15 }),
          " Export all"
        ] })
      ] })
    ] }),
    q && /* @__PURE__ */ jsx("div", { style: styles.searchResults, children: matches.length === 0 ? /* @__PURE__ */ jsxs("p", { style: styles.emptySub, children: [
      'No swimmers match "',
      search,
      '".'
    ] }) : matches.map((s) => /* @__PURE__ */ jsxs("button", { style: styles.resultRow, onClick: () => onOpenSlot(s.time), children: [
      /* @__PURE__ */ jsx("span", { style: { ...styles.distDot, background: levelColor(s.level) } }),
      /* @__PURE__ */ jsx("span", { style: styles.resultName, children: s.name }),
      /* @__PURE__ */ jsxs("span", { style: styles.resultMeta, children: [
        s.time,
        " \xB7 ",
        s.level
      ] })
    ] }, s.id)) }),
    !q && TIME_SLOTS.map((slot) => {
      const levelsHere = LEVELS.filter((l) => grid[classKey(slot, l)]);
      return /* @__PURE__ */ jsxs("div", { style: styles.timeRow, children: [
        /* @__PURE__ */ jsxs("div", { style: styles.timeRowHead, children: [
          /* @__PURE__ */ jsx(Clock, { size: 14, style: { color: "var(--muted,#5B7A88)" } }),
          /* @__PURE__ */ jsx("span", { style: styles.timeRowLabel, children: slot }),
          /* @__PURE__ */ jsxs("span", { style: styles.timeRowCount, children: [
            counts[slot],
            " swimmers"
          ] })
        ] }),
        levelsHere.length === 0 ? /* @__PURE__ */ jsxs("div", { style: styles.gap, children: [
          /* @__PURE__ */ jsx(AlertCircle, { size: 14, style: { color: "#C9B07A" } }),
          " No classes scheduled"
        ] }) : /* @__PURE__ */ jsx("div", { style: styles.classCells, children: levelsHere.map((lvl) => {
          const cell = grid[classKey(slot, lvl)];
          const inst = instructors[classKey(slot, lvl)] || [];
          const full = cell.count >= 7;
          return /* @__PURE__ */ jsxs(
            "button",
            {
              style: { ...styles.cell, borderLeftColor: levelColor(lvl) },
              onClick: () => onOpenSlot(slot),
              children: [
                /* @__PURE__ */ jsxs("div", { style: styles.cellTop, children: [
                  /* @__PURE__ */ jsx("span", { style: { ...styles.cellLevel, color: levelColor(lvl) }, children: lvl }),
                  /* @__PURE__ */ jsx("span", { style: { ...styles.cellCount, ...full ? styles.cellFull : {} }, children: cell.count })
                ] }),
                /* @__PURE__ */ jsx("div", { style: styles.cellInst, children: inst.length ? inst.join(", ") : "No instructor" }),
                /* @__PURE__ */ jsx("div", { style: styles.cellBar, children: /* @__PURE__ */ jsx(
                  "div",
                  {
                    style: {
                      ...styles.cellBarFill,
                      width: `${cell.count ? cell.present / cell.count * 100 : 0}%`,
                      background: levelColor(lvl)
                    }
                  }
                ) })
              ]
            },
            lvl
          );
        }) })
      ] }, slot);
    }),
    !q && /* @__PURE__ */ jsxs("div", { style: { ...styles.timeRow, ...stats.freeSwim ? styles.timeRowLive : {}, ...stats.dayOver ? styles.timeRowDone : {} }, children: [
      /* @__PURE__ */ jsxs("div", { style: styles.timeRowHead, children: [
        /* @__PURE__ */ jsx(LifeBuoy, { size: 14, style: { color: stats.freeSwim ? "#7C5CFF" : "var(--muted,#5B7A88)" } }),
        /* @__PURE__ */ jsx("span", { style: styles.timeRowLabel, children: "2\u20133:25pm" }),
        /* @__PURE__ */ jsx("span", { style: styles.timeRowCount, children: "Free swim \xB7 lifeguard rotation" }),
        stats.freeSwim && /* @__PURE__ */ jsx("span", { style: styles.liveTag, children: "Now" }),
        stats.dayOver && /* @__PURE__ */ jsx("span", { style: styles.doneTag, children: "Ended" })
      ] }),
      h("button", { style: styles.freeRowBtn, onClick: onOpenFree }, [
        h(LifeBuoy, { size: 15, key: "i", style: { color: "#7C5CFF", flexShrink: 0 } }),
        h("span", { key: "t", style: { flex: 1, textAlign: "left" } }, "Open swim \u2014 3-station guard rotation. Tap to open the live board."),
        h(ChevronRight, { size: 16, key: "c", style: { color: "#7C5CFF", flexShrink: 0 } })
      ])
    ] })
  ] });
}
function Stat({ label, value, accent }) {
  const long = typeof value === "string" && value.length > 5;
  return /* @__PURE__ */ jsxs("div", { style: styles.stat, children: [
    /* @__PURE__ */ jsx("div", { style: { ...styles.statValue, ...long ? { fontSize: 16 } : {}, ...accent ? { color: accent } : {} }, children: value }),
    /* @__PURE__ */ jsx("div", { style: styles.statLabel, children: label })
  ] });
}
function reqKindLabel(r) {
  if (r.kind === "pickup") return "Pick up lesson";
  if (r.kind === "drop") return "Drop lesson";
  if (r.kind === "trade") return "Shift trade";
  if (r.kind === "timeEdit") return "Fix clock-in";
  if (r.kind === "lessonEdit") return "Lessons change";
  return "Switch swimmer";
}
function reqLine(r) {
  if (r.kind === "pickup") return `${r.toTime} ${r.toLevel}`;
  if (r.kind === "drop") return `${r.fromTime} ${r.fromLevel}`;
  if (r.kind === "trade") return `${r.fromTime} ${r.fromLevel}  \u21C4  ${r.toTime} ${r.toLevel}${r.withName ? ` (with ${r.withName})` : ""}`;
  if (r.kind === "timeEdit") return `${prettyDate(r.day)}: arrived ${fmtPunchTime(r.oldIn)}  \u2192  ${fmtPunchTime(r.newIn)}`;
  if (r.kind === "lessonEdit") return `${prettyDate(r.day)}: ${r.fromSlots ? r.fromSlots.replace(/,/g, ", ") : "no lessons"}  \u2192  ${r.toSlots ? r.toSlots.replace(/,/g, ", ") : "no lessons"}`;
  return `${r.fromTime} ${r.fromLevel}  \u2192  ${r.toTime} ${r.toLevel}`;
}
function reqApproveLabel(r) {
  if (r.kind === "pickup") return "Approve & assign";
  if (r.kind === "drop") return "Approve & remove";
  if (r.kind === "trade") return "Approve & swap";
  if (r.kind === "timeEdit") return "Approve & fix time";
  if (r.kind === "lessonEdit") return "Approve & update";
  return "Approve & move";
}
function ReviewDialog({ isOwner, requests, myId, myName, onApprove, onReject, onClear, onClose }) {
  const mineFilter = (r) => isOwner || (myId && r.byId === myId) || (!r.byId && normName(r.by) === normName(myName));
  const decided = requests.filter((r) => r.status !== "pending");
  const list = requests.filter(mineFilter);
  const pendingList = list.filter((r) => r.status === "pending");
  const decidedList = list.filter((r) => r.status !== "pending");
  const kindChip = (r) => {
    const st = r.kind === "pickup" ? styles.reqKindPickup : r.kind === "drop" ? styles.reqKindDrop : r.kind === "timeEdit" ? styles.reqKindTime : styles.reqKindSwitch;
    return h("span", { style: { ...styles.reqKind, ...st }, key: "k" }, reqKindLabel(r));
  };
  const statusChip = (r) => {
    if (r.status === "approved") return h("span", { style: { ...styles.reqStatus, ...styles.reqStatusOk }, key: "s" }, [h(Check, { size: 12, key: "i" }), " Approved"]);
    if (r.status === "rejected") return h("span", { style: { ...styles.reqStatus, ...styles.reqStatusNo }, key: "s" }, [h(X, { size: 12, key: "i" }), " Declined"]);
    return h("span", { style: { ...styles.reqStatus, ...styles.reqStatusWait }, key: "s" }, "Waiting");
  };
  const card = (r, withActions) => h("div", { style: styles.reqCard, key: r.id }, [
    h("div", { style: styles.reqTop, key: "t" }, [
      h("div", { style: styles.reqTopLeft, key: "tl" }, [
        kindChip(r),
        r.kind === "switch" && h("span", { style: styles.reqName, key: "n" }, r.studentName || "Swimmer")
      ]),
      statusChip(r)
    ]),
    h("div", { style: styles.reqMove, key: "m" }, [
      h(ArrowRightLeft, { size: 13, key: "a", style: { color: "#5B4B9E", flexShrink: 0 } }),
      h("span", { key: "x" }, reqLine(r))
    ]),
    isOwner && r.by && h("div", { style: styles.reqBy, key: "b" }, [h(Users, { size: 12, key: "i" }), " Requested by ", r.by]),
    r.reason && h("div", { style: styles.reqReason, key: "r" }, `\u201C${r.reason}\u201D`),
    withActions && h("div", { style: styles.reqActions, key: "ac" }, [
      h("button", { style: styles.reqReject, key: "no", onClick: () => onReject(r.id) }, [h(X, { size: 15, key: "i" }), " Decline"]),
      h("button", { style: styles.reqApprove, key: "ok", onClick: () => onApprove(r.id) }, [h(Check, { size: 15, key: "i" }), " " + reqApproveLabel(r)])
    ])
  ]);
  return h(Modal, { onClose, labelledBy: "lessonReqTitle" }, [
    h("div", { style: styles.modalHead, key: "h" }, [
      h("div", { key: "t" }, [
        h("div", { style: styles.kicker, key: "k" }, isOwner ? "Owner \xB7 approvals" : "Your requests"),
        h("h2", { id: "lessonReqTitle", style: styles.modalTitle, key: "ti" }, "Requests")
      ]),
      h("button", { style: styles.iconBtn, onClick: onClose, key: "x", "aria-label": "Close" }, h(X, { size: 18 }))
    ]),
    h("div", { style: { ...styles.settingsBody, paddingBottom: 8, overflowY: "auto" }, key: "b" }, [
      isOwner && h("p", { style: styles.settingsText, key: "intro" }, "Staff send switch, pick-up, drop, and clock-in fix requests here. Approving applies the change right away."),
      !isOwner && h("p", { style: styles.settingsText, key: "intro" }, "These are the changes you've asked an admin to approve. You'll see the result here once they decide."),
      pendingList.length > 0 && h("div", { style: styles.reqSectionLbl, key: "pl" }, isOwner ? `Pending (${pendingList.length})` : "Waiting for approval"),
      ...pendingList.map((r) => card(r, isOwner)),
      pendingList.length === 0 && h("div", { style: styles.reqEmpty, key: "pe" }, isOwner ? "No pending requests right now." : "You have no pending requests."),
      decidedList.length > 0 && h("div", { style: { ...styles.reqSectionLbl, marginTop: 12 }, key: "dl" }, "Recently decided"),
      ...decidedList.map((r) => card(r, false))
    ]),
    h("div", { style: styles.modalFoot, key: "f" }, [
      h("button", { style: styles.ghostBtn, onClick: onClose, key: "c" }, "Close"),
      isOwner && decided.length > 0 && h("button", { style: styles.primaryBtn, onClick: onClear, key: "cl" }, [h(Trash2, { size: 16, key: "i" }), " Clear decided"])
    ])
  ]);
}
// ---- Today: staff check-in, coverage board, and no-show replacements ----
// One screen the owner runs each morning. Attendance is keyed by the active date,
// so a fresh day shows everyone present again (the "reset"). Instructors get a
// read-only view (owner-gated toggles/replacements are no-ops for them upstream).
function roleLabel(role) {
  return role === "lifeguard" ? "Lifeguard" : role === "both" ? "Both" : "Instructor";
}
function canTeach(role) { return role === "instructor" || role === "both"; }
function canGuard(role) { return role === "lifeguard" || role === "both"; }
function StaffRoleBadge({ role }) {
  const st = role === "lifeguard" ? styles.stRoleGuard : role === "both" ? styles.stRoleBoth : styles.stRoleInstr;
  return h("span", { style: { ...styles.stRoleBadge, ...st } }, roleLabel(role));
}
function TodayView({ unlinkedCheckIns, staffList, staff, activeDate, isToday, isOwner, instructors, roster, classKey, freeSwim, onTogglePresent, onSetRole, onAddExtra, onRemoveExtra, onReplaceInstructor, onReplaceGuard }) {
  const [picker, setPicker] = useState(null); // { kind:"lesson"|"guard", time, level, name }
  const [newName, setNewName] = useState("");
  const presentCount = staffList.filter((p) => p.present).length;
  const presentByName = (name) => {
    const p = staffList.find((s) => normName(s.name) === normName(name));
    return p ? p.present : true; // people not on the roster (rare) treated as present
  };
  // Real classes today = class keys with >=1 student on the active week's roster.
  const realClasses = [];
  const seenKeys = /* @__PURE__ */ new Set();
  (roster || []).forEach((s) => {
    const k = classKey(s.time, s.level);
    if (seenKeys.has(k)) return;
    seenKeys.add(k);
    realClasses.push({ key: k, time: s.time, level: s.level, names: instructors[k] || [] });
  });
  realClasses.sort((a, b) => TIME_SLOTS.indexOf(a.time) - TIME_SLOTS.indexOf(b.time) || a.level.localeCompare(b.level));
  const onDutyGuards = (freeSwim && freeSwim.onDuty && freeSwim.onDuty.length ? freeSwim.onDuty : (freeSwim && freeSwim.guards) || []);
  // Available replacements for a slot = present staff with the matching capability,
  // minus the absent person being replaced.
  const replacementsFor = (kind, exclude) => staffList.filter((p) =>
    p.present && normName(p.name) !== normName(exclude) &&
    (kind === "guard" ? canGuard(p.role) : canTeach(p.role))
  );
  const closePicker = () => setPicker(null);
  const choose = (name) => {
    if (!picker) return;
    if (picker.kind === "guard") onReplaceGuard(picker.name, name);
    else onReplaceInstructor(picker.time, picker.level, picker.name, name);
    closePicker();
  };
  const extraNames = new Set((staff.extra || []).map((e) => normName(e.name)));
  return h("main", { style: styles.main, key: "todaymain" }, [
    // ---- A. Daily check-in ----
    h("div", { style: styles.stHeadRow, key: "ah" }, [
      h("div", { key: "l" }, [
        h("div", { style: styles.kicker, key: "k" }, isToday ? "Today \xB7 staff check-in" : "Staff check-in"),
        h("h2", { style: styles.stTitle, key: "t" }, "Who's here")
      ]),
      h("span", { style: styles.stCount, key: "c" }, `${presentCount} of ${staffList.length} here`)
    ]),
    isOwner && Array.isArray(unlinkedCheckIns) && unlinkedCheckIns.length > 0 && h("div", { style: styles.ambWarn, key: "unlinked" }, [
      h("div", { style: styles.ambWarnHead, key: "h" }, [h(AlertCircle, { size: 15, key: "i" }), " Check-ins that aren't linked to a staff name"]),
      ...unlinkedCheckIns.map((u, i) => h("div", { style: styles.ambWarnRow, key: i }, `${u.label} answered "${u.mark === "present" ? "I'm here" : "I'm out"}" but doesn't match anyone on the staff list. Open Instructor accounts and make their account name match their staff name.`)),
      h("div", { style: styles.ambWarnRow, key: "why" }, "Until it's fixed, their answer can't mark the right card present or absent.")
    ]),
    !isOwner && h("p", { style: styles.settingsText, key: "ro" }, "Read-only — the owner manages check-in and replacements."),
    h("div", { style: styles.stGrid, key: "checkin" }, staffList.length === 0
      ? [h("div", { style: styles.reqEmpty, key: "e" }, "No staff yet. Add people below or create instructor logins.")]
      : staffList.map((p) => h("div", { style: { ...styles.stCard, ...p.present ? {} : styles.stCardAbsent }, key: p.name }, [
          h("div", { style: styles.stCardTop, key: "top" }, [
            // flex:1 + minWidth guarantee the NAME always renders — previously
            // the two no-shrink chips could squeeze it to zero width on phones,
            // leaving nameless "SELF-CHECKED-IN" cards.
            h("span", { style: { ...styles.stName, flex: "1 1 auto", minWidth: 0 }, key: "n" }, (p.displayFull ? p.name : firstNameCap(p.name)) || p.name || "Unnamed — tap to rename"),
            h(StaffRoleBadge, { role: p.role, key: "b" })
          ]),
          p.selfChecked && h("div", { key: "scRow", style: { display: "flex", marginTop: -3 } },
            h("span", { style: { ...styles.selfCheckTag, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis" }, title: "Confirmed by the instructor's own check-in" }, "✓ Checked in")
          ),
          // Their own "which lessons today" answer from the daily check-in.
          p.selfChecked && typeof p.todayLessons === "string" && h("div", { key: "lesRow", style: { fontSize: 12, fontWeight: 700, color: "var(--muted,#5B7A88)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } },
            p.todayLessons ? `Lessons: ${p.todayLessons.replace(/,/g, " · ")}` : "No lessons today"),
          h("button", {
            key: "tg",
            style: { ...styles.stToggle, ...p.present ? styles.stTogglePresent : styles.stToggleAbsent, ...isOwner ? {} : styles.stToggleDisabled },
            disabled: !isOwner,
            onClick: () => onTogglePresent(p.name),
            "aria-pressed": !p.present,
            title: isOwner ? "Tap to flip present / no-show" : void 0
          }, p.present ? [h(Check, { size: 14, key: "i" }), " Present"] : [h(X, { size: 14, key: "i" }), " No-show"])
        ]))
    ),
    // ---- B. Coverage board ----
    h("div", { style: { ...styles.stHeadRow, marginTop: 18 }, key: "bh" }, [
      h("div", { key: "l" }, [
        h("div", { style: styles.kicker, key: "k" }, "Coverage"),
        h("h2", { style: styles.stTitle, key: "t" }, "Who's doing what")
      ])
    ]),
    h("div", { style: styles.stCoverGrid, key: "cover" }, [
      // Teaching lessons column
      h("div", { style: styles.stCoverCol, key: "teach" }, [
        h("div", { style: styles.stColHead, key: "h" }, [h(Waves, { size: 15, key: "i" }), " Teaching lessons"]),
        realClasses.length === 0
          ? h("div", { style: styles.reqEmpty, key: "e" }, "No classes with swimmers today.")
          : realClasses.map((c) => h("div", { style: styles.stCoverRow, key: c.key }, [
              h("div", { style: styles.stCoverMeta, key: "m" }, [
                h("span", { style: styles.stCoverWhen, key: "w" }, `${c.time} \xB7 ${c.level}`)
              ]),
              h("div", { style: styles.stCoverWho, key: "who" }, c.names.length === 0
                ? [h("span", { style: styles.instNone, key: "u" }, "Unassigned")]
                : c.names.map((nm) => {
                    const here = presentByName(nm);
                    return h("span", { style: { ...styles.stWhoChip, ...here ? {} : styles.stWhoChipAbsent }, key: nm }, [
                      firstNameCap(nm) || nm,
                      !here && isOwner && h("button", {
                        key: "rep",
                        style: styles.stReplaceBtn,
                        onClick: () => setPicker({ kind: "lesson", time: c.time, level: c.level, name: nm }),
                        title: `Find a replacement for ${nm}`
                      }, "Replace"),
                      !here && !isOwner && h("span", { style: styles.stAbsentTag, key: "a" }, "absent")
                    ]);
                  }))
            ]))
      ]),
      // Lifeguarding column
      h("div", { style: styles.stCoverCol, key: "guard" }, [
        h("div", { style: styles.stColHead, key: "h" }, [h(LifeBuoy, { size: 15, key: "i" }), " Lifeguarding"]),
        onDutyGuards.length === 0
          ? h("div", { style: styles.reqEmpty, key: "e" }, "No lifeguards on duty.")
          : onDutyGuards.map((nm) => {
              const here = presentByName(nm);
              return h("div", { style: styles.stCoverRow, key: nm }, [
                h("div", { style: styles.stCoverWho, key: "who" }, [
                  h("span", { style: { ...styles.stWhoChip, ...here ? {} : styles.stWhoChipAbsent }, key: "c" }, [
                    firstNameCap(nm) || nm,
                    !here && isOwner && h("button", {
                      key: "rep",
                      style: styles.stReplaceBtn,
                      onClick: () => setPicker({ kind: "guard", name: nm }),
                      title: `Find a replacement for ${nm}`
                    }, "Replace"),
                    !here && !isOwner && h("span", { style: styles.stAbsentTag, key: "a" }, "absent")
                  ])
                ])
              ]);
            })
      ])
    ]),
    // ---- D. Staff manager (owner-only) ----
    isOwner && h("div", { style: { ...styles.stHeadRow, marginTop: 18 }, key: "dh" }, [
      h("div", { key: "l" }, [
        h("div", { style: styles.kicker, key: "k" }, "Manage"),
        h("h2", { style: styles.stTitle, key: "t" }, "Staff & capabilities")
      ])
    ]),
    isOwner && h("div", { style: styles.acctAddCard, key: "add" }, [
      h("label", { style: styles.fieldLabel, key: "lbl" }, "Add a staff member (no login needed)"),
      h("div", { style: { display: "flex", gap: 8 }, key: "row" }, [
        h("input", {
          key: "in",
          style: { ...styles.search, flex: 1 },
          placeholder: "Name…",
          value: newName,
          onChange: (e) => setNewName(e.target.value),
          onKeyDown: (e) => { if (e.key === "Enter" && newName.trim()) { onAddExtra(newName); setNewName(""); } }
        }),
        h("button", {
          key: "btn",
          style: styles.acctAddBtn,
          onClick: () => { if (newName.trim()) { onAddExtra(newName); setNewName(""); } }
        }, [h(UserPlus, { size: 16, key: "i" }), " Add"])
      ])
    ]),
    isOwner && h("div", { style: { ...styles.stGrid, gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))" }, key: "manage" }, staffList.map((p) => {
      const isExtra = extraNames.has(normName(p.name));
      return h("div", { style: styles.stCard, key: p.name }, [
        h("div", { style: styles.stCardTop, key: "top" }, [
          h("span", { style: styles.stName, key: "n" }, p.name),
          isExtra && h("button", {
            key: "rm",
            style: styles.iconBtn,
            onClick: () => onRemoveExtra(p.name),
            "aria-label": `Remove ${p.name}`,
            title: "Remove this staff member"
          }, h(Trash2, { size: 15 }))
        ]),
        h("div", { style: styles.stRoleSeg, key: "seg" }, STAFF_ROLES.map((r) => h("button", {
          key: r,
          style: { ...styles.stRoleSegBtn, ...p.role === r ? styles.stRoleSegBtnOn : {} },
          onClick: () => onSetRole(p.name, r),
          "aria-pressed": p.role === r
        }, roleLabel(r))))
      ]);
    })),
    // ---- C. Replacement picker modal ----
    picker && h(Modal, { onClose: closePicker, labelledBy: "stReplaceTitle", key: "modal", style: { maxWidth: 380 } }, h(Fragment, null, [
      h("div", { style: styles.modalHead, key: "h" }, [
        h("div", { key: "l" }, [
          h("div", { style: styles.kicker, key: "k" }, picker.kind === "guard" ? "Lifeguard \xB7 no-show" : `${picker.time} \xB7 ${picker.level}`),
          h("h2", { id: "stReplaceTitle", style: styles.modalTitle, key: "t" }, `Replace ${firstNameCap(picker.name) || picker.name}`)
        ]),
        h("button", { style: styles.iconBtn, onClick: closePicker, key: "x", "aria-label": "Close" }, h(X, { size: 18 }))
      ]),
      h("div", { style: { ...styles.settingsBody, paddingBottom: 8, overflowY: "auto" }, key: "b" }, (() => {
        const opts = replacementsFor(picker.kind, picker.name);
        if (opts.length === 0) return [h("div", { style: styles.reqEmpty, key: "e" }, `No available ${picker.kind === "guard" ? "lifeguards" : "instructors"} are present right now.`)];
        return opts.map((p) => h("button", {
          key: p.name,
          style: styles.stPickRow,
          onClick: () => choose(p.name)
        }, [
          h("span", { style: styles.stName, key: "n" }, p.name),
          h(StaffRoleBadge, { role: p.role, key: "b" })
        ]));
      })()),
      h("div", { style: styles.modalFoot, key: "f" }, [
        h("button", { style: styles.ghostBtn, onClick: closePicker, key: "c" }, "Cancel")
      ])
    ]))
  ]);
}
// A1: shared accessible dialog wrapper. Renders the existing backdrop + panel
// styling but adds dialog semantics, focus trap, Escape-to-close, and focus
// restore. Behaviour-preserving: backdrop click still closes, inner click still
// stops propagation. If something inside already holds focus (e.g. an autoFocus
// input), the trap does NOT steal it.
// Instructor-only daily self check-in. Rendered first (over everything) when it
// applies. No close/X — Modal gets no onClose, so Escape/backdrop can't dismiss
// it; the instructor must answer. Answering updates dashboards everywhere via the
// __self merge and persists so they aren't re-asked today.
function CheckInPrompt({ onAnswer, defaultSlots }) {
  // Step 1: are you here? Step 2 (if yes): which lessons today? The slot picker
  // pre-selects their assigned lessons; the combined answer saves in one tap.
  const [step, setStep] = useState("here"); // here | lessons
  const [slots, setSlots] = useState(() => Array.isArray(defaultSlots) ? defaultSlots.filter((s) => TIME_SLOTS.includes(s)) : []);
  const toggleSlot = (t) => setSlots((p) => p.includes(t) ? p.filter((x) => x !== t) : [...p, t].sort((a, b) => TIME_SLOTS.indexOf(a) - TIME_SLOTS.indexOf(b)));
  return h(
    Modal,
    { labelledBy: "checkInTitle", style: { maxWidth: 420 } },
    h(Fragment, null, [
      h("div", { style: { ...styles.modalHead, justifyContent: "flex-start" }, key: "h" },
        h("div", { key: "l" }, [
          h("div", { style: styles.kicker, key: "k" }, "Daily check-in"),
          h("h2", { id: "checkInTitle", style: styles.modalTitle, key: "t" }, step === "here" ? "Are you here today?" : "Which lessons do you have today?")
        ])
      ),
      step === "here" && h("div", { style: { padding: "0 18px 6px" }, key: "b" },
        h("p", { style: styles.settingsText, key: "p" }, "Let the team know if you're in for today's lessons.")
      ),
      step === "here" && h("div", { style: { display: "flex", gap: 10, padding: "10px 18px 18px" }, key: "f" }, [
        h("button", {
          style: styles.primaryBtn,
          key: "yes",
          onClick: () => setStep("lessons")
        }, [h(Check, { size: 16, key: "i" }), " Yes, I'm here"]),
        h("button", {
          style: { ...styles.ghostBtn, flex: 1 },
          key: "no",
          onClick: () => onAnswer("absent", "")
        }, [h(X, { size: 16, key: "i" }), " No, I'm out"])
      ]),
      step === "lessons" && h("div", { style: { padding: "0 18px 6px" }, key: "b2" }, [
        h("p", { style: styles.settingsText, key: "p" }, "Tap every time slot you're teaching today — it shows on the schedule. Changing it later needs an admin's OK."),
        h("div", { key: "chips", style: { display: "flex", flexWrap: "wrap", gap: 8, marginTop: 4 } }, TIME_SLOTS.map((t) => {
          const on = slots.includes(t);
          return h("button", {
            key: t,
            "aria-pressed": on,
            style: { border: on ? "1.5px solid #0E9F8E" : "1.5px solid var(--border,#DCE6E8)", background: on ? "rgba(45,212,191,.16)" : "var(--surface)", color: on ? legibleColor("#0B6B60") : "var(--text)", borderRadius: 999, padding: "10px 16px", fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "inherit" },
            onClick: () => toggleSlot(t)
          }, [on && h(Check, { size: 13, key: "i", style: { verticalAlign: -2, marginRight: 4 } }), t]);
        }))
      ]),
      step === "lessons" && h("div", { style: { display: "flex", gap: 10, padding: "10px 18px 18px" }, key: "f2" }, [
        h("button", { style: { ...styles.ghostBtn, flex: "0 0 auto" }, key: "back", onClick: () => setStep("here") }, "Back"),
        h("button", {
          style: styles.primaryBtn,
          key: "ok",
          onClick: () => onAnswer("present", slots.join(","))
        }, [h(Check, { size: 16, key: "i" }), slots.length ? ` Confirm ${slots.length} lesson${slots.length === 1 ? "" : "s"}` : " No lessons today"])
      ])
    ])
  );
}
// Shows the instructor's own "lessons today" answer on My Lessons, with a
// request-a-change editor — the fix goes to an admin, never applies directly.
function TodayLessonsCard({ slots, pending, onRequest }) {
  const [edit, setEdit] = useState(null); // null | array of slots
  const cur = String(slots || "");
  const curList = cur ? cur.split(",") : [];
  const toggleSlot = (t) => setEdit((p) => (p || []).includes(t) ? (p || []).filter((x) => x !== t) : [...(p || []), t].sort((a, b) => TIME_SLOTS.indexOf(a) - TIME_SLOTS.indexOf(b)));
  const changed = edit && edit.join(",") !== cur;
  return h("section", { style: { ...styles.card, padding: "12px 13px", display: "flex", flexDirection: "column", gap: 8 } }, [
    h("div", { key: "top", style: { display: "flex", alignItems: "center", gap: 8 } }, [
      h(Waves, { size: 16, key: "i", style: { color: legibleColor("#1D7A8C"), flexShrink: 0 } }),
      h("div", { key: "t", style: { fontWeight: 800, fontSize: 14, color: "var(--text)" } }, "Your lessons today"),
      h("div", { key: "v", style: { marginLeft: "auto", fontSize: 13, fontWeight: 800, color: legibleColor("#0B3C5D"), whiteSpace: "nowrap" } }, curList.length ? curList.join(" · ") : "None")
    ]),
    pending && h("div", { key: "pend", style: { ...styles.pendingTag, alignSelf: "flex-start", marginTop: 0 } }, [
      h(ArrowRightLeft, { size: 11, key: "i" }),
      ` Change sent (${pending.toSlots ? pending.toSlots.replace(/,/g, ", ") : "no lessons"}) · waiting for admin`
    ]),
    !pending && !edit && h("button", {
      key: "editbtn",
      style: { alignSelf: "flex-start", background: "none", border: "none", padding: "10px 0", margin: "-6px 0", fontSize: 12.5, fontWeight: 700, color: legibleColor("#1D7A8C"), textDecoration: "underline", cursor: "pointer", fontFamily: "inherit" },
      onClick: () => setEdit(curList)
    }, "Wrong? Ask an admin to change it"),
    !pending && edit && h("div", { key: "editor", style: { display: "flex", flexDirection: "column", gap: 8 } }, [
      h("div", { key: "chips", style: { display: "flex", flexWrap: "wrap", gap: 7 } }, TIME_SLOTS.map((t) => {
        const on = edit.includes(t);
        return h("button", {
          key: t,
          "aria-pressed": on,
          style: { border: on ? "1.5px solid #0E9F8E" : "1.5px solid var(--border,#DCE6E8)", background: on ? "rgba(45,212,191,.16)" : "var(--surface)", color: on ? legibleColor("#0B6B60") : "var(--text)", borderRadius: 999, padding: "8px 13px", fontWeight: 800, fontSize: 13, cursor: "pointer", fontFamily: "inherit" },
          onClick: () => toggleSlot(t)
        }, t);
      })),
      h("div", { key: "b", style: { display: "flex", gap: 8 } }, [
        h("button", { key: "c", style: { background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", color: "var(--muted,#5B7A88)", borderRadius: 9, padding: "9px 12px", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "inherit" }, onClick: () => setEdit(null) }, "Cancel"),
        h("button", {
          key: "s",
          style: { ...styles.reqSendBtn, marginTop: 0, width: "auto", flex: 1, ...changed ? {} : { opacity: 0.55, cursor: "default" } },
          disabled: !changed,
          onClick: () => { onRequest(edit.join(",")); setEdit(null); }
        }, [h(Check, { size: 14, key: "i" }), " Send for approval"])
      ])
    ])
  ]);
}
function Modal({ onClose, labelledBy, style, children }) {
  const panelRef = useRef(null);
  useEffect(() => {
    const panel = panelRef.current;
    const prevActive = document.activeElement;
    if (panel && !panel.contains(document.activeElement)) {
      const focusables = panel.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
      if (focusables.length) focusables[0].focus();
      else panel.focus();
    }
    return () => {
      if (prevActive && typeof prevActive.focus === "function") prevActive.focus();
    };
  }, []);
  const onKeyDown = (e) => {
    if (e.key === "Escape") { e.stopPropagation(); onClose && onClose(); return; }
    if (e.key !== "Tab") return;
    const panel = panelRef.current;
    if (!panel) return;
    const nodes = Array.prototype.slice.call(
      panel.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')
    ).filter((n) => !n.disabled && n.offsetParent !== null);
    if (!nodes.length) return;
    const first = nodes[0];
    const last = nodes[nodes.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };
  return h("div", { style: styles.modalWrap, onClick: onClose }, h("div", {
    ref: panelRef,
    style: style ? { ...styles.modal, ...style } : styles.modal,
    onClick: (e) => e.stopPropagation(),
    onKeyDown,
    role: "dialog",
    "aria-modal": "true",
    "aria-labelledby": labelledBy || void 0,
    tabIndex: -1
  }, children));
}
function SyncSettings({ onClose, onSaved, canInstall, isInstalled, onInstall, accent, onSetAccent }) {
  const installLabel = isInstalled ? "Installed" : "Add to Home Screen";
  const installRow = isInstalled
    ? h("div", { style: { ...styles.installBtn, ...styles.installBtnDone, cursor: "default" }, key: "ins" }, [
        h("div", { style: styles.installIconWrap, key: "i" }, h(Check, { size: 20 })),
        h("div", { style: styles.installTextWrap, key: "t" }, [
          h("span", { style: styles.installTitle, key: "tt" }, "Installed ✓"),
          h("span", { style: styles.installSub, key: "ts" }, "This app is on your home screen")
        ])
      ])
    : h("button", { style: styles.installBtn, onClick: onInstall, key: "ins" }, [
        h("div", { style: styles.installIconWrap, key: "i" }, h(Download, { size: 20 })),
        h("div", { style: styles.installTextWrap, key: "t" }, [
          h("span", { style: styles.installTitle, key: "tt" }, installLabel),
          h("span", { style: styles.installSub, key: "ts" }, "Install this app on your phone or computer")
        ]),
        h(Plus, { size: 18, style: { flexShrink: 0, opacity: 0.55 }, key: "p" })
      ]);
  return /* @__PURE__ */ h(Modal, { onClose, labelledBy: "syncSettingsTitle", children: /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { style: styles.modalHead, children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("div", { style: styles.kicker, children: "Settings" }),
        /* @__PURE__ */ jsx("h2", { id: "syncSettingsTitle", style: styles.modalTitle, children: "Sync & accounts" })
      ] }),
      /* @__PURE__ */ jsx("button", { style: styles.iconBtn, onClick: onClose, "aria-label": "Close", children: /* @__PURE__ */ jsx(X, { size: 18 }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { style: styles.settingsBody, children: [
      installRow,
      /* @__PURE__ */ jsx("div", { style: styles.pwDivider }),
      /* @__PURE__ */ jsx("p", { style: styles.settingsText, children: "Every roster, attendance mark, and request syncs automatically across all devices through your secure Supabase project. There's nothing to configure here." }),
      /* @__PURE__ */ jsx("div", { style: styles.pwDivider }),
      /* @__PURE__ */ jsx("label", { style: styles.fieldLabel, children: "App color" }),
      h("div", { key: "accents", style: { display: "flex", gap: 12, flexWrap: "wrap", margin: "6px 0 2px" } }, [
        ["pool", "Pool", "#0B3C5D", "#2DD4BF"],
        ["sunset", "Sunset", "#46203E", "#E8853C"],
        ["forest", "Forest", "#0E3B2E", "#3BAF7E"],
        ["midnight", "Midnight", "#232B52", "#7C8BE0"]
      ].map(([id, label, a, b]) => h("button", {
        key: id,
        onClick: () => onSetAccent && onSetAccent(id),
        "aria-pressed": accent === id,
        "aria-label": `${label} theme`,
        style: { display: "flex", flexDirection: "column", alignItems: "center", gap: 6, background: "none", border: "none", cursor: "pointer", fontFamily: "inherit", padding: 4 }
      }, [
        h("span", { key: "s", "aria-hidden": true, style: { width: 44, height: 44, borderRadius: 999, background: `linear-gradient(135deg, ${a} 58%, ${b} 58%)`, boxShadow: accent === id ? `0 0 0 3px var(--surface,#fff), 0 0 0 6px ${b}` : "inset 0 0 0 1px rgba(0,0,0,.15)" } }),
        h("span", { key: "l", style: { fontSize: 12, fontWeight: accent === id ? 800 : 600, color: accent === id ? "var(--heading)" : "var(--muted,#5B7A88)" } }, label)
      ]))),
      /* @__PURE__ */ jsx("p", { style: styles.settingsText, children: "Your pick only changes this device. Dark mode is the moon button in the header." }),
      /* @__PURE__ */ jsx("div", { style: styles.pwDivider }),
      /* @__PURE__ */ jsx("label", { style: styles.fieldLabel, children: "Accounts & roles" }),
      /* @__PURE__ */ jsx("p", { style: styles.settingsText, children: "You sign in with your own email and password. The owner has full editing and approves lesson-switch requests. Instructors can take attendance and request switches, pickups, and drops. To add or pause an instructor, the owner uses the Requests \u2192 Accounts panel." })
    ] }),
    /* @__PURE__ */ jsx("div", { style: styles.modalFoot, children: /* @__PURE__ */ jsx("button", { style: styles.primaryBtn, onClick: onClose, children: "Done" }) })
  ] }) });
}
// --- Add-to-Home-Screen instructions modal --------------------------------
// Shown when the browser offers no native install prompt (notably iOS Safari,
// which has no install API). Detects the browser from the UA and renders the
// matching step-by-step guide. UI only — no data, no side effects.
function detectInstallPlatform() {
  let ua = "";
  try {
    ua = (typeof navigator !== "undefined" && navigator.userAgent) ? navigator.userAgent : "";
  } catch {
    ua = "";
  }
  const isIOS = /iphone|ipad|ipod/i.test(ua);
  const isAndroid = /android/i.test(ua);
  const isSamsung = /SamsungBrowser/i.test(ua);
  if (isIOS) return "ios";
  if (isSamsung) return "samsung";
  if (isAndroid) return "android";
  return "desktop";
}
// Inline up-arrow-in-square glyph mirroring the iOS Safari "Share" icon, so the
// guide reads clearly even though no lucide Share/Upload icon is imported.
function ShareGlyph() {
  return h("svg", {
    width: 18, height: 18, viewBox: "0 0 24 24", fill: "none",
    stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round",
    "aria-hidden": "true", style: { verticalAlign: "-3px", margin: "0 2px" }
  }, [
    h("path", { d: "M12 3v12", key: "a" }),
    h("path", { d: "M8 7l4-4 4 4", key: "b" }),
    h("path", { d: "M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7", key: "c" })
  ]);
}
function InstallGuideModal({ onClose }) {
  const platform = detectInstallPlatform();
  let steps;
  if (platform === "ios") {
    steps = [
      h("p", { style: styles.settingsText, key: "p" }, "To add this app to your iPhone or iPad home screen in Safari:"),
      h("ol", { style: styles.installSteps, key: "o" }, [
        h("li", { key: "1" }, ["Tap the ", h("strong", { key: "s" }, "Share"), " button ", h(ShareGlyph, { key: "g" }), " (a square with an up-arrow) at the bottom of Safari."]),
        h("li", { key: "2" }, ["Scroll down and tap ", h("strong", { key: "s" }, "Add to Home Screen"), "."]),
        h("li", { key: "3" }, ["Tap ", h("strong", { key: "s" }, "Add"), " in the top-right corner."])
      ])
    ];
  } else if (platform === "samsung") {
    steps = [
      h("p", { style: styles.settingsText, key: "p" }, "To add this app to your home screen in Samsung Internet:"),
      h("ol", { style: styles.installSteps, key: "o" }, [
        h("li", { key: "1" }, ["Tap the ", h("strong", { key: "s" }, "☰ menu"), " (bottom bar)."]),
        h("li", { key: "2" }, ["Tap ", h("strong", { key: "s" }, "Add page to"), " → ", h("strong", { key: "s2" }, "Home screen"), "."]),
        h("li", { key: "3" }, ["Tap ", h("strong", { key: "s" }, "Add"), "."])
      ])
    ];
  } else if (platform === "android") {
    steps = [
      h("p", { style: styles.settingsText, key: "p" }, "To add this app to your home screen in Chrome:"),
      h("ol", { style: styles.installSteps, key: "o" }, [
        h("li", { key: "1" }, ["Tap the ", h("strong", { key: "s" }, "⋮ menu"), " (top-right)."]),
        h("li", { key: "2" }, ["Tap ", h("strong", { key: "s" }, "Install app"), " or ", h("strong", { key: "s2" }, "Add to Home screen"), "."]),
        h("li", { key: "3" }, ["Tap ", h("strong", { key: "s" }, "Add"), "."])
      ])
    ];
  } else {
    steps = [
      h("p", { style: styles.settingsText, key: "p" }, "To install this app on your computer:"),
      h("ol", { style: styles.installSteps, key: "o" }, [
        h("li", { key: "1" }, ["Look for the install icon in your browser's address bar."]),
        h("li", { key: "2" }, ["Or open the browser menu and choose ", h("strong", { key: "s" }, "Install"), "."])
      ])
    ];
  }
  return h(Modal, { onClose, labelledBy: "installGuideTitle", style: { maxWidth: 420 } }, h(Fragment, null, [
    h("div", { style: styles.modalHead, key: "head" }, [
      h("div", { key: "h" }, [
        h("div", { style: styles.kicker, key: "k" }, "Install"),
        h("h2", { id: "installGuideTitle", style: styles.modalTitle, key: "t" }, "Add to Home Screen")
      ]),
      h("button", { style: styles.iconBtn, onClick: onClose, "aria-label": "Close", key: "x" }, h(X, { size: 18 }))
    ]),
    h("div", { style: { ...styles.settingsBody, paddingBottom: 8 }, key: "body" }, steps),
    h("div", { style: styles.modalFoot, key: "foot" }, h("button", { style: styles.primaryBtn, onClick: onClose }, "Got it"))
  ].filter(Boolean)));
}
// --- Scan roster modal ----------------------------------------------------
// Owner picks/takes many roster photos; we downscale + scan each (throttled),
// then show an editable review grouped by class, then import into a week.
function ScanRosterModal({ weeks, activeWeek, onImport, onClose, onDone }) {
  const [phase, setPhase] = useState("pick"); // pick | scanning | review
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [rows, setRows] = useState([]);       // flat, editable swimmer rows
  const [failed, setFailed] = useState([]);   // [{ name, error }] photos that didn't read
  const [targetWeek, setTargetWeek] = useState(activeWeek);
  const [error, setError] = useState("");
  const [pasteText, setPasteText] = useState("");
  const cancelRef = useRef(false);
  useEffect(() => () => { cancelRef.current = true; }, []);

  // Week options for the target dropdown: every known week + the active one,
  // sorted, so the owner can import into a different week than they're viewing.
  const weekKeys = Array.from(new Set([...(weeks ? Object.keys(weeks) : []), activeWeek])).filter(Boolean).sort();
  // Wrong-week guard: targetWeek defaults to the week being VIEWED, which once
  // sent a whole paste into a past week. Week keys are YYYY-MM-DD Mondays, so
  // string compare against today's week is a chronological compare.
  const todayWeek = weekKeyFor(pstDateKey());
  const targetIsPast = targetWeek < todayWeek;

  const nudgeLevel = (raw) => {
    const v = String(raw || "").trim();
    if (LEVELS.includes(v)) return v;
    const lc = v.toLowerCase();
    if (lc.includes("div")) return "Diving";
    const m = lc.match(/level\s*([1-6])/);
    if (m) return `Level ${m[1]}`;
    const n = lc.match(/\b([1-6])\b/);
    if (n) return `Level ${n[1]}`;
    return "";
  };
  const nudgeTime = (raw) => {
    const v = String(raw || "").trim().toLowerCase().replace(/\s+/g, "");
    if (TIME_SLOTS.includes(v)) return v;
    const m = v.match(/(\d{1,2})/);
    if (m) {
      const hr = Number(m[1]);
      const slot = TIME_SLOTS.find((t) => t === `${hr}am` || t === `${hr}pm`);
      if (slot) return slot;
    }
    return "";
  };

  // Paste import: same review + import flow as photos, no photo needed.
  // Accepts a JSON array of { name, guardian, age, level, time, balance } OR
  // one swimmer per line, tab- or comma-separated:
  //   Name, Guardian, Age, Level, Time, Balance
  // Level/time are nudged with the same helpers the photo scan uses, and
  // anything ambiguous is fixed in the review step before importing.
  const onPasteReview = () => {
    setError("");
    const text = String(pasteText || "").trim();
    if (!text) { setError("Paste roster text first — one swimmer per line."); return; }
    let parsed = [];
    let json = null;
    if (text[0] === "[" || text[0] === "{") {
      try { json = JSON.parse(text); } catch { json = null; }
    }
    if (json && !Array.isArray(json) && Array.isArray(json.students)) json = json.students;
    if (Array.isArray(json)) {
      parsed = json.map((r) => ({
        name: String((r && r.name) || "").trim(),
        guardian: String((r && r.guardian) || "").trim(),
        age: r && r.age != null ? String(r.age) : "",
        balance: r && r.balance != null ? String(r.balance) : "0",
        level: nudgeLevel(r && r.level),
        time: nudgeTime(r && r.time)
      }));
    } else {
      const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
      parsed = lines.map((line) => {
        const parts = (line.includes("\t") ? line.split("\t") : line.split(",")).map((p) => p.trim());
        return {
          name: parts[0] || "",
          guardian: parts[1] || "",
          age: parts[2] || "",
          level: nudgeLevel(parts[3]),
          time: nudgeTime(parts[4]),
          balance: parts[5] || "0"
        };
      });
      // Drop a pasted header row ("Name, Guardian, ...") if one came along.
      if (parsed.length && /^name$/i.test(parsed[0].name)) parsed.shift();
    }
    const ready = parsed.filter((r) => r.name).map((r, i) => ({ key: `paste-${i}`, ...r }));
    if (ready.length === 0) { setError("No swimmers found in the pasted text."); return; }
    setRows(ready);
    setFailed([]);
    setPhase("review");
  };

  const onFiles = async (fileList) => {
    setError("");
    const files = Array.prototype.slice.call(fileList || []);
    if (!files.length) return;
    cancelRef.current = false;
    setPhase("scanning");
    setProgress({ done: 0, total: files.length });
    const collected = [];
    const fails = [];
    for (let i = 0; i < files.length; i++) {
      if (cancelRef.current) return;
      const file = files[i];
      try {
        const { base64, mimeType } = await downscaleImageFile(file);
        const res = await scanRosterPhoto(base64, mimeType);
        const level = nudgeLevel(res && res.level);
        const time = nudgeTime(res && res.time);
        const students = (res && Array.isArray(res.students) ? res.students : []).filter((s) => s && String(s.name || "").trim());
        if (students.length === 0) {
          fails.push({ name: file.name || `Photo ${i + 1}`, error: "No swimmers were read from this photo." });
        } else {
          students.forEach((s, j) => {
            collected.push({
              key: `scan-${i}-${j}`,
              name: String(s.name || "").trim(),
              guardian: String(s.guardian || "").trim(),
              age: s.age == null ? "" : String(s.age),
              balance: s.balance == null ? "0" : String(s.balance),
              level,
              time
            });
          });
        }
      } catch (e) {
        fails.push({ name: (file && file.name) || `Photo ${i + 1}`, error: (e && e.message) || "Couldn't read this photo." });
      }
      if (cancelRef.current) return;
      setProgress({ done: i + 1, total: files.length });
      // Throttle to stay under the Gemini free-tier rate limit (skip after last).
      if (i < files.length - 1) await new Promise((r) => setTimeout(r, SCAN_THROTTLE_MS));
    }
    if (cancelRef.current) return;
    setRows(collected);
    setFailed(fails);
    setPhase("review");
  };

  const setRow = (key, patch) => setRows((p) => p.map((r) => r.key === key ? { ...r, ...patch } : r));
  const removeRow = (key) => setRows((p) => p.filter((r) => r.key !== key));

  // Group review rows by class (level + time) for display.
  const groups = [];
  const groupIndex = {};
  rows.forEach((r) => {
    const gk = `${r.time}|${r.level}`;
    if (groupIndex[gk] == null) { groupIndex[gk] = groups.length; groups.push({ key: gk, time: r.time, level: r.level, rows: [] }); }
    groups[groupIndex[gk]].rows.push(r);
  });
  groups.sort((a, b) => (TIME_SLOTS.indexOf(a.time) - TIME_SLOTS.indexOf(b.time)) || (LEVELS.indexOf(a.level) - LEVELS.indexOf(b.level)));

  const doImport = () => {
    const ready = rows
      .filter((r) => String(r.name || "").trim() && r.level && r.time)
      .map((r) => ({ name: r.name, guardian: r.guardian, age: r.age, balance: r.balance, level: r.level, time: r.time }));
    if (ready.length === 0) { setError("Set a level and time for at least one swimmer before importing."); return; }
    const res = onImport(targetWeek, ready) || { added: 0, skipped: 0 };
    onDone(res.added || 0, res.skipped || 0);
  };

  const head = h("div", { style: styles.modalHead, key: "head" }, [
    h("div", { key: "t" }, [
      h("div", { style: styles.kicker, key: "k" }, "Scan roster"),
      h("h2", { id: "scanTitle", style: styles.modalTitle, key: "h" }, "Photo or paste → roster")
    ]),
    h("button", { style: styles.iconBtn, onClick: onClose, "aria-label": "Close", key: "x" }, h(X, { size: 18 }))
  ]);

  let bodyChildren;
  if (phase === "pick") {
    bodyChildren = h("div", { style: { ...styles.settingsBody, overflowY: "auto", paddingBottom: 8 }, key: "pick" }, [
      h("p", { style: styles.settingsText, key: "p1" }, "Take or choose photos of your printed class rosters — one photo per class. Each photo should show the handwritten level/time at the top and the list of swimmers. You can pick many at once."),
      h("label", { style: { ...styles.primaryBtn, cursor: "pointer", marginTop: 4 }, key: "lbl" }, [
        h(ClipboardCheck, { size: 16, key: "i" }),
        " Choose roster photos",
        h("input", {
          key: "inp",
          type: "file",
          accept: "image/*",
          capture: "environment",
          multiple: true,
          style: { display: "none" },
          onChange: (e) => onFiles(e.target.files)
        })
      ]),
      h("div", { style: { display: "flex", alignItems: "center", gap: 10, margin: "12px 0 2px" }, key: "or" }, [
        h("div", { style: { flex: 1, height: 1, background: "var(--border,#DCE6E8)" }, key: "l" }),
        h("span", { style: { fontSize: 12.5, color: "var(--muted,#6B7A80)", fontWeight: 700 }, key: "t" }, "OR PASTE"),
        h("div", { style: { flex: 1, height: 1, background: "var(--border,#DCE6E8)" }, key: "r" })
      ]),
      h("p", { style: styles.settingsText, key: "pp" }, "Paste roster text — one swimmer per line, comma- or tab-separated: Name, Guardian, Age, Level, Time, Balance. You'll review everything before it imports."),
      h("textarea", {
        key: "ta",
        value: pasteText,
        placeholder: "Paul Hanson, Brian Hanson, 7, Level 3, 11am, 0",
        rows: 6,
        spellCheck: false,
        style: { ...styles.scanInput, width: "100%", minHeight: 110, resize: "vertical", lineHeight: 1.5 },
        onChange: (e) => setPasteText(e.target.value)
      }),
      h("button", {
        style: { ...styles.primaryBtn, marginTop: 6, opacity: pasteText.trim() ? 1 : 0.55 },
        onClick: onPasteReview,
        key: "pbtn"
      }, [h(ClipboardCheck, { size: 16, key: "i" }), " Review pasted roster"]),
      error && h("p", { style: styles.scanError, key: "err" }, error)
    ]);
  } else if (phase === "scanning") {
    bodyChildren = h("div", { style: { ...styles.settingsBody, alignItems: "center", textAlign: "center", padding: "18px" }, key: "scan" }, [
      h(Loader2, { size: 28, className: "spin", style: { color: "#2DD4BF" }, key: "ld" }),
      h("p", { style: { ...styles.settingsText, fontWeight: 700, color: "var(--heading)" }, key: "p" }, `Reading ${Math.min(progress.done + 1, progress.total)} of ${progress.total}…`),
      h("p", { style: styles.settingsText, key: "p2" }, "Each photo is sent securely to be read. This stays slow on purpose to avoid rate limits."),
      h("button", { style: styles.ghostBtn, onClick: () => { cancelRef.current = true; setPhase("pick"); }, key: "c" }, "Cancel")
    ]);
  } else {
    // review
    const swimmerCount = rows.length;
    // overflowY so a big paste/scan (e.g. a full 49-swimmer week) can scroll to
    // every name; the foot with the Import button stays pinned below.
    bodyChildren = h("div", { style: { ...styles.settingsBody, overflowY: "auto", paddingBottom: 8 }, key: "rev" }, [
      h("p", { style: { ...styles.settingsText, fontWeight: 700, color: "var(--heading)" }, key: "cnt" },
        `Found ${swimmerCount} swimmer${swimmerCount === 1 ? "" : "s"} across ${groups.length} class${groups.length === 1 ? "" : "es"}.`),
      failed.length > 0 && h("div", { style: styles.scanWarn, key: "fail" }, [
        h("div", { style: { fontWeight: 700, marginBottom: 4 }, key: "ft" }, `${failed.length} photo${failed.length === 1 ? "" : "s"} couldn't be read — skipped:`),
        ...failed.map((f, i) => h("div", { key: `f${i}`, style: { fontSize: 12.5 } }, `• ${f.name}: ${f.error}`))
      ]),
      h("label", { style: styles.fieldLabel, key: "wkl" }, "Import into week"),
      h("select", {
        key: "wk",
        style: styles.scanSelect,
        value: targetWeek,
        onChange: (e) => setTargetWeek(e.target.value)
      }, weekKeys.map((wk) => h("option", { key: wk, value: wk },
        // "(current)" used to mark the VIEWED week, which made a past week look
        // safe to import into. Mark weeks relative to today instead.
        weekLabelWithDays(wk) + (wk === todayWeek ? " (this week)" : wk < todayWeek ? " (past)" : "")))),
      targetIsPast && h("div", { style: styles.scanWarn, key: "pastwk" },
        `Heads up: ${weekLabelWithDays(targetWeek)} is a PAST week — this week is ${weekLabelWithDays(todayWeek)}. Swimmers will import into ${weekLabelWithDays(targetWeek)}.`),
      ...groups.map((g) => h("div", { key: g.key, style: styles.scanGroup }, [
        h("div", { style: styles.scanGroupHead, key: "gh" }, `${g.level || "(no level)"} \xB7 ${g.time || "(no time)"} — ${g.rows.length}`),
        ...g.rows.map((r) => h("div", { key: r.key, style: styles.scanRow }, [
          h("input", { key: "nm", style: styles.scanInput, value: r.name, placeholder: "Name", onChange: (e) => setRow(r.key, { name: e.target.value }) }),
          h("input", { key: "gd", style: styles.scanInput, value: r.guardian, placeholder: "Guardian", onChange: (e) => setRow(r.key, { guardian: e.target.value }) }),
          h("div", { key: "rr", style: styles.scanRowSub }, [
            h("input", { key: "ag", style: { ...styles.scanInput, width: 56 }, value: r.age, placeholder: "Age", inputMode: "numeric", onChange: (e) => setRow(r.key, { age: e.target.value }) }),
            h("input", { key: "bl", style: { ...styles.scanInput, width: 72 }, value: r.balance, placeholder: "Bal", inputMode: "decimal", onChange: (e) => setRow(r.key, { balance: e.target.value }) }),
            h("select", { key: "lv", style: styles.scanSelectSm, value: r.level, onChange: (e) => setRow(r.key, { level: e.target.value }) }, [
              h("option", { key: "_", value: "" }, "Level…"),
              ...LEVELS.map((l) => h("option", { key: l, value: l }, l))
            ]),
            h("select", { key: "tm", style: styles.scanSelectSm, value: r.time, onChange: (e) => setRow(r.key, { time: e.target.value }) }, [
              h("option", { key: "_", value: "" }, "Time…"),
              ...TIME_SLOTS.map((t) => h("option", { key: t, value: t }, t))
            ]),
            h("button", { key: "rm", style: styles.scanRemove, onClick: () => removeRow(r.key), "aria-label": "Remove swimmer", title: "Remove" }, h(Trash2, { size: 14 }))
          ])
        ]))
      ])),
      rows.length === 0 && h("p", { style: styles.settingsText, key: "none" }, "No swimmers were read. Close and try clearer, straight-on photos."),
      error && h("p", { style: styles.scanError, key: "err" }, error)
    ]);
  }

  // The Import button always names the destination week so a wrong target is
  // visible at the moment of commit; amber (scanWarn's hue) when it's past.
  const readyCount = rows.filter((r) => String(r.name || "").trim() && r.level && r.time).length;
  const foot = phase === "review"
    ? h("div", { style: styles.modalFoot, key: "foot" }, [
        h("button", { style: styles.ghostBtn, onClick: onClose, key: "cancel" }, "Cancel"),
        h("button", {
          style: targetIsPast ? { ...styles.primaryBtn, background: "#E8A02C" } : styles.primaryBtn,
          onClick: doImport,
          disabled: rows.length === 0,
          title: `Import into ${weekLabelWithDays(targetWeek)}`,
          key: "imp"
        }, [
          h(Download, { size: 15, key: "i" }),
          ` Import ${readyCount} → ${weekLabelWithDays(targetWeek)}`
        ])
      ])
    : null;

  return h(Modal, { onClose, labelledBy: "scanTitle" }, h(Fragment, null, [head, bodyChildren, foot].filter(Boolean)));
}
// Header time display. Owns its own 1s tick so App doesn't re-render every second.
function HeaderClock() {
  const [clock, setClock] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  // Weekday + date (PST, matching the rest of the app) alongside the live time,
  // e.g. "Tue, Jul 7 · 3:14:05 PM".
  const dateStr = clock.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", timeZone: "America/Los_Angeles" });
  const timeStr = clock.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", second: "2-digit", timeZone: "America/Los_Angeles" });
  return h("div", { className: "ag-hd-clock", style: styles.headerClock, key: "clk" }, [
    h("span", { style: styles.clockDot, key: "d" }),
    h("span", { key: "dt", style: { fontWeight: 800 } }, dateStr),
    h("span", { key: "sep", style: { opacity: 0.5 } }, "·"),
    h("span", { key: "tm" }, timeStr)
  ]);
}
function SyncBadge({ state, onRetry }) {
  const map = {
    loading: { icon: /* @__PURE__ */ jsx(Loader2, { size: 13, className: "spin" }), text: "Loading\u2026", color: "#8FC9CE" },
    saving: { icon: /* @__PURE__ */ jsx(Loader2, { size: 13, className: "spin" }), text: "Saving\u2026", color: "#8FC9CE" },
    saved: { icon: /* @__PURE__ */ jsx(Cloud, { size: 13 }), text: "Synced", color: "#8FC9CE" },
    // R4: tell the truth. The change isn't lost \u2014 it retries automatically and
    // can be retried by tapping the badge.
    offline: { icon: /* @__PURE__ */ jsx(CloudOff, { size: 13 }), text: "Not saved", color: "#FFB4AC" },
    local: { icon: /* @__PURE__ */ jsx(CloudOff, { size: 13 }), text: "Set up sync", color: "#FFD79A" }
  };
  const s = map[state] || map.saved;
  // R4: only the offline badge is actionable (forces a retry); others are static.
  const isOffline = state === "offline";
  const title = isOffline
    ? "Changes aren't saved yet \u2014 will retry when you're back online. Tap to retry now."
    : "Synced across devices automatically";
  // The offline badge is a REAL button (keyboard/switch users can retry);
  // a span with role=button and no tabIndex was unreachable without a mouse.
  const Tag = isOffline && onRetry ? "button" : "span";
  return /* @__PURE__ */ jsxs(Tag, {
    style: { ...styles.syncBadge, color: s.color, cursor: isOffline && onRetry ? "pointer" : "default", ...isOffline && onRetry ? { background: "none", border: "none", fontFamily: "inherit", padding: "7px 4px" } : {} },
    title,
    onClick: isOffline && onRetry ? onRetry : void 0,
    children: [
      s.icon,
      // A4: announce sync status changes to screen readers. Offline/error is
      // assertive (interrupts), the rest is polite.
      /* @__PURE__ */ jsx("span", { role: "status", "aria-live": isOffline ? "assertive" : "polite", children: s.text })
    ]
  });
}
function MovePicker({ currentTime, currentLevel, onPick, onClose }) {
  const [time, setTime] = useState(currentTime);
  return /* @__PURE__ */ jsxs("div", { style: styles.movePop, onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxs("div", { style: styles.moveHead, children: [
      "Move to",
      /* @__PURE__ */ jsx("button", { style: styles.moveClose, onClick: onClose, children: /* @__PURE__ */ jsx(X, { size: 13 }) })
    ] }),
    /* @__PURE__ */ jsx("div", { style: styles.moveRow, children: TIME_SLOTS.map((t) => /* @__PURE__ */ jsx(
      "button",
      {
        style: { ...styles.moveChip, ...time === t ? styles.moveChipOn : {} },
        onClick: () => setTime(t),
        children: t
      },
      t
    )) }),
    /* @__PURE__ */ jsx("div", { style: styles.moveLevels, children: LEVELS.map((l) => {
      const isCurrent = time === currentTime && l === currentLevel;
      return /* @__PURE__ */ jsxs(
        "button",
        {
          disabled: isCurrent,
          style: {
            ...styles.moveLevelBtn,
            ...isCurrent ? styles.moveLevelCurrent : {},
            borderColor: levelColor(l)
          },
          onClick: () => onPick(time, l),
          children: [
            /* @__PURE__ */ jsx("span", { style: { ...styles.moveDot, background: levelColor(l) } }),
            l,
            isCurrent && /* @__PURE__ */ jsx("span", { style: styles.moveHere, children: "here now" })
          ]
        },
        l
      );
    }) })
  ] });
}
function RequestPicker({ currentTime, currentLevel, studentName, onSubmit, onClose }) {
  const [time, setTime] = useState(currentTime);
  const [level, setLevel] = useState(null);
  const [reason, setReason] = useState("");
  const canSend = !!level && !(time === currentTime && level === currentLevel);
  return h("div", { style: styles.movePop, onClick: (e) => e.stopPropagation() }, [
    h("div", { style: styles.moveHead, key: "hd" }, [
      "Request switch",
      h("button", { style: styles.moveClose, onClick: onClose, key: "x" }, h(X, { size: 13 }))
    ]),
    h("p", { style: styles.reqPickSub, key: "sub" }, [studentName ? `${studentName} \u2192 ` : "Move to ", "pick the new time and level, then send it to an admin to approve."]),
    h("div", { style: styles.moveRow, key: "row" }, TIME_SLOTS.map((t) => h(
      "button",
      {
        style: { ...styles.moveChip, ...time === t ? styles.moveChipOn : {} },
        onClick: () => { setTime(t); setLevel(null); },
        key: t
      },
      t
    ))),
    h("div", { style: styles.moveLevels, key: "lv" }, LEVELS.map((l) => {
      const isCurrent = time === currentTime && l === currentLevel;
      const isPicked = level === l;
      return h(
        "button",
        {
          disabled: isCurrent,
          style: {
            ...styles.moveLevelBtn,
            ...isCurrent ? styles.moveLevelCurrent : {},
            ...isPicked ? styles.moveLevelPicked : {},
            borderColor: levelColor(l)
          },
          onClick: () => setLevel(l),
          key: l
        },
        [
          h("span", { style: { ...styles.moveDot, background: levelColor(l) }, key: "d" }),
          l,
          isCurrent && h("span", { style: styles.moveHere, key: "h" }, "here now"),
          isPicked && h(Check, { size: 14, key: "c", style: { marginLeft: "auto", color: legibleColor("#1D7A8C") } })
        ]
      );
    })),
    h("textarea", {
      key: "rea",
      style: styles.reqReasonInput,
      value: reason,
      placeholder: "Reason (optional) \u2014 e.g. moving up a level, schedule conflict\u2026",
      rows: 2,
      onChange: (e) => setReason(e.target.value)
    }),
    h("button", {
      key: "send",
      style: { ...styles.reqSendBtn, ...canSend ? {} : styles.reqSendBtnOff },
      disabled: !canSend,
      onClick: () => canSend && onSubmit(time, level, reason)
    }, [h(ArrowRightLeft, { size: 15, key: "i" }), " Send request to owner"])
  ]);
}
function AddClassControl({ existingLevels, onAddClass }) {
  const [picking, setPicking] = useState(false);
  const available = LEVELS.filter((l) => !existingLevels.includes(l));
  if (available.length === 0 && !picking) return null;
  return /* @__PURE__ */ jsx("div", { style: styles.addClassWrap, children: picking ? /* @__PURE__ */ jsxs("div", { style: styles.addClassPanel, children: [
    /* @__PURE__ */ jsxs("div", { style: styles.addClassHead, children: [
      "Add a class",
      /* @__PURE__ */ jsx("button", { style: styles.moveClose, onClick: () => setPicking(false), children: /* @__PURE__ */ jsx(X, { size: 14 }) })
    ] }),
    /* @__PURE__ */ jsx("div", { style: styles.addClassLevels, children: available.map((l) => /* @__PURE__ */ jsxs(
      "button",
      {
        style: { ...styles.addClassLevel, borderColor: levelColor(l) },
        onClick: () => {
          onAddClass(l);
          setPicking(false);
        },
        children: [
          /* @__PURE__ */ jsx("span", { style: { ...styles.moveDot, background: levelColor(l) } }),
          l
        ]
      },
      l
    )) })
  ] }) : /* @__PURE__ */ jsxs("button", { style: styles.addClassBtn, onClick: () => setPicking(true), children: [
    /* @__PURE__ */ jsx(Plus, { size: 16 }),
    " Add a class"
  ] }) });
}
function ClassCard({ level, time, roster, instructors, onToggle, onRemove, onNote, onMove, onRequestSwitch, isInstructor, requests, onAddStudent, onEditStudent, onAddInstructor, onRemoveInstructor, startAdding }) {
  const [open, setOpen] = useState(true);
  const [addingInst, setAddingInst] = useState(false);
  const [instName, setInstName] = useState("");
  const [noteFor, setNoteFor] = useState(null);
  const [moveFor, setMoveFor] = useState(null);
  const [adding, setAdding] = useState(!!startAdding);
  const [form, setForm] = useState({ name: "", guardian: "", age: "" });
  const [addErr, setAddErr] = useState("");
  const [editFor, setEditFor] = useState(null);
  const [editForm, setEditForm] = useState({ name: "", guardian: "", age: "" });
  const accent = levelColor(level) || "#1D7A8C";
  const present = roster.filter((s) => s.present).length;
  // "All here" pill: mark every un-marked swimmer via the SAME togglePresent
  // path each check uses (sync engine untouched); flips to "Clear" when full.
  const absentKids = roster.filter((s) => !s.present);
  const allPresent = roster.length > 0 && absentKids.length === 0;
  const submitAdd = () => {
    if (!form.name.trim()) { setAddErr("Name is required"); return; }
    setAddErr("");
    onAddStudent(time, level, form);
    setForm({ name: "", guardian: "", age: "" });
    setAdding(false);
  };
  const startEdit = (s) => {
    setEditFor(s.id);
    setEditForm({ name: s.name, guardian: s.guardian || "", age: s.age ? String(s.age) : "" });
  };
  const submitEdit = () => {
    if (!editForm.name.trim()) return;
    onEditStudent(editFor, editForm);
    setEditFor(null);
  };
  return /* @__PURE__ */ jsxs("section", { style: styles.card, children: [
    /* @__PURE__ */ jsx("div", { style: { ...styles.cardBar, background: accent } }),
    /* @__PURE__ */ jsxs("div", { style: styles.cardBody, children: [
      /* @__PURE__ */ jsxs("div", { style: styles.cardHead, children: [/* @__PURE__ */ jsxs("button", { style: styles.cardTitleBtn, onClick: () => setOpen((o) => !o), children: [
        /* @__PURE__ */ jsx(
          ChevronDown,
          {
            size: 18,
            style: { transform: open ? "none" : "rotate(-90deg)", transition: "transform .2s", color: "var(--muted,#5B7A88)" }
          }
        ),
        /* @__PURE__ */ jsx("span", { style: { ...styles.levelBadge, background: accent }, children: level }),
        /* @__PURE__ */ jsxs("span", { style: styles.cardCount, children: [
          present,
          "/",
          roster.length,
          " here"
        ] })
      ] }), roster.length > 0 && /* @__PURE__ */ jsx("button", {
        style: { ...styles.instAdd, flexShrink: 0, ...allPresent ? {} : { borderStyle: "solid", color: accent, borderColor: accent } },
        onClick: () => { (allPresent ? roster : absentKids).forEach((s) => onToggle(s.id)); },
        "aria-label": allPresent ? "Clear every attendance mark in this class" : "Mark every swimmer in this class present",
        children: allPresent ? "Clear" : "All here"
      })] }),
      /* @__PURE__ */ jsxs("div", { style: styles.instRow, children: [
        /* @__PURE__ */ jsx("span", { style: styles.instLabel, children: "Instructors" }),
        instructors.map((name, i) => /* @__PURE__ */ jsxs("span", { style: styles.instChip, children: [
          name,
          !isInstructor && /* @__PURE__ */ jsx("button", { style: styles.chipX, onClick: () => onRemoveInstructor(time, level, i), children: /* @__PURE__ */ jsx(X, { size: 11 }) })
        ] }, i)),
        instructors.length === 0 && isInstructor && /* @__PURE__ */ jsx("span", { style: styles.instNone, children: "\u2014" }),
        !isInstructor && (addingInst ? /* @__PURE__ */ jsx("span", { style: styles.instAddWrap, children: /* @__PURE__ */ jsx(
          "input",
          {
            autoFocus: true,
            style: styles.instInput,
            value: instName,
            placeholder: "Name",
            "aria-label": "Instructor name",
            onChange: (e) => setInstName(e.target.value),
            onKeyDown: (e) => {
              if (e.key === "Enter") {
                onAddInstructor(time, level, instName);
                setInstName("");
                setAddingInst(false);
              }
              if (e.key === "Escape") setAddingInst(false);
            }
          }
        ) }) : /* @__PURE__ */ jsxs("button", { style: styles.instAdd, onClick: () => setAddingInst(true), children: [
          /* @__PURE__ */ jsx(UserPlus, { size: 13 }),
          " Add"
        ] }))
      ] }),
      open && /* @__PURE__ */ jsx("ul", { style: styles.list, children: roster.map((s) => editFor === s.id ? /* @__PURE__ */ jsxs("li", { style: styles.editRow, children: [
        /* @__PURE__ */ jsx(
          "input",
          {
            autoFocus: true,
            style: styles.addInput,
            value: editForm.name,
            placeholder: "Swimmer name", "aria-label": "Swimmer name",
            onChange: (e) => setEditForm((f) => ({ ...f, name: e.target.value })),
            onKeyDown: (e) => e.key === "Enter" && submitEdit()
          }
        ),
        /* @__PURE__ */ jsxs("div", { style: styles.addRow, children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              style: styles.addInput,
              value: editForm.guardian,
              placeholder: "Parent / guardian", "aria-label": "Parent / guardian",
              onChange: (e) => setEditForm((f) => ({ ...f, guardian: e.target.value })),
              onKeyDown: (e) => e.key === "Enter" && submitEdit()
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              style: { ...styles.addInput, width: 70, flex: "0 0 auto" },
              value: editForm.age,
              placeholder: "Age", "aria-label": "Age",
              inputMode: "numeric",
              onChange: (e) => setEditForm((f) => ({ ...f, age: e.target.value.replace(/[^0-9]/g, "") })),
              onKeyDown: (e) => e.key === "Enter" && submitEdit()
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { style: styles.addBtns, children: [
          /* @__PURE__ */ jsx("button", { style: styles.addCancel, onClick: () => setEditFor(null), children: "Cancel" }),
          /* @__PURE__ */ jsxs("button", { style: { ...styles.addSave, background: accent }, onClick: submitEdit, children: [
            /* @__PURE__ */ jsx(Check, { size: 15 }),
            " Save"
          ] })
        ] })
      ] }, s.id) : /* @__PURE__ */ jsxs("li", { style: { ...styles.row, ...s.present ? styles.rowPresent : {} }, children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            style: { ...styles.check, ...s.present ? { borderColor: accent, background: accent } : {} },
            className: "ag-check",
            onClick: () => onToggle(s.id),
            "aria-label": s.present ? "Mark absent" : "Mark present",
            children: s.present && /* @__PURE__ */ jsx(Check, { size: 15, color: "#fff" })
          }
        ),
        // The whole name/guardian block toggles too — a 44px+ tap target vs the
        // 26px check. Buttons inside stop propagation so they don't toggle.
        /* @__PURE__ */ jsxs("div", {
          style: { flex: 1, minWidth: 0, cursor: "pointer" },
          role: "button",
          tabIndex: 0,
          onClick: () => onToggle(s.id),
          onKeyDown: (e) => { if (e.target !== e.currentTarget) return; if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onToggle(s.id); } },
          "aria-label": s.present ? `Mark ${s.name} absent` : `Mark ${s.name} present`,
          children: [
          /* @__PURE__ */ jsxs("div", { style: styles.rName, children: [
            s.name,
            s.age > 0 && /* @__PURE__ */ jsx("span", { style: styles.ageTag, children: s.age })
          ] }),
          /* @__PURE__ */ jsx("div", { style: styles.rSub, children: s.guardian }),
          // Instructors see notes read-only: note edits route through the
          // owner-only guard() and would silently evaporate, so never offer
          // them the editor \u2014 just show any existing note as plain text.
          isInstructor ? (s.note ? /* @__PURE__ */ jsx("span", { style: { ...styles.noteTag, cursor: "default" }, children: s.note }) : null) : noteFor === s.id ? /* @__PURE__ */ jsx(
            "input",
            {
              autoFocus: true,
              style: styles.noteInput,
              defaultValue: s.note,
              placeholder: "Add a note\u2026",
              "aria-label": "Add a note",
              onClick: (e) => e.stopPropagation(),
              onBlur: (e) => {
                onNote(s.id, e.target.value);
                setNoteFor(null);
              },
              // Keydown must not bubble to the row's toggle handler: it would
              // eat spaces and flip attendance on every space/Enter.
              onKeyDown: (e) => { e.stopPropagation(); if (e.key === "Enter") e.target.blur(); }
            }
          ) : s.note ? /* @__PURE__ */ jsx("button", { style: styles.noteTag, onClick: (e) => { e.stopPropagation(); setNoteFor(s.id); }, children: s.note }) : /* @__PURE__ */ jsx("button", { style: styles.noteAdd, onClick: (e) => { e.stopPropagation(); setNoteFor(s.id); }, children: "+ note" }),
          (requests || []).some((r) => r.studentId === s.id && r.status === "pending") && /* @__PURE__ */ jsxs("span", { style: styles.pendingTag, children: [
            /* @__PURE__ */ jsx(ArrowRightLeft, { size: 11 }),
            " Switch requested"
          ] }),
          // Wrapped so taps/keys inside the picker never toggle the row.
          moveFor === s.id && /* @__PURE__ */ jsx("span", { onClick: (e) => e.stopPropagation(), onKeyDown: (e) => e.stopPropagation(), children: isInstructor ? /* @__PURE__ */ jsx(
            RequestPicker,
            {
              currentTime: time,
              currentLevel: level,
              studentName: s.name,
              onSubmit: (t, l, reason) => {
                onRequestSwitch(s.id, t, l, reason);
                setMoveFor(null);
              },
              onClose: () => setMoveFor(null)
            }
          ) : /* @__PURE__ */ jsx(
            MovePicker,
            {
              currentTime: time,
              currentLevel: level,
              onPick: (t, l) => {
                onMove(s.id, t, l);
                setMoveFor(null);
              },
              onClose: () => setMoveFor(null)
            }
          ) })
        ] }),
        s.balance > 0 && /* @__PURE__ */ jsxs("span", { style: styles.balance, children: [
          "$",
          s.balance.toFixed(2)
        ] }),
        !isInstructor && /* @__PURE__ */ jsx(
          "button",
          {
            style: styles.iconBtn,
            onClick: () => startEdit(s),
            "aria-label": "Edit details",
            title: "Edit name, guardian, age",
            children: /* @__PURE__ */ jsx(Pencil, { size: 15 })
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            style: { ...styles.iconBtn, ...moveFor === s.id ? { color: accent } : {} },
            onClick: () => setMoveFor(moveFor === s.id ? null : s.id),
            "aria-label": isInstructor ? "Request a lesson switch" : "Move to another class",
            title: isInstructor ? "Request a lesson switch" : "Move to another class",
            children: /* @__PURE__ */ jsx(ArrowRightLeft, { size: 15 })
          }
        ),
        !isInstructor && /* @__PURE__ */ jsx("button", { style: styles.iconBtn, onClick: () => onRemove(s.id), "aria-label": "Remove", children: /* @__PURE__ */ jsx(Trash2, { size: 15 }) })
      ] }, s.id)) }),
      open && (adding ? /* @__PURE__ */ jsxs("div", { style: styles.addForm, children: [
        /* @__PURE__ */ jsx(
          "input",
          {
            autoFocus: true,
            style: styles.addInput,
            value: form.name,
            placeholder: "Swimmer name", "aria-label": "Swimmer name",
            onChange: (e) => { setForm((f) => ({ ...f, name: e.target.value })); if (addErr) setAddErr(""); },
            onKeyDown: (e) => e.key === "Enter" && submitAdd()
          }
        ),
        addErr && h("div", { key: "addErr", role: "alert", style: { fontSize: 12, color: "#B23A2C", fontWeight: 600, margin: "2px 0" } }, addErr),
        /* @__PURE__ */ jsxs("div", { style: styles.addRow, children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              style: styles.addInput,
              value: form.guardian,
              placeholder: "Parent / guardian", "aria-label": "Parent / guardian",
              onChange: (e) => setForm((f) => ({ ...f, guardian: e.target.value })),
              onKeyDown: (e) => e.key === "Enter" && submitAdd()
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              style: { ...styles.addInput, width: 70, flex: "0 0 auto" },
              value: form.age,
              placeholder: "Age", "aria-label": "Age",
              inputMode: "numeric",
              onChange: (e) => setForm((f) => ({ ...f, age: e.target.value.replace(/[^0-9]/g, "") })),
              onKeyDown: (e) => e.key === "Enter" && submitAdd()
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { style: styles.addBtns, children: [
          /* @__PURE__ */ jsx("button", { style: styles.addCancel, onClick: () => {
            setAdding(false);
            setForm({ name: "", guardian: "", age: "" });
            setAddErr("");
          }, children: "Cancel" }),
          /* @__PURE__ */ jsxs("button", { style: { ...styles.addSave, background: accent }, onClick: submitAdd, children: [
            /* @__PURE__ */ jsx(Check, { size: 15 }),
            " Add to ",
            level
          ] })
        ] })
      ] }) : !isInstructor && /* @__PURE__ */ jsxs("button", { style: styles.addSwimmerBtn, onClick: () => setAdding(true), children: [
        /* @__PURE__ */ jsx(UserPlus, { size: 15 }),
        " Add swimmer"
      ] }))
    ] })
  ] });
}
function AuthGate({ topError }) {
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [diag, setDiag] = useState("");
  const runDiag = async () => {
    setDiag("Testing\u2026");
    const url = "https://vjmawnmopndlrmruchhs.supabase.co/auth/v1/health";
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 10000);
      const r = await fetch(url, { headers: { apikey: "sb_publishable_dz4NIUQxtOROwgc0Hkrxhw_C4sLUn1v" }, signal: ctrl.signal });
      clearTimeout(t);
      let body = "";
      try { body = (await r.text()).slice(0, 80); } catch {}
      setDiag("HTTP " + r.status + " \u2014 " + (body || "(no body)"));
    } catch (e) {
      setDiag("FAILED: " + String(e && e.name || "") + " " + String(e && e.message || e));
    }
  };
  const submit = async () => {
    if (!email.trim() || !pw) { setErr("Enter your email and password."); return; }
    setBusy(true); setErr("");
    try {
      await authSignIn(email, pw);
      // onAuthStateChange in App handles the rest.
    } catch (e) {
      const msg = String(e && e.message || e);
      if (/invalid login/i.test(msg)) setErr("Email or password is incorrect.");
      else if (/email not confirmed/i.test(msg)) setErr("This account isn't confirmed yet. Ask the owner.");
      else setErr(msg);
      setBusy(false);
    }
  };
  return h("div", { style: styles.gateScene }, h("style", null, css), [
    // Layered aquatic background (CSS-only, performant): drifting caustic orbs + ripple + grain.
    h("div", { style: styles.gateBgOrb1, className: "ag-orb1", key: "o1", "aria-hidden": true }),
    h("div", { style: styles.gateBgOrb2, className: "ag-orb2", key: "o2", "aria-hidden": true }),
    h("div", { style: styles.gateRipple, className: "ag-ripple", key: "rp", "aria-hidden": true }),
    h("div", { style: styles.gateGrain, key: "gr", "aria-hidden": true }),
    h("div", { style: styles.gateWrap, key: "wrap" }, h("div", { style: styles.gateCard, className: "ag-rise ag-d1" }, [
      h("div", { style: styles.gateIcon, className: "ag-rise ag-d1", key: "i" }, h(LifeBuoy, { size: 28, style: { color: "#06283A" } })),
      h("div", { style: styles.gateKicker, className: "ag-rise ag-d2", key: "k" }, "LMUSD \xB7 Summer Swim 2026"),
      h("h1", { style: styles.gateTitle, className: "ag-rise ag-d2", key: "t" }, "Arroyo Grande Pool"),
      h("div", { style: styles.gateUnderline, className: "ag-rise ag-d2", key: "ul", "aria-hidden": true }),
      h("p", { style: styles.gateSub, className: "ag-rise ag-d3", key: "s" }, "Sign in with your account to view rosters, take attendance, and manage lessons."),
      // A2: real login form \u2014 native Enter-to-submit + form semantics. Reuses the
      // existing submit() handler; preventDefault stops the native page reload.
      h("form", { key: "form", onSubmit: (e) => { e.preventDefault(); submit(); } }, [
        // Persistent labels: placeholder-only labels vanish under autofill and
        // measured ~3.9:1 in sunlight glare — the one flow that gates everything
        // was the hardest to see.
        h("label", { key: "eml", htmlFor: "email", style: { display: "block", textAlign: "left", fontSize: 12, fontWeight: 700, color: "#CFE6EA", margin: "10px 2px 0" } }, "Email"),
        h("input", {
          key: "em", autoFocus: true, type: "email", className: "ag-gate-input ag-rise ag-d4", style: styles.gateInput, value: email,
          id: "email", name: "email", autoComplete: "email", enterKeyHint: "next",
          placeholder: "you@example.com", autoCapitalize: "none", autoCorrect: "off", spellCheck: false, inputMode: "email",
          onChange: (e) => { setEmail(e.target.value); setErr(""); },
          onKeyDown: (e) => e.key === "Enter" && submit()
        }),
        h("label", { key: "pwl", htmlFor: "password", style: { display: "block", textAlign: "left", fontSize: 12, fontWeight: 700, color: "#CFE6EA", margin: "10px 2px 0" } }, "Password"),
        h("input", {
          key: "pw", type: "password", className: "ag-gate-input ag-rise ag-d4", style: styles.gateInput, value: pw,
          id: "password", name: "password", autoComplete: "current-password", enterKeyHint: "go",
          placeholder: "••••••••", autoCapitalize: "off", autoCorrect: "off", spellCheck: false,
          onChange: (e) => { setPw(e.target.value); setErr(""); },
          onKeyDown: (e) => e.key === "Enter" && submit()
        }),
        err && h("div", { style: styles.gateErr, key: "e", role: "alert" }, err),
        !err && topError && h("div", { style: styles.gateErr, key: "te", role: "alert" }, "Connection issue: " + topError),
        (topError || diag) && h("button", { type: "button", style: { ...styles.gateBtn, background: "#46606C", marginTop: 8 }, key: "diag", onClick: runDiag }, "Test connection"),
        diag && h("div", { style: { ...styles.gateErr, background: "var(--surface-2)", color: "var(--text)", wordBreak: "break-word", fontSize: 12 }, key: "dr", role: "status" }, diag),
        h("button", { type: "submit", className: "ag-signin ag-rise ag-d5", style: { ...styles.gateBtn, ...busy ? { opacity: 0.7 } : {}, marginTop: 12 }, key: "b", disabled: busy }, [
          busy ? h(Loader2, { size: 16, key: "u", className: "spin" }) : h(Unlock, { size: 16, key: "u" }),
          busy ? " Signing in\u2026" : " Sign in"
        ])
      ]),
      h("p", { style: styles.gateFoot, className: "ag-rise ag-d5", key: "f" }, "No account? Ask Peter (the owner) to create one for you.")
    ]))
  ]);
}
function DisabledGate({ onSignOut }) {
  return h("div", { style: styles.gateScene }, h("style", null, css), [
    h("div", { style: styles.gateBgOrb1, className: "ag-orb1", key: "o1", "aria-hidden": true }),
    h("div", { style: styles.gateBgOrb2, className: "ag-orb2", key: "o2", "aria-hidden": true }),
    h("div", { style: styles.gateGrain, key: "gr", "aria-hidden": true }),
    h("div", { style: styles.gateWrap, key: "wrap" }, h("div", { style: styles.gateCard, className: "ag-rise ag-d1" }, [
      h("div", { style: styles.gateIcon, key: "i" }, h(Lock, { size: 28, style: { color: "#06283A" } })),
      h("div", { style: styles.gateKicker, key: "k" }, "Account paused"),
      h("h1", { style: styles.gateTitle, key: "t" }, "Access disabled"),
      h("p", { style: styles.gateSub, key: "s" }, "Your account has been turned off by the owner. Contact Peter if you think this is a mistake."),
      h("button", { style: styles.gateBtn, className: "ag-signin", key: "b", onClick: onSignOut }, [h(Lock, { size: 16, key: "u" }), " Sign out"])
    ]))
  ]);
}
function StationCardFS({ index, station, guard2, next, live }) {
  const color = stationColor(index);
  return h("div", { style: { ...styles.fsStation, borderTopColor: color } }, [
    h("div", { style: styles.fsStationHead, key: "h" }, [
      h("span", { style: { ...styles.fsStationDot, background: color }, key: "d" }),
      h("span", { style: styles.fsStationName, key: "n" }, station)
    ]),
    h("div", { style: { ...styles.fsStationGuard, color: guard2 ? "var(--text,#0A2233)" : "var(--faint,#9DB4BF)" }, key: "g" }, guard2 || "Unassigned"),
    h("div", { style: styles.fsStationNext, key: "x" }, next ? [h(ArrowRightLeft, { size: 12, key: "a" }), " then ", next] : (live ? "stays on" : "—"))
  ]);
}
function RotationBoard({ freeSwim, candidates, unlocked, onStart, onStop, onAddGuard, onRemoveGuard, onMoveGuard, onToggleDuty, onSetAllDuty, onSetStations, onSetGroupMin, onSetScheduleMode, onSetManualCell, onFillManual }) {
  const [now, setNow] = useState(() => Date.now());
  const [newGuard, setNewGuard] = useState("");
  const [editing, setEditing] = useState(false);
  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 1e3);
    return () => clearInterval(iv);
  }, []);
  const guards = freeSwim.guards || [];
  const onDuty = freeSwim.onDuty || [];
  // The toggle roster shows the guard candidate pool: roster guards PLUS anyone
  // whose staff role is lifeguard/both (passed in as `candidates`). Falls back to
  // the raw roster if no candidate list was supplied.
  const dutyRoster = candidates && candidates.length ? candidates : guards;
  const activeGuards = dutyRoster.filter((g) => onDuty.includes(g));
  const stations = freeSwim.stations && freeSwim.stations.length ? freeSwim.stations : DEFAULT_STATIONS;
  const groupMin = freeSwim.groupMin === 15 ? 15 : 30;
  const blockLen = groupMin === 15 ? 1 : 2;
  const manualMode = freeSwim.mode === "manual";
  const startedAt = liveStartedAt(freeSwim.startedAt || 0, now);
  const period = freeSwimPeriodIndex(startedAt, now);
  const running = startedAt > 0 && period >= 0 && period < FREE_SWIM_PERIODS;
  const over = startedAt > 0 && period >= FREE_SWIM_PERIODS;
  // Keep the deck screen awake while the rotation is LIVE. Fully feature-
  // detected; the lock auto-releases when the tab hides, so re-acquire on
  // return. Any failure (unsupported, denied) is silently safe.
  useEffect(() => {
    if (!running) return;
    let lock = null;
    const acquire = async () => {
      try {
        if (typeof navigator !== "undefined" && navigator.wakeLock && navigator.wakeLock.request) {
          lock = await navigator.wakeLock.request("screen");
        }
      } catch {}
    };
    const onVis = () => { try { if (document.visibilityState === "visible") acquire(); } catch {} };
    acquire();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      try { if (lock) lock.release(); } catch {}
    };
  }, [running]);
  const showPeriod = running ? period : over ? FREE_SWIM_PERIODS - 1 : 0;
  const cur = planForPeriod(freeSwim, activeGuards, stations, showPeriod, blockLen);
  const next = planForPeriod(freeSwim, activeGuards, stations, showPeriod + 1, blockLen);
  const baseStart = startedAt || todayAt(FREE_SWIM_START_HOUR);
  const periodStart = startedAt + showPeriod * SWITCH_MIN * 6e4;
  const periodEnd = Math.min(startedAt + (showPeriod + 1) * SWITCH_MIN * 6e4, startedAt + FREE_SWIM_DURATION_MS);
  const msToSwitch = running ? periodEnd - now : 0;
  const msToEnd = running ? startedAt + FREE_SWIM_DURATION_MS - now : 0;
  const nextIsNewCrew = running && Math.floor((showPeriod + 1) / blockLen) !== Math.floor(showPeriod / blockLen);
  const statusPill = over ? h("span", { style: styles.fsPillDone }, [h(Check, { size: 13, key: "c" }), " Free swim ended"]) : running ? h("span", { style: styles.fsPillLive }, [h("span", { style: styles.fsLiveDot, key: "d", className: "fspulse" }), "LIVE \xB7 Rotation ", period + 1, " of ", FREE_SWIM_PERIODS]) : h("span", { style: styles.fsPillIdle }, [h(Timer, { size: 13, key: "t" }), " Not started"]);
  const controls = h("div", { style: styles.fsControls }, over || running ? [
    h("button", { key: "r", style: styles.fsResetBtn, onClick: () => onStop() }, [h(RotateCcw, { size: 15, key: "i" }), " Reset rotation"])
  ] : [
    h("button", { key: "s", style: styles.fsStartBtn, onClick: () => onStart(Date.now()) }, [h(Play, { size: 17, key: "p" }), " Start rotation now"]),
    h("button", { key: "t", style: styles.fsTimeBtn, onClick: () => onStart(todayAt(FREE_SWIM_START_HOUR)) }, "Set to 2:00 PM")
  ]);
  const heroTop = h("div", { style: styles.fsHeroTop }, [
    h("div", { key: "l", style: styles.fsHeroLeft }, [
      h("div", { style: styles.fsKicker, key: "k" }, running ? "On station right now" : over ? "Final lineup" : "Starting lineup"),
      h("div", { style: styles.fsWindow, key: "w" }, running ? `${fmtClock(periodStart)} – ${fmtClock(periodEnd)}` : "2:00 – 3:25 PM · free swim")
    ]),
    running && h("div", { key: "c", style: styles.fsCountWrap }, [
      h("div", { style: styles.fsCountNum, key: "n" }, fmtCountdown(msToSwitch)),
      h("div", { style: styles.fsCountLbl, key: "l" }, nextIsNewCrew ? "until crew change" : "until switch")
    ])
  ]);
  const heroCards = h("div", { style: styles.fsStationGrid }, stations.map((st, i) => h(StationCardFS, {
    key: i,
    index: i,
    station: st,
    guard2: cur.assign[i] && cur.assign[i].guard,
    next: next.assign[i] && next.assign[i].guard,
    live: running
  })));
  const breakRow = cur.breaks.length > 0 && h("div", { style: styles.fsBreakRow }, [
    h(Coffee, { size: 15, key: "c", style: { color: "#9A6212", flexShrink: 0 } }),
    h("span", { style: styles.fsBreakLbl, key: "l" }, "On break"),
    ...cur.breaks.map((g, i) => h("span", { style: styles.fsBreakChip, key: "g" + i }, g))
  ]);
  const understaffed = activeGuards.length > 0 && activeGuards.length < stations.length;
  const warn = understaffed && h("div", { style: styles.fsWarn }, [
    h(AlertCircle, { size: 15, key: "a", style: { flexShrink: 0 } }),
    unlocked ? `Only ${activeGuards.length} guard${activeGuards.length === 1 ? "" : "s"} on duty for ${stations.length} zones — add another guard on duty or switch to 2 zones below.` : `Only ${activeGuards.length} guard${activeGuards.length === 1 ? "" : "s"} on duty for ${stations.length} zones — an editor can add guards or reduce zones.`
  ]);
  const noneOnDuty = activeGuards.length === 0 && h("div", { style: styles.fsNoneOnDuty }, [
    h(LifeBuoy, { size: 16, key: "i", style: { color: "#7C5CFF", flexShrink: 0 } }),
    unlocked ? "Tap the guards on duty for free swim below to build the rotation." : "No guards marked on duty yet — an editor can set the lineup below."
  ]);
  const isLastPeriod = showPeriod >= FREE_SWIM_PERIODS - 1;
  const nowGuards = cur.assign.filter((a) => a.guard);
  const nextGuards = next.assign.filter((a) => a.guard);
  const nowSet = /* @__PURE__ */ new Set(nowGuards.map((a) => a.guard));
  const newInNext = /* @__PURE__ */ new Set(nextGuards.filter((a) => !nowSet.has(a.guard)).map((a) => a.guard));
  const nnChip = (a, isNew, key) => {
    const si = stations.indexOf(a.station);
    const color = stationColor(si < 0 ? 0 : si);
    return h("div", { style: { ...styles.nnChip, borderLeftColor: color }, key }, [
      h("div", { key: "x", style: { minWidth: 0 } }, [
        h("div", { style: styles.nnGuard, key: "g" }, a.guard),
        h("div", { style: styles.nnStation, key: "s" }, a.station)
      ]),
      isNew && h("span", { style: styles.nnIn, key: "in" }, "in")
    ]);
  };
  const endClock = fmtClock((running ? startedAt : todayAt(FREE_SWIM_START_HOUR)) + FREE_SWIM_DURATION_MS);
  const nowNext = activeGuards.length > 0 && h("div", { style: styles.nnCard }, [
    h("div", { style: styles.nnCol, key: "now" }, [
      h("div", { style: styles.nnHead, key: "h" }, [h("span", { style: styles.nnHeadNow, key: "d" }), h("span", { key: "t" }, running ? "On station now" : over ? "Final lineup" : "First up")]),
      h("div", { style: styles.nnList, key: "l" }, nowGuards.length ? nowGuards.map((a, i) => nnChip(a, false, i)) : h("span", { style: styles.nnEmpty, key: "e" }, "—"))
    ]),
    h("div", { style: styles.nnArrow, key: "arr" }, h(ChevronRight, { size: 20, style: { color: "var(--faint,#B9CDD3)" } })),
    h("div", { style: styles.nnCol, key: "next" }, [
      h("div", { style: styles.nnHead, key: "h" }, [h("span", { style: styles.nnHeadNext, key: "d" }), h("span", { key: "t" }, isLastPeriod ? "Last rotation" : running ? `Up next · ${fmtClock(periodEnd)}` : "Up next")]),
      isLastPeriod ? h("div", { style: styles.nnEndNote, key: "e" }, `Free swim ends ${endClock}`) : h("div", { style: styles.nnList, key: "l" }, nextGuards.map((a, i) => nnChip(a, newInNext.has(a.guard), i)))
    ])
  ]);
  const schedule = h("div", { style: styles.fsSched }, [
    manualMode && unlocked && h("div", { style: styles.fsManualBar, key: "mb" }, [
      h("span", { style: styles.fsManualHint, key: "h" }, "Manual — pick a guard for each slot."),
      h("button", { style: styles.fsQuickBtn, key: "af", onClick: () => onFillManual() }, "Auto-fill")
    ]),
    h("div", { style: styles.fsSchedHead, key: "h" }, [
      h("div", { style: styles.fsSchedTime, key: "t" }, "Time"),
      ...stations.map((st, i) => h("div", { style: { ...styles.fsSchedCol, color: stationColor(i) }, key: "c" + i }, st)),
      h("div", { style: styles.fsSchedColBreak, key: "b" }, "Break")
    ]),
    ...Array.from({ length: FREE_SWIM_PERIODS }, (_, p) => {
      const r = planForPeriod(freeSwim, activeGuards, stations, p, blockLen);
      const t0 = fmtClock(baseStart + p * SWITCH_MIN * 6e4);
      const t1 = fmtClock(Math.min(baseStart + (p + 1) * SWITCH_MIN * 6e4, baseStart + FREE_SWIM_DURATION_MS));
      const isNow = running && p === period;
      const isPast = running && p < period;
      return h("div", { key: p, style: { ...styles.fsSchedRow, ...isNow ? styles.fsSchedRowNow : {}, ...isPast ? styles.fsSchedRowPast : {} } }, [
        h("div", { style: styles.fsSchedTime, key: "t" }, [t0, h("span", { style: styles.fsSchedTime2, key: "x" }, t1)]),
        ...r.assign.map((a, i) => h("div", { style: styles.fsSchedCell, key: "c" + i }, manualMode && unlocked ? h("select", { style: styles.fsCellSelect, value: a.guard || "", onChange: (e) => onSetManualCell(p, i, e.target.value) }, [h("option", { value: "", key: "_" }, "—"), ...activeGuards.map((g, gi) => h("option", { value: g, key: gi }, g))]) : a.guard || "—")),
        h("div", { style: styles.fsSchedCellBreak, key: "b" }, r.breaks.length ? r.breaks.join(", ") : "—")
      ]);
    })
  ]);
  const crew = h("div", { style: styles.fsCrew }, [
    h("div", { style: styles.fsCrewHead, key: "h" }, [
      h("span", { style: styles.fsCrewTitle, key: "t" }, [h(Users, { size: 15, key: "u", style: { color: legibleColor("#1D7A8C") } }), ` On duty today (${activeGuards.length}/${dutyRoster.length})`]),
      unlocked && h("div", { key: "qa", style: styles.fsQuickWrap }, [
        h("button", { key: "all", style: styles.fsQuickBtn, onClick: () => onSetAllDuty(true) }, "All on"),
        h("button", { key: "clr", style: styles.fsQuickBtn, onClick: () => onSetAllDuty(false) }, "Clear"),
        h("button", { key: "e", style: styles.fsCrewEdit, onClick: () => setEditing((v) => !v) }, editing ? "Done" : "Edit roster")
      ])
    ]),
    !unlocked && h("p", { style: styles.fsCrewSub, key: "sub" }, "Highlighted guards are on duty and in the rotation. Unlock editing to change the lineup."),
    unlocked && h("p", { style: styles.fsCrewSub, key: "sub" }, "Tap a guard to put them on or off duty for today. The numbered order is their place in the rotation."),
    h("div", { style: styles.fsCrewList, key: "l" }, dutyRoster.length === 0 ? h("div", { style: styles.fsCrewEmpty }, "No guards or lifeguards yet — add a lifeguard below, or set someone's role to lifeguard in the Today tab.") : dutyRoster.map((g, i) => {
      const dutyIdx = activeGuards.indexOf(g);
      const on = dutyIdx >= 0;
      // Roster index for the move/remove tools — role-only candidates not yet in
      // the saved guard roster have no index, so those tools are hidden for them.
      const rosterIdx = guards.findIndex((x) => normName(x) === normName(g));
      const inRoster = rosterIdx >= 0;
      return h("div", { style: styles.fsDutyItem, key: i }, [
        h("button", {
          key: "tog",
          style: { ...styles.fsDutyChip, ...on ? styles.fsDutyChipOn : {} },
          onClick: () => onToggleDuty(g),
          disabled: !unlocked,
          title: unlocked ? (on ? "On duty — tap to take off" : "Off duty — tap to put on") : g
        }, [
          on ? h("span", { style: styles.fsDutyNum, key: "n" }, dutyIdx + 1) : h("span", { style: styles.fsDutyDot, key: "d" }),
          h("span", { style: styles.fsGuardName2, key: "g" }, g)
        ]),
        editing && unlocked && inRoster && h("span", { style: styles.fsGuardTools, key: "t" }, [
          h("button", { key: "up", style: styles.fsGuardBtn, disabled: rosterIdx === 0, onClick: () => onMoveGuard(rosterIdx, -1), title: "Move up" }, "↑"),
          h("button", { key: "dn", style: styles.fsGuardBtn, disabled: rosterIdx === guards.length - 1, onClick: () => onMoveGuard(rosterIdx, 1), title: "Move down" }, "↓"),
          h("button", { key: "rm", style: styles.fsGuardX, onClick: () => onRemoveGuard(rosterIdx), title: "Remove from roster" }, h(X, { size: 13 }))
        ])
      ]);
    })),
    unlocked ? (editing && h("div", { style: styles.fsAddRow, key: "a" }, [
      h("input", {
        key: "in",
        style: styles.fsAddInput,
        value: newGuard,
        placeholder: "Add a certified lifeguard…",
        "aria-label": "Add a certified lifeguard",
        onChange: (e) => setNewGuard(e.target.value),
        onKeyDown: (e) => { if (e.key === "Enter") { onAddGuard(newGuard); setNewGuard(""); } }
      }),
      h("button", { key: "b", style: styles.fsAddBtn, onClick: () => { onAddGuard(newGuard); setNewGuard(""); } }, [h(UserPlus, { size: 15, key: "u" }), " Add"])
    ])) : h("div", { style: styles.fsLockHint, key: "lh" }, [h(Lock, { size: 13, key: "l" }), " Tap “View only” in the header to unlock the timer and crew."]),
    unlocked && h("div", { style: styles.fsModeRow, key: "sm" }, [
      h("span", { style: styles.fsModeLbl, key: "l" }, "Schedule"),
      h("button", { key: "a", style: { ...styles.fsModeBtn, ...!manualMode ? styles.fsModeBtnOn : {} }, onClick: () => onSetScheduleMode("auto") }, "Auto rotate"),
      h("button", { key: "man", style: { ...styles.fsModeBtn, ...manualMode ? styles.fsModeBtnOn : {} }, onClick: () => onSetScheduleMode("manual") }, "Manual place")
    ]),
    unlocked && h("div", { style: styles.fsModeRow, key: "m" }, [
      h("span", { style: styles.fsModeLbl, key: "l" }, "Zones"),
      h("button", { key: "2", style: { ...styles.fsModeBtn, ...stations.length === 2 ? styles.fsModeBtnOn : {} }, onClick: () => onSetStations(2) }, "2 · shallow + deep"),
      h("button", { key: "3", style: { ...styles.fsModeBtn, ...stations.length === 3 ? styles.fsModeBtnOn : {} }, onClick: () => onSetStations(3) }, "3 · shallow / middle / deep")
    ]),
    unlocked && !manualMode && h("div", { style: styles.fsModeRow, key: "cm" }, [
      h("span", { style: styles.fsModeLbl, key: "l" }, "New crew"),
      h("button", { key: "30", style: { ...styles.fsModeBtn, ...groupMin === 30 ? styles.fsModeBtnOn : {} }, onClick: () => onSetGroupMin(30) }, "every 30 min · steady"),
      h("button", { key: "15", style: { ...styles.fsModeBtn, ...groupMin === 15 ? styles.fsModeBtnOn : {} }, onClick: () => onSetGroupMin(15) }, "every 15 min · slow day")
    ])
  ]);
  const explain = h("details", { style: styles.fsExplain }, [
    h("summary", { style: styles.fsExplainSum, key: "s" }, "How the rotation works"),
    h("div", { style: styles.fsExplainBody, key: "b" }, [
      h("p", { key: "1", style: styles.fsExplainP }, "Tap the guards who are on duty for free swim. Stations switch every 15 minutes, and each 30-minute block hands the zones to the next group, so guards stay fresh."),
      h("p", { key: "2", style: styles.fsExplainP }, "With 3 on duty, all three stay on and rotate through shallow → middle → deep. Put more guards on duty and they rotate onto breaks. Switch to 2 zones for a smaller crew."),
      h("p", { key: "2b", style: styles.fsExplainP }, "“New crew” sets how often a fresh group swaps in: every 30 minutes on a steady day, or every 15 minutes on a slow day so more guards cycle through breaks. The “On now / Up next” band shows who's on and who's coming up."),
      h("p", { key: "2c", style: styles.fsExplainP }, "Want to set the lineup yourself? Switch Schedule to “Manual place” and pick a guard for each slot in the grid — “Auto-fill” drops in the automatic rotation as a starting point."),
      h("p", { key: "3", style: styles.fsExplainP }, "Press Start at 2:00 sharp — the board counts down to each switch and moves everyone for you.")
    ])
  ]);
  return h("main", { style: styles.fsMain }, [
    h("div", { style: styles.fsHero, key: "hero" }, [
      h("div", { style: styles.fsHeroBar, key: "bar" }, [
        h("div", { style: styles.fsHeroTitleRow, key: "tr" }, [
          h("div", { style: styles.fsHeroTitleWrap, key: "tw" }, [
            h(Waves, { size: 18, key: "w", style: { color: "#fff", opacity: 0.9 } }),
            h("span", { style: styles.fsHeroTitle, key: "t" }, "Free Swim Rotation")
          ]),
          statusPill
        ]),
        heroTop
      ]),
      heroCards,
      noneOnDuty,
      breakRow,
      warn,
      running && h("div", { style: styles.fsEndNote, key: "en" }, `Free swim wraps in ${fmtCountdown(msToEnd)} · ends ${fmtClock(startedAt + FREE_SWIM_DURATION_MS)}`),
      controls
    ]),
    nowNext,
    schedule,
    crew,
    explain
  ]);
}
function RotationMini({ freeSwim, onOpen }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 1e3);
    return () => clearInterval(iv);
  }, []);
  const guards = freeSwim.guards || [];
  const onDuty = freeSwim.onDuty || [];
  const activeGuards = guards.filter((g) => onDuty.includes(g));
  const stations = freeSwim.stations && freeSwim.stations.length ? freeSwim.stations : DEFAULT_STATIONS;
  const blockLen = freeSwim.groupMin === 15 ? 1 : 2;
  const startedAt = liveStartedAt(freeSwim.startedAt || 0, now);
  const period = freeSwimPeriodIndex(startedAt, now);
  const running = startedAt > 0 && period >= 0 && period < FREE_SWIM_PERIODS;
  const over = startedAt > 0 && period >= FREE_SWIM_PERIODS;
  const cur = running ? planForPeriod(freeSwim, activeGuards, stations, period, blockLen) : null;
  const isLastPeriod = period >= FREE_SWIM_PERIODS - 1;
  const next = running && !isLastPeriod ? planForPeriod(freeSwim, activeGuards, stations, period + 1, blockLen) : null;
  const periodEnd = running ? Math.min(startedAt + (period + 1) * SWITCH_MIN * 6e4, startedAt + FREE_SWIM_DURATION_MS) : 0;
  const msToSwitch = running ? periodEnd - now : 0;
  const header = h("div", { style: styles.miniTop, key: "top" }, [
    h("div", { style: styles.miniTitleWrap, key: "tw" }, [
      h(LifeBuoy, { size: 16, key: "i", style: { color: running ? "#fff" : "#7C5CFF", flexShrink: 0 } }),
      h("span", { style: styles.miniTitle, key: "t" }, "Free Swim Rotation")
    ]),
    running ? h("span", { style: styles.miniLive, key: "l" }, [h("span", { style: styles.miniLiveDot, key: "d", className: "fspulse" }), `LIVE \xB7 ${fmtCountdown(msToSwitch)}`]) : h("span", { style: styles.miniWhen, key: "w" }, over ? "Ended for today" : "2:00 – 3:25 PM")
  ]);
  const body = running ? h("div", { style: { ...styles.miniStations, gridTemplateColumns: `repeat(${stations.length}, 1fr)` }, key: "body" }, stations.map((st, i) => h("div", { style: styles.miniStation, key: i }, [
    h("span", { style: { ...styles.miniDot, background: stationColor(i) }, key: "d" }),
    h("div", { style: { minWidth: 0 }, key: "x" }, [
      h("div", { style: styles.miniStName, key: "n" }, st),
      h("div", { style: styles.miniStGuard, key: "g" }, cur.assign[i] && cur.assign[i].guard || "—")
    ])
  ]))) : h("div", { style: styles.miniIdle, key: "body" }, activeGuards.length > 0 ? `${activeGuards.length} of ${guards.length} guards on duty \xB7 tap to start the rotation` : `${guards.length} guards in the roster \xB7 tap to set who's on duty today`);
  const nextLine = running && h("div", { style: styles.miniNext, key: "next" }, next ? `Up next ${fmtClock(periodEnd)} · ${next.assign.filter((a) => a.guard).map((a) => a.guard).join(", ")}` : `Last rotation · ends ${fmtClock(startedAt + FREE_SWIM_DURATION_MS)}`);
  const foot = h("div", { style: running ? styles.miniFoot : styles.miniFootIdle, key: "foot" }, [
    h("span", { key: "t" }, running ? "Tap for the full live board" : "Open the full rotation board"),
    h(ChevronRight, { size: 15, key: "c", style: { flexShrink: 0 } })
  ]);
  return h("button", { style: { ...styles.miniCard, ...running ? styles.miniCardLive : {} }, onClick: onOpen }, [header, body, nextLine, foot]);
}
var css = `
  :root {
    color-scheme: light;
    --maxw: 760px;
    --display: 'Bricolage Grotesque', 'Hanken Grotesk', system-ui, sans-serif;
    --accent-gold: #E8A23C;
    --page-bg:
      linear-gradient(180deg, #FBFDFE 0%, #F2F8FA 55%, #E8F2F5 100%);
    --surface: #fff;
    --surface-2: #EAF1F2;
    --surface-3: #FAFCFC;
    --text: #0A2233;
    --heading: #0B3C5D;
    --muted: #46606C;
    --faint: #5E7884;
    --border: #DCE6E8;
    --border-soft: #ECF1F2;
    --teal-ink: #1D7A8C;
    /* Status-chip ink. The old single hex set was tuned on dark surfaces and
       measured 1.8-2.3:1 on light cards — invisible in daylight. */
    --ink-ok: #0B6B5C;
    --ink-no: #9E3023;
    --ink-wait: #5B4B9E;
    --ink-time: #8A6320;
    --hd-bg: #0B3C5D;
  }
  /* Color themes (Settings → App color). Placed BEFORE the dark block so dark
     mode keeps its own surface/text vars; each palette keeps white header text
     and dark heading ink at 4.5:1+ so no label ever fades out. */
  :root[data-accent="sunset"] {
    --hd-bg: #46203E;
    --heading: #6B2149;
    --teal-ink: #A3486B;
    --page-bg: linear-gradient(180deg, #FFFBF7 0%, #FBEFE9 55%, #F6E3DC 100%);
  }
  :root[data-accent="forest"] {
    --hd-bg: #0E3B2E;
    --heading: #155239;
    --teal-ink: #2E7D5B;
    --page-bg: linear-gradient(180deg, #FAFDFB 0%, #EFF7F1 55%, #E3F0E7 100%);
  }
  :root[data-accent="midnight"] {
    --hd-bg: #232B52;
    --heading: #2C3A6B;
    --teal-ink: #5566B8;
    --page-bg: linear-gradient(180deg, #FBFCFE 0%, #F0F3FA 55%, #E6EAF6 100%);
  }
  :root[data-theme="dark"] {
    color-scheme: dark;
    --page-bg:
      radial-gradient(1300px 900px at 50% -20%, rgba(29,122,140,.12), transparent 60%),
      linear-gradient(180deg, #0B1320 0%, #0D1925 55%, #0A1520 100%);
    --surface: #19232F;
    --surface-2: #243140;
    --surface-3: #1F2A37;
    --text: #E6EDF3;
    --heading: #CFE0EA;
    --muted: #A6B8C2;
    --faint: #94A9B6;
    --border: #2E3C4A;
    --border-soft: #283443;
    --teal-ink: #5FBBD0;
    --ink-ok: #19B6A0;
    --ink-no: #E2725B;
    --ink-wait: #A99AFF;
    --ink-time: #C8923A;
  }
  /* Dark mode deepens each theme's header so it doesn't glow at night. */
  :root[data-theme="dark"][data-accent="sunset"] { --hd-bg: #331230; }
  :root[data-theme="dark"][data-accent="forest"] { --hd-bg: #0A2C22; }
  :root[data-theme="dark"][data-accent="midnight"] { --hd-bg: #181F3D; }
  @media (min-width: 980px) { :root { --maxw: 1180px; } }
  * { box-sizing: border-box; }
  /* Expanded tap target for the attendance check WITHOUT changing its look:
     the invisible ::after halo catches taps, lifting the 26px box past 44px. */
  .ag-check { position: relative; }
  .ag-check::after { content: ""; position: absolute; inset: -9px; }
  /* Mobile header polish (sync-36): tighter type and even spacing on phones.
     Inline styles always beat classes, so these overrides need !important. */
  @media (max-width: 620px) {
    .ag-hd-in { padding: 10px 0 12px !important; gap: 8px !important; }
    .ag-hd-wave { width: 32px !important; height: 32px !important; border-radius: 9px !important; }
    .ag-hd-h1 { font-size: 18px !important; letter-spacing: -0.2px !important; line-height: 1.15 !important; }
    .ag-hd-kick { font-size: 9.5px !important; letter-spacing: 1.1px !important; }
    .ag-hd-clock { font-size: 12px !important; margin-top: 1px !important; }
    .ag-hd-act { width: 100% !important; justify-content: center !important; gap: 7px !important; row-gap: 7px !important; }
    .ag-hd-greet { text-align: center !important; font-size: 13px !important; }
  }
  html, body { margin: 0; background: var(--page-bg); background-attachment: fixed; }
  body { font-family: 'Hanken Grotesk', system-ui, -apple-system, sans-serif; }
  .spin { animation: spin 1s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .agpulse { animation: agpulse 1.8s ease-in-out infinite; }
  @keyframes agpulse { 0%,100% { box-shadow: 0 0 0 0 rgba(232,160,44,.55); } 55% { box-shadow: 0 0 0 8px rgba(232,160,44,0); } }
  @media (prefers-reduced-motion: reduce) { .agpulse { animation: none; } }
  .fspulse { animation: fspulse 1.6s ease-in-out infinite; }
  @keyframes fspulse { 0%,100% { opacity: 1; transform: scale(1); } 50% { opacity: .45; transform: scale(.7); } }
  input:focus { outline: 2px solid #2DD4BF; outline-offset: 1px; }
  button:focus-visible { outline: 2px solid #2DD4BF; outline-offset: 2px; }
  ::placeholder { color: var(--faint,#6E8A98); }
  /* --- Login gate: aquatic atmosphere --- */
  @keyframes agDrift1 { 0%,100% { transform: translate(0,0) scale(1); } 50% { transform: translate(36px,-28px) scale(1.12); } }
  @keyframes agDrift2 { 0%,100% { transform: translate(0,0) scale(1); } 50% { transform: translate(-30px,30px) scale(1.08); } }
  @keyframes agRipple { 0% { transform: translateX(-50%) translateY(0); opacity:.5; } 50% { opacity:.85; } 100% { transform: translateX(-50%) translateY(-10px); opacity:.5; } }
  @keyframes agRise { from { opacity:0; transform: translateY(14px); } to { opacity:1; transform: translateY(0); } }
  .ag-orb1 { animation: agDrift1 18s ease-in-out infinite; }
  .ag-orb2 { animation: agDrift2 22s ease-in-out infinite; }
  .ag-ripple { animation: agRipple 7s ease-in-out infinite; }
  .ag-rise { opacity: 0; animation: agRise .7s cubic-bezier(.22,.61,.36,1) forwards; }
  .ag-d1 { animation-delay: .05s; } .ag-d2 { animation-delay: .16s; }
  .ag-d3 { animation-delay: .27s; } .ag-d4 { animation-delay: .38s; } .ag-d5 { animation-delay: .49s; }
  .ag-gate-input::placeholder { color: rgba(220,238,240,.55); }
  .ag-gate-input:focus { outline: 2px solid #2DD4BF; outline-offset: 2px; border-color: #2DD4BF !important; background: rgba(6,40,58,.5) !important; }
  .ag-signin { transition: transform .18s ease, box-shadow .18s ease, filter .18s ease; }
  .ag-signin:hover { transform: translateY(-1px); box-shadow: 0 10px 26px rgba(232,162,60,.42); filter: brightness(1.03); }
  .ag-signin:active { transform: translateY(0); box-shadow: 0 4px 12px rgba(232,162,60,.34); }
  @media (prefers-reduced-motion: reduce) { *, .spin, .ag-orb1, .ag-orb2, .ag-ripple, .ag-rise { animation: none !important; transition: none !important; } .ag-rise { opacity: 1 !important; } }
`;
// ── Time clock UI ────────────────────────────────────────────────────────
// Compact punch card. Instructors see it at the top of My Lessons; the owner
// gets the same card inside the Staff Hours dialog. Reads live durations off
// the shared 30s tick (clockTick prop is only read to stay fresh).
// Wraps the horizontally-scrolling tab rail with "there's more" affordances:
// soft edge fades plus a floating chevron whenever tabs are hidden off-screen
// (staff kept missing Free swim / Hours because nothing hinted at scrolling).
function RailScroller({ children }) {
  const wrapRef = useRef(null);
  const [edge, setEdge] = useState({ l: false, r: false });
  const railEl = () => wrapRef.current ? wrapRef.current.firstChild : null;
  const measure = () => {
    const el = railEl();
    if (!el) return;
    const l = el.scrollLeft > 6;
    const r = el.scrollLeft + el.clientWidth < el.scrollWidth - 6;
    setEdge((p) => p.l === l && p.r === r ? p : { l, r });
  };
  // Listeners attach ONCE (the missing deps array re-attached them every
  // render); the measure itself still runs per render because the rail's
  // content — and so its scrollWidth — changes.
  useEffect(() => {
    const el = railEl();
    if (!el) return;
    el.addEventListener("scroll", measure, { passive: true });
    window.addEventListener("resize", measure);
    const t = setTimeout(measure, 400);
    return () => { el.removeEventListener("scroll", measure); window.removeEventListener("resize", measure); clearTimeout(t); };
  }, []);
  useEffect(() => { measure(); });
  const nudge = () => {
    const el = railEl();
    if (el && typeof el.scrollBy === "function") el.scrollBy({ left: Math.max(120, el.clientWidth * 0.6), behavior: "smooth" });
  };
  return h("div", { ref: wrapRef, style: { position: "relative" } }, [
    children,
    edge.l && h("div", { key: "lf", "aria-hidden": true, style: { position: "absolute", left: 0, top: 0, bottom: 0, width: 28, pointerEvents: "none", background: "linear-gradient(to right, var(--bg,#F2F7F8), rgba(242,247,248,0))" } }),
    edge.r && h("div", { key: "rf", "aria-hidden": true, style: { position: "absolute", right: 0, top: 0, bottom: 0, width: 46, pointerEvents: "none", background: "linear-gradient(to left, var(--bg,#F2F7F8), rgba(242,247,248,0))" } }),
    edge.r && h("button", {
      key: "rc",
      onClick: nudge,
      "aria-label": "Scroll to see more sections",
      title: "More sections",
      style: { position: "absolute", right: 4, top: "50%", transform: "translateY(-50%)", width: 27, height: 27, borderRadius: 99, border: "none", background: "var(--surface,#fff)", boxShadow: "0 1px 7px rgba(11,60,93,.25)", color: "var(--heading,#0B3C5D)", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", padding: 0 }
    }, h(ChevronRight, { size: 16 }))
  ]);
}
// Per-device notification toggle. iOS only supports web push for apps that
// are INSTALLED to the home screen (16.4+), so the card explains itself when
// the capability isn't there instead of showing a button that can't work.
function NotifCard({ userId, copy }) {
  const [state, setState] = useState("checking"); // unsupported | off | on | busy | checking
  const [msg, setMsg] = useState("");
  const supported = typeof window !== "undefined" && "Notification" in window && "serviceWorker" in navigator && "PushManager" in window;
  useEffect(() => {
    let alive = true;
    (async () => {
      if (!supported) { if (alive) setState("unsupported"); return; }
      try {
        const reg = await navigator.serviceWorker.ready;
        const sub = await reg.pushManager.getSubscription();
        if (alive) setState(sub && Notification.permission === "granted" ? "on" : "off");
      } catch { if (alive) setState("off"); }
    })();
    return () => { alive = false; };
  }, []);
  const enable = async () => {
    setState("busy"); setMsg("");
    try {
      const perm = await Notification.requestPermission();
      if (perm !== "granted") { setState("off"); setMsg("Notifications are blocked \u2014 allow them in Settings for this app."); return; }
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: pushKeyBytes(VAPID_PUBLIC) });
      await saveMyPushSubscription(userId, sub);
      setState("on");
    } catch (e) {
      setState("off");
      setMsg("Couldn't turn on notifications: " + String(e && e.message || e).slice(0, 110));
    }
  };
  const disable = async () => {
    setState("busy");
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (sub) { await deleteMyPushSubscription(sub.endpoint); await sub.unsubscribe(); }
    } catch {}
    setState("off");
  };
  return h("section", { style: { ...styles.card, padding: "12px 13px", display: "flex", flexDirection: "column", gap: 8 } }, [
    h("div", { key: "t", style: { display: "flex", alignItems: "center", gap: 8 } }, [
      h(AlertCircle, { size: 16, key: "i", style: { color: legibleColor("#1D7A8C"), flexShrink: 0 } }),
      h("div", { key: "l", style: { fontWeight: 800, fontSize: 14, color: "var(--text)" } }, "Notifications"),
      state === "on" && h("span", { key: "on", style: { marginLeft: "auto", fontSize: 11, fontWeight: 900, color: "#0E9F8E", background: "rgba(45,212,191,.16)", borderRadius: 999, padding: "3px 9px" } }, "ON")
    ]),
    state === "unsupported"
      ? h("div", { key: "u", style: { fontSize: 12.5, fontWeight: 600, color: "var(--muted,#46606C)" } }, "To get notifications on iPhone, add this app to your Home Screen first (Share \u2192 Add to Home Screen), then come back here.")
      : h("div", { key: "b", style: { display: "flex", flexDirection: "column", gap: 7 } }, [
          h("div", { key: "d", style: { fontSize: 12.5, fontWeight: 600, color: "var(--muted,#46606C)" } }, copy || "Get a ping when your shift requests are approved or declined."),
          h("button", {
            key: "btn",
            style: { ...styles.acctAddBtn, background: state === "on" ? "var(--surface-2,#EAF1F2)" : "#0E9F8E", color: state === "on" ? "var(--text)" : "#fff", ...state === "busy" || state === "checking" ? { opacity: 0.7 } : {} },
            disabled: state === "busy" || state === "checking",
            onClick: () => (state === "on" ? disable() : enable()),
            "aria-label": state === "on" ? "Turn notifications off" : "Turn notifications on"
          }, state === "busy" || state === "checking" ? "One sec\u2026" : state === "on" ? "Turn off on this device" : "Enable notifications"),
          msg && h("div", { key: "m", style: { fontSize: 12, fontWeight: 700, color: "#8A6A1F" } }, msg)
        ])
  ]);
}
// ── Kiosk mode ───────────────────────────────────────────────────────────
// A shared pool-deck tablet opens the site with ?kiosk and gets THIS screen
// instead of the app: tap your name, type your 4-digit PIN, you're punched.
// The tablet never signs into anyone's account — it holds only a device key
// (entered once by an admin) and every punch is verified server-side by the
// kiosk-punch function. Punches land in the same rows the app uses, so they
// show up everywhere within a second via realtime.
async function kioskCall(kioskKey, payload) {
  const { data, error } = await supa.functions.invoke("kiosk-punch", { body: payload, headers: { "x-kiosk-key": kioskKey } });
  if (error) throw new Error(error.message || "Kiosk call failed");
  return typeof data === "string" ? JSON.parse(data) : data;
}
function KioskApp() {
  const [kioskKey, setKioskKey] = useState(() => { try { return localStorage.getItem("kiosk_key") || ""; } catch { return ""; } });
  const [keyDraft, setKeyDraft] = useState("");
  const [staffRows, setStaffRows] = useState(null);
  const [err, setErr] = useState("");
  const [sel, setSel] = useState(null);
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState(null); // { good, text }
  const refresh = async (key) => {
    try {
      const res = await kioskCall(key, { action: "list" });
      setStaffRows(Array.isArray(res.staff) ? res.staff : []);
      setErr("");
    } catch (e) {
      setErr("Can't reach the kiosk service \u2014 check the device key and wifi.");
      // Keep the last-known grid: one failed 60s poll must not blank the
      // tablet for staff mid-punch. Only show empty if nothing ever loaded.
      setStaffRows((rows) => rows === null ? [] : rows);
    }
  };
  useEffect(() => {
    if (!kioskKey) return;
    refresh(kioskKey);
    // Skip the fetch while the tab is hidden (an idle kiosk tab in someone's
    // pocket shouldn't burn data); catch back up the moment it's visible.
    const iv = setInterval(() => { if (typeof document === "undefined" || !document.hidden) refresh(kioskKey); }, 60000);
    const onVis = () => { if (document.visibilityState === "visible") refresh(kioskKey); };
    document.addEventListener("visibilitychange", onVis);
    return () => { clearInterval(iv); document.removeEventListener("visibilitychange", onVis); };
  }, [kioskKey]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => { setToast(null); setSel(null); setPin(""); }, 3500);
    return () => clearTimeout(t);
  }, [toast]);
  // A kiosk is a wall/desk tablet — keep its screen awake. Feature-detected;
  // re-acquires on tab return (the lock auto-releases on hide).
  useEffect(() => {
    let lock = null;
    const acquire = async () => {
      try {
        if (typeof navigator !== "undefined" && navigator.wakeLock && navigator.wakeLock.request) {
          lock = await navigator.wakeLock.request("screen");
        }
      } catch {}
    };
    const onVis = () => { try { if (document.visibilityState === "visible") acquire(); } catch {} };
    acquire();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      try { if (lock) lock.release(); } catch {}
    };
  }, []);
  const press = (d) => {
    if (busy) return;
    const next = (pin + d).slice(0, 4);
    setPin(next);
    if (next.length === 4) punch(next);
  };
  const punch = async (code) => {
    setBusy(true);
    try {
      const res = await kioskCall(kioskKey, { action: "punch", userId: sel.id, pin: code });
      if (res.ok) {
        setToast({ good: true, text: `${res.name} \u2014 clocked ${res.dir === "in" ? "IN \u2705" : "OUT \uD83D\uDC4B"}` });
        refresh(kioskKey);
      } else {
        setToast({ good: false, text: res.error || "Try again." });
      }
    } catch {
      setToast({ good: false, text: "Couldn't reach the kiosk service." });
    }
    setBusy(false);
    setPin("");
  };
  const big = { fontFamily: "inherit", border: "none", cursor: "pointer", borderRadius: 18 };
  if (!kioskKey) {
    return h("div", { style: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#0B3C5D", padding: 20 } },
      h("div", { style: { background: "#fff", borderRadius: 20, padding: 24, maxWidth: 420, width: "100%" } }, [
        h("h1", { key: "t", style: { margin: 0, fontSize: 22, color: "#0B3C5D" } }, "Set up this kiosk"),
        h("p", { key: "p", style: { fontSize: 14, color: "#46606C", fontWeight: 600 } }, "Paste the kiosk device key (an admin has it). This is done once per tablet."),
        h("input", { key: "in", type: "password", value: keyDraft, onChange: (e) => setKeyDraft(e.target.value), "aria-label": "Kiosk device key", style: { width: "100%", padding: "12px 14px", fontSize: 16, borderRadius: 12, border: "1.5px solid #DCE6E8", boxSizing: "border-box" } }),
        h("button", { key: "go", style: { ...big, marginTop: 12, width: "100%", padding: 14, background: "#0E9F8E", color: "#fff", fontSize: 16, fontWeight: 800 }, onClick: () => { const k = keyDraft.trim(); if (!k) return; try { localStorage.setItem("kiosk_key", k); } catch {} setKioskKey(k); } }, "Start kiosk")
      ]));
  }
  return h("div", { style: { minHeight: "100vh", background: "#0B3C5D", padding: "20px 16px 40px", color: "#fff" } }, [
    h("div", { key: "hd", style: { display: "flex", alignItems: "center", gap: 10, maxWidth: 900, margin: "0 auto 18px" } }, [
      h(Waves, { size: 26, key: "i" }),
      h("h1", { key: "t", style: { margin: 0, fontSize: 24, flex: 1 } }, "Time clock"),
      h("div", { key: "d", style: { fontSize: 14, fontWeight: 800, opacity: 0.85 } }, prettyDate(pstDateKey()))
    ]),
    toast && h("div", { key: "toast", role: "status", style: { maxWidth: 900, margin: "0 auto 16px", padding: "16px 18px", borderRadius: 16, fontSize: 20, fontWeight: 900, textAlign: "center", background: toast.good ? "#0E9F8E" : "#B23A2C" } }, toast.text),
    err && h("div", { key: "err", style: { maxWidth: 900, margin: "0 auto 14px", padding: "12px 14px", borderRadius: 12, background: "rgba(255,255,255,.12)", fontSize: 14, fontWeight: 700, display: "flex", alignItems: "center", gap: 10 } }, [
      h("span", { key: "t", style: { flex: 1, minWidth: 0 } }, err),
      h("button", { key: "r", style: { ...big, padding: "8px 14px", background: "#0E9F8E", color: "#fff", fontSize: 13, fontWeight: 800, flexShrink: 0 }, onClick: () => refresh(kioskKey), "aria-label": "Retry loading staff" }, "Retry")
    ]),
    !sel
      ? h("div", { key: "grid", style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 12, maxWidth: 900, margin: "0 auto" } },
          staffRows === null
            ? [h("div", { key: "ld", style: { fontSize: 16, fontWeight: 700, opacity: 0.8 } }, "Loading staff\u2026")]
            : staffRows.map((p) => h("button", {
                key: p.id,
                style: { ...big, padding: "22px 12px", background: p.onClock ? "#0E9F8E" : "rgba(255,255,255,.12)", color: "#fff", fontSize: 18, fontWeight: 900, display: "flex", flexDirection: "column", gap: 6, alignItems: "center" },
                onClick: () => { setSel(p); setPin(""); setToast(null); },
                "aria-label": `${p.name} \u2014 tap to clock ${p.onClock ? "out" : "in"}`
              }, [
                h("span", { key: "n", style: { pointerEvents: "none" } }, firstNameCap(p.name) || p.name),
                h("span", { key: "s", style: { fontSize: 11.5, fontWeight: 800, opacity: 0.85, pointerEvents: "none" } }, p.onClock ? "ON THE CLOCK" : "tap to clock in")
              ])))
      : h("div", { key: "pin", style: { maxWidth: 380, margin: "0 auto", textAlign: "center" } }, [
          h("div", { key: "who", style: { fontSize: 22, fontWeight: 900, marginBottom: 4 } }, sel.name),
          h("div", { key: "ask", style: { fontSize: 14, fontWeight: 700, opacity: 0.85, marginBottom: 14 } }, sel.hasPin ? `Enter your PIN to clock ${sel.onClock ? "out" : "in"}` : "No PIN set \u2014 ask an admin to set one in Instructor accounts."),
          h("div", { key: "dots", style: { fontSize: 34, letterSpacing: 12, minHeight: 44, marginBottom: 10 } }, "\u25CF".repeat(pin.length) + "\u25CB".repeat(4 - pin.length)),
          h("div", { key: "pad", style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 } }, [
            ...["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((d) => h("button", { key: d, style: { ...big, padding: "18px 0", fontSize: 24, fontWeight: 900, background: "rgba(255,255,255,.14)", color: "#fff" }, disabled: busy || !sel.hasPin, onClick: () => press(d), "aria-label": `PIN digit ${d}` }, d)),
            h("button", { key: "back", style: { ...big, padding: "18px 0", fontSize: 18, fontWeight: 900, background: "rgba(255,255,255,.08)", color: "#fff" }, onClick: () => { setSel(null); setPin(""); }, "aria-label": "Back to names" }, "\u2190"),
            h("button", { key: "0", style: { ...big, padding: "18px 0", fontSize: 24, fontWeight: 900, background: "rgba(255,255,255,.14)", color: "#fff" }, disabled: busy || !sel.hasPin, onClick: () => press("0"), "aria-label": "PIN digit 0" }, "0"),
            h("button", { key: "del", style: { ...big, padding: "18px 0", fontSize: 18, fontWeight: 900, background: "rgba(255,255,255,.08)", color: "#fff" }, disabled: busy, onClick: () => setPin(pin.slice(0, -1)), "aria-label": "Delete digit" }, "\u232B")
          ]),
          busy && h("div", { key: "b", style: { marginTop: 12, fontSize: 14, fontWeight: 800, opacity: 0.85 } }, "Checking\u2026")
        ])
  ]);
}
function PreviewPicker({ accounts, onPick, onClose }) {
  const list = (accounts || []).filter((a) => a && a.role !== "owner" && a.active !== false && a.name && a.name.trim());
  return h(Modal, { onClose, labelledBy: "previewPickTitle" }, [
    h("div", { style: styles.modalHead, key: "h" }, [
      h("div", { key: "t" }, [
        h("div", { style: styles.kicker, key: "k" }, "Admin"),
        h("h2", { id: "previewPickTitle", style: styles.modalTitle, key: "ti" }, "Preview as instructor")
      ]),
      h("button", { style: styles.iconBtn, onClick: onClose, key: "x", "aria-label": "Close" }, h(X, { size: 18 }))
    ]),
    h("div", { style: { ...styles.settingsBody, overflowY: "auto", paddingBottom: 16 }, key: "b" }, [
      h("p", { style: styles.settingsText, key: "p" }, "See the app exactly as one of your instructors does \u2014 their lessons, their time clock, their tabs \u2014 with live data. Everything is look-don't-touch: no taps in preview can change or save anything."),
      list.length === 0 && h("div", { style: styles.reqEmpty, key: "empty" }, "No active instructor accounts yet \u2014 create one first in Instructor accounts."),
      ...list.map((a) => h("button", {
        key: a.id,
        style: { ...styles.acctCard, flexDirection: "row", alignItems: "center", gap: 10, cursor: "pointer", width: "100%", textAlign: "left", fontFamily: "inherit", fontSize: 14 },
        onClick: () => onPick(a),
        "aria-label": `Preview as ${a.name}`
      }, [
        h("span", { style: styles.acctAvatar, key: "av" }, a.name.trim().charAt(0).toUpperCase()),
        h("span", { style: { fontWeight: 700, color: "var(--text)", flex: 1 }, key: "n" }, a.name),
        h(Eye, { size: 16, key: "i", style: { color: "var(--faint,#B9CDD3)" } })
      ]))
    ])
  ]);
}
function ClockCard({ open, todayMs, weekMs, busy, onIn, onOut, clockTick, compact, readOnly, fixTarget, pendingFix, onRequestTimeEdit }) {
  void clockTick;
  const now = Date.now();
  const elapsed = open ? now - open.in : 0;
  const longShift = open && elapsed > LONG_SHIFT_WARN_MS;
  // Arrival-fix editor: staff propose a corrected clock-in for fixTarget. It
  // becomes a request an admin approves \u2014 never a direct write to the shift.
  const [fix, setFix] = useState(null); // { in: "HH:MM", reason: "" }
  const [fixErr, setFixErr] = useState("");
  const canFix = !!(fixTarget && onRequestTimeEdit && !readOnly && !pendingFix);
  const sendFix = () => {
    const tin = dayTimeToMs(fixTarget.day, fix && fix.in);
    if (!tin) { setFixErr("Enter a valid time."); return; }
    if (tin === fixTarget.in) { setFixErr("That's already the recorded time."); return; }
    if (tin >= (fixTarget.out || Date.now())) { setFixErr(fixTarget.out ? "Arrival must be before your clock-out." : "Arrival must be earlier than now."); return; }
    onRequestTimeEdit(fixTarget.id, fixTarget.day, fixTarget.in, tin, (fix && fix.reason) || "");
    setFix(null); setFixErr("");
  };
  return h("section", { style: { ...styles.card, padding: compact ? "12px 13px" : "14px 15px", display: "flex", flexDirection: "column", gap: 8 } }, [
    h("div", { key: "top", style: { display: "flex", alignItems: "center", gap: 8 } }, [
      h(Timer, { size: 17, key: "i", style: { color: legibleColor("#1D7A8C"), flexShrink: 0 } }),
      h("div", { key: "t", style: { fontWeight: 800, fontSize: 14.5, color: "var(--text)" } }, "Time clock"),
      open && h("span", { key: "live", style: { marginLeft: "auto", fontSize: 11.5, fontWeight: 800, color: legibleColor("#0B6B60"), background: "rgba(45,212,191,.16)", borderRadius: 999, padding: "3px 9px", whiteSpace: "nowrap" } }, "ON THE CLOCK")
    ]),
    h("div", { key: "status", style: { fontSize: 13, fontWeight: 600, color: "var(--muted,#5B7A88)" } },
      open ? `Clocked in at ${fmtPunchTime(open.in)} \u00B7 ${fmtDur(elapsed)} so far` : "You're clocked out."
    ),
    pendingFix && h("div", { key: "fixpend", style: { ...styles.pendingTag, alignSelf: "flex-start", marginTop: 0 } }, [
      h(ArrowRightLeft, { size: 11, key: "i" }),
      ` Arrival fix sent (${fmtPunchTime(pendingFix.newIn)}) \u00B7 waiting for admin`
    ]),
    canFix && !fix && h("button", {
      key: "fixbtn",
      style: { alignSelf: "flex-start", background: "none", border: "none", padding: "10px 0", margin: "-6px 0", fontSize: 12.5, fontWeight: 700, color: legibleColor("#1D7A8C"), textDecoration: "underline", cursor: "pointer", fontFamily: "inherit" },
      onClick: () => { setFixErr(""); setFix({ in: msToDayTime(fixTarget.in), reason: "" }); }
    }, "Wrong arrival time? Ask an admin to fix it"),
    canFix && fix && h("div", { key: "fixed", style: { display: "flex", flexDirection: "column", gap: 7, background: "var(--surface-3,#FAFCFC)", border: "1px solid var(--border-soft,#ECF1F2)", borderRadius: 10, padding: "10px 11px" } }, [
      h("div", { key: "l", style: { fontSize: 12.5, fontWeight: 600, color: "var(--muted,#5B7A88)" } }, `Recorded ${fmtPunchTime(fixTarget.in)} on ${prettyDate(fixTarget.day)}. Pick when you really arrived \u2014 an admin approves it before anything changes.`),
      h("input", { key: "t", type: "time", value: fix.in, "aria-label": "Corrected arrival time", style: { ...styles.keyInput, padding: "8px 10px", width: "auto", alignSelf: "flex-start", minWidth: 120 }, onChange: (ev) => setFix((f) => ({ ...f, in: ev.target.value })) }),
      h("input", { key: "r", value: fix.reason, placeholder: "Reason (optional)", "aria-label": "Reason for the time fix", style: { ...styles.reqReasonInput, marginTop: 0 }, onChange: (ev) => setFix((f) => ({ ...f, reason: ev.target.value })) }),
      fixErr && h("div", { key: "e", role: "alert", style: { fontSize: 12, fontWeight: 700, color: "#B23A2C" } }, fixErr),
      h("div", { key: "b", style: { display: "flex", gap: 8 } }, [
        h("button", { key: "c", style: { background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", color: "var(--muted,#5B7A88)", borderRadius: 9, padding: "9px 12px", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "inherit" }, onClick: () => { setFix(null); setFixErr(""); } }, "Cancel"),
        h("button", { key: "s", style: { ...styles.reqSendBtn, marginTop: 0, width: "auto", flex: 1 }, onClick: sendFix }, [h(Check, { size: 14, key: "i" }), " Send for approval"])
      ])
    ]),
    longShift && h("div", { key: "warn", style: { fontSize: 12.5, fontWeight: 600, color: "#8A6A1F", background: "rgba(232,160,44,.16)", borderRadius: 8, padding: "7px 10px" } }, "This shift is over 10 hours \u2014 forgot to clock out earlier? Clock out now, then ask an admin to fix the times."),
    h("button", {
      key: "btn",
      style: { ...styles.acctAddBtn, background: readOnly ? "#9AB4BC" : open ? "#B23A2C" : "#0E9F8E", ...busy || readOnly ? { opacity: 0.75, cursor: "default" } : {} },
      disabled: busy || readOnly,
      onClick: () => (open ? onOut() : onIn()),
      "aria-label": readOnly ? "Time clock (preview)" : open ? "Clock out" : "Clock in"
    }, [busy ? h(Loader2, { size: 15, key: "i", className: "spin" }) : h(Timer, { size: 15, key: "i" }), readOnly ? " Preview \u2014 punching disabled" : busy ? " Saving\u2026" : open ? " Clock out" : " Clock in"]),
    h("div", { key: "totals", style: { fontSize: 12.5, fontWeight: 700, color: "var(--muted,#5B7A88)" } }, `Today ${fmtDur(todayMs)} \u00B7 This week ${fmtDur(weekMs)}`)
  ]);
}
// Owner/admin staff-hours dashboard: who's on the clock right now, weekly
// totals per person, and per-shift detail with edit / delete / add / force
// clock-out. All adjustments go through onAdjust (optimistic + revert).
function HoursPanel({ rows, accounts, myUserId, myName, selfPunch, onAdjust, clockTick, autoClockOut, onSetAutoClockOut, schedule, onSetSchedule, lateToday }) {
  void clockTick;
  const [wk, setWk] = useState(weekKeyFor(pstDateKey()));
  const [openId, setOpenId] = useState(null);
  const [qDayFor, setQDayFor] = useState({});
  const [err, setErr] = useState("");
  const [busyId, setBusyId] = useState(null);
  const [editShift, setEditShift] = useState(null); // { userId, shiftId, day, in, out }
  const [adding, setAdding] = useState(null); // { userId, day, in, out }
  const now = Date.now();
  const todayKey = pstDateKey();
  // Identity vs display: staff.schedule (and CSV rows) are keyed by the RAW
  // name, so the "(you)" suffix must never leak into keys — it stored the
  // admin's own schedule under "Name (you)", broke lateToday matching, and
  // diverged across devices. rawNameFor is the key; nameFor is UI text only.
  const rawNameFor = (id) => {
    if (id === myUserId) return String(myName || "Me");
    const a = (accounts || []).find((x) => x.id === id);
    if (a && a.name) return a.name;
    // Fall back to the name their own device stamped onto the row — keeps
    // hours readable even if the login was deleted or renamed.
    const row = (rows || []).find((r) => r && r.user_id === id);
    const travelling = row && row.attendance && typeof row.attendance.__name === "string" ? row.attendance.__name.trim() : "";
    return travelling || `Unknown (${String(id).slice(0, 6)})`;
  };
  const nameFor = (id) => id === myUserId ? `${rawNameFor(id)} (you)` : rawNameFor(id);
  // People = everyone with a login (accounts excludes self, so add self) plus
  // anyone with punches on record but no matching account (e.g. deleted login).
  const people = (() => {
    const map = /* @__PURE__ */ new Map();
    map.set(myUserId, { id: myUserId, name: rawNameFor(myUserId), label: nameFor(myUserId) });
    (accounts || []).forEach((a) => map.set(a.id, { id: a.id, name: a.name, label: a.name }));
    (rows || []).forEach((r) => { if (r && r.user_id && !map.has(r.user_id)) map.set(r.user_id, { id: r.user_id, name: rawNameFor(r.user_id), label: nameFor(r.user_id) }); });
    return [...map.values()];
  })();
  const shiftsFor = (id) => sanitizeShifts(((rows || []).find((r) => r && r.user_id === id) || {}).shifts);
  const enriched = people.map((p) => {
    const list = shiftsFor(p.id);
    return { ...p, list, weekMs: shiftsMsForWeek(list, wk, now), open: list.find((s) => !s.out) || null };
  }).sort((a, b) => b.weekMs - a.weekMs || a.name.localeCompare(b.name));
  const onClock = enriched.filter((p) => p.open);
  const seasonMs = (list) => list.reduce((t, s) => t + shiftMs(s, now), 0);
  const run = async (userId, mutate) => {
    setErr(""); setBusyId(userId);
    const res = await onAdjust(userId, mutate);
    if (!res || !res.ok) setErr((res && res.error) || "Couldn't save that adjustment.");
    setBusyId(null);
    return res && res.ok;
  };
  // Admin clock-in (mirror of the force clock-out): opens a live shift for
  // someone who forgot to punch. No-op if they already have an open shift, so
  // a stale tap can never double-clock anyone.
  const clockInNow = (userId) => run(userId, (cur) => cur.some((s) => !s.out) ? cur : [...cur, { id: `sh-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, in: roundClockIn(Date.now()), out: 0, day: pstDateKey() }]);
  const saveEdit = async () => {
    const e = editShift;
    if (!e) return;
    const tin = dayTimeToMs(e.day, e.in);
    const tout = e.out ? dayTimeToMs(e.day, e.out) : 0;
    if (!tin) { setErr("Enter a valid clock-in time."); return; }
    if (tout && tout <= tin) { setErr("Clock-out must be after clock-in."); return; }
    const ok = await run(e.userId, (cur) => cur.map((s) => s.id === e.shiftId ? { ...s, in: tin, out: tout, day: e.day } : s));
    if (ok) setEditShift(null);
  };
  const saveAdd = async () => {
    const a = adding;
    if (!a) return;
    const tin = dayTimeToMs(a.day, a.in);
    const tout = a.out ? dayTimeToMs(a.day, a.out) : 0;
    if (!tin || !tout || tout <= tin) { setErr("Enter valid in and out times."); return; }
    const ok = await run(a.userId, (cur) => [...cur, { id: `sh-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, in: tin, out: tout, day: a.day }]);
    if (ok) setAdding(null);
  };
  const timeInput = (val, set, label) => h("input", { style: { ...styles.keyInput, padding: "8px 10px", width: "auto", flex: "1 1 110px", minWidth: 110 }, type: "time", value: val, "aria-label": label, onChange: (ev) => set(ev.target.value) });
  const dateInput = (val, set) => h("input", { style: { ...styles.keyInput, padding: "8px 10px", width: "auto", flex: "1 1 100%" }, type: "date", value: val, "aria-label": "Shift date", onChange: (ev) => set(ev.target.value) });
  // Week CSV for payroll: one row per person, a column per day, plus total.
  const exportWeekCSV = () => {
    const days = Array.from({ length: 7 }, (_, i) => shiftDateKey(wk, i));
    const esc = (v) => {
      let str = String(v ?? "");
      if (/^[=+\-@\t\r]/.test(str)) str = "'" + str;
      return `"${str.replace(/"/g, '""')}"`;
    };
    const head2 = ["Name", ...days.map((d) => prettyDate(d)), "Total (h)", "Scheduled (h)"];
    const schedH = (name) => {
      // Same legacy "(you)"-key fold as the schedule editor's read path.
      const legacySch = (schedule || {})[`${name} (you)`];
      const mySch = legacySch ? { ...legacySch, ...((schedule || {})[name] || {}) } : ((schedule || {})[name] || {});
      let t = 0;
      for (const r of Object.values(mySch)) {
        const [a, b] = String(r).split("-");
        const d0 = dayTimeToMs("2026-01-05", a), d1 = dayTimeToMs("2026-01-05", b);
        if (d0 && d1 && d1 > d0) t += (d1 - d0) / 36e5;
      }
      return t;
    };
    const lines = enriched.map((p) => {
      const per = days.map((d) => (shiftsMsForDay(p.list, d, now) / 36e5));
      const tot = per.reduce((a, b) => a + b, 0);
      return [p.name, ...per.map((x) => x.toFixed(2)), tot.toFixed(2), schedH(p.name).toFixed(2)].map(esc).join(",");
    });
    const csv = [head2.map(esc).join(","), ...lines].join("\n");
    // UTF-8 BOM so Excel decodes accents/emoji instead of mangling them.
    const blob = new Blob([String.fromCharCode(65279) + csv], { type: "text/csv" }); // 65279 = U+FEFF byte-order mark
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `staff-hours-week-${wk}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  return h("section", { style: { display: "flex", flexDirection: "column", gap: 10 } }, [
    h("div", { key: "head", style: { display: "flex", alignItems: "center", gap: 8 } }, [
      h(Timer, { size: 18, key: "i", style: { color: legibleColor("#1D7A8C") } }),
      h("h2", { key: "t", style: { margin: 0, fontSize: 17, fontWeight: 800, color: "var(--text)", flex: 1 } }, "Staff hours"),
      h("button", { key: "csv", style: { ...styles.toolBtn }, onClick: exportWeekCSV, "aria-label": "Export this week as CSV" }, [h(Download, { size: 14, key: "i" }), " Export CSV"])
    ]),
    h("div", { style: { display: "flex", flexDirection: "column", gap: 8 }, key: "b" }, [
      selfPunch && h(ClockCard, { key: "self", compact: true, ...selfPunch }),
      // Admins can subscribe here so staff requests (clock-in fixes etc.) ping
      // their phone instead of waiting to be noticed on next open.
      h(NotifCard, { key: "notif", userId: myUserId, copy: "Get a ping on this device when staff send requests — clock-in fixes, pick-ups, drops, and trades." }),
      h("div", { key: "closecfg", style: { ...styles.acctCard, flexDirection: "row", alignItems: "center", gap: 10 } }, [
        h("div", { key: "t", style: { flex: 1, minWidth: 0 } }, [
          h("div", { style: { fontWeight: 800, fontSize: 13.5, color: "var(--text)" }, key: "l" }, "Auto clock-out at close"),
          h("div", { style: styles.acctMeta, key: "m" }, autoClockOut ? "Open shifts close automatically 30 min after this time." : "Off \u2014 pick a closing time to turn it on.")
        ]),
        h("input", { key: "in", style: { ...styles.keyInput, padding: "8px 10px", width: "auto", flex: "0 0 108px" }, type: "time", value: autoClockOut || "", "aria-label": "Pool closing time for auto clock-out", onChange: (ev) => onSetAutoClockOut(ev.target.value) }),
        autoClockOut && h("button", { key: "off", style: styles.addCancel, onClick: () => onSetAutoClockOut("") }, "Off")
      ]),
      Array.isArray(lateToday) && lateToday.length > 0 && h("div", { key: "late", style: styles.ambWarn }, [
        h("div", { style: styles.ambWarnHead, key: "h" }, [h(AlertCircle, { size: 15, key: "i" }), " Scheduled but not clocked in"]),
        ...lateToday.map((l, i) => h("div", { style: { ...styles.ambWarnRow, display: "flex", alignItems: "center", gap: 8 }, key: i }, [
          h("span", { key: "t", style: { flex: 1, minWidth: 0 } }, `${l.name} is scheduled ${l.sched.replace("-", "\u2013")} today and hasn't clocked in yet.`),
          l.userId && h("button", {
            key: "in",
            style: { ...styles.acctAddBtn, background: "#0E9F8E", padding: "8px 11px", fontSize: 12.5, flexShrink: 0, ...busyId === l.userId ? { opacity: 0.7 } : {} },
            disabled: busyId === l.userId,
            onClick: () => clockInNow(l.userId)
          }, "Clock in")
        ]))
      ]),
      (() => {
        const flagged = [];
        (rows || []).forEach((r) => {
          if (!r || !r.user_id) return;
          sanitizeShifts(r.shifts).forEach((s) => { if (s.auto) flagged.push({ userId: r.user_id, s }); });
        });
        if (!flagged.length) return null;
        return h("div", { key: "autorev", style: styles.ambWarn }, [
          h("div", { style: styles.ambWarnHead, key: "h" }, [h(AlertCircle, { size: 15, key: "i" }), " Auto clocked-out \u2014 give these a quick look"]),
          ...flagged.slice(0, 12).map(({ userId, s }) => h("div", { style: { ...styles.ambWarnRow, display: "flex", alignItems: "center", gap: 8 }, key: s.id }, [
            h("span", { key: "t", style: { flex: 1, minWidth: 0 } }, `${nameFor(userId)} \u00B7 ${prettyDate(s.day)} \u00B7 ${fmtPunchTime(s.in)}\u2013${fmtPunchTime(s.out)}`),
            h("button", { key: "ok", style: { ...styles.addCancel, padding: "6px 10px", fontSize: 12 }, disabled: busyId === userId, onClick: () => run(userId, (cur) => cur.map((c) => c.id === s.id ? (({ auto, ...rest }) => rest)(c) : c)) }, "Looks right"),
            h("button", { key: "ed", style: { ...styles.addCancel, padding: "6px 10px", fontSize: 12 }, onClick: () => { setOpenId(userId); setAdding(null); setErr(""); setEditShift({ userId, shiftId: s.id, day: s.day, in: msToDayTime(s.in), out: msToDayTime(s.out) }); } }, "Edit")
          ]))
        ]);
      })(),
      err && h("div", { style: styles.testFail, key: "err", role: "alert" }, err),
      onClock.length > 0 && h("div", { key: "live" }, [
        h("div", { style: styles.reqSectionLbl, key: "l" }, `On the clock now (${onClock.length})`),
        ...onClock.map((p) => h("div", { style: { ...styles.acctCard, flexDirection: "row", alignItems: "center", gap: 10, marginTop: 6 }, key: p.id }, [
          h("span", { key: "dot", style: { width: 9, height: 9, borderRadius: 99, background: "#0E9F8E", flexShrink: 0 } }),
          h("div", { key: "n", style: { flex: 1, minWidth: 0 } }, [
            h("div", { style: { fontWeight: 800, fontSize: 14, color: "var(--text)" }, key: "nm" }, p.label || p.name),
            h("div", { style: styles.acctMeta, key: "m" }, `In at ${fmtPunchTime(p.open.in)} \u00B7 ${fmtDur(now - p.open.in)}`)
          ]),
          p.id !== myUserId && h("button", { key: "out", style: { ...styles.acctAddBtn, background: "#B23A2C", padding: "8px 11px", fontSize: 12.5, ...busyId === p.id ? { opacity: 0.7 } : {} }, disabled: busyId === p.id, onClick: () => run(p.id, (cur) => cur.map((s) => !s.out ? { ...s, out: Math.max(Date.now(), s.in + 1000) } : s)) }, "Clock out")
        ]))
      ]),
      h("div", { key: "wknav", style: { display: "flex", alignItems: "center", gap: 8, marginTop: 4 } }, [
        h("button", { key: "p", style: styles.iconBtn, "aria-label": "Previous week", onClick: () => setWk(shiftDateKey(wk, -7)) }, h(ChevronLeft, { size: 18 })),
        h("div", { key: "l", style: { flex: 1, textAlign: "center", fontWeight: 800, fontSize: 13.5, color: "var(--text)" } }, `Week of ${prettyDate(wk)}`),
        h("button", { key: "n", style: styles.iconBtn, "aria-label": "Next week", onClick: () => setWk(shiftDateKey(wk, 7)) }, h(ChevronRight, { size: 18 }))
      ]),
      h("div", { style: styles.reqSectionLbl, key: "plbl" }, "Hours this week"),
      enriched.length === 0 && h("div", { style: styles.reqEmpty, key: "empty" }, "No staff yet."),
      ...enriched.map((p) => {
        const expanded = openId === p.id;
        const weekDays = Array.from({ length: 7 }, (_, i) => shiftDateKey(wk, i));
        const weekShifts = p.list.filter((s) => weekDays.includes(s.day)).slice().reverse();
        return h("div", { style: styles.acctCard, key: p.id }, [
          h("div", { key: "row", role: "button", tabIndex: 0, style: { display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }, onClick: () => { setOpenId(expanded ? null : p.id); setEditShift(null); setAdding(null); setErr(""); }, onKeyDown: (ev) => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); setOpenId(expanded ? null : p.id); } }, "aria-expanded": expanded }, [
            h("span", { style: { ...styles.acctAvatar, ...p.open ? { boxShadow: "0 0 0 2px #0E9F8E" } : {} }, key: "av" }, String(p.name || "?").trim().charAt(0).toUpperCase()),
            h("div", { key: "mid", style: { flex: 1, minWidth: 0 } }, [
              h("div", { style: styles.acctName, key: "n" }, p.label || p.name),
              h("div", { style: styles.acctMeta, key: "m" }, `Today ${fmtDur(shiftsMsForDay(p.list, todayKey, now))} \u00B7 season ${fmtDur(seasonMs(p.list))}`)
            ]),
            // Always-visible punch control on the row itself, left of the week
            // total: green Clock in when they're out, red Clock out when they're
            // on. stopPropagation on click AND keydown so the button never also
            // toggles the row expansion it sits inside. Self excluded — the
            // owner's own punch card at the top handles that.
            p.id !== myUserId && h("button", {
              key: "punch",
              style: { ...styles.acctAddBtn, background: p.open ? "#B23A2C" : "#0E9F8E", padding: "8px 12px", fontSize: 12.5, flexShrink: 0, ...busyId === p.id ? { opacity: 0.7 } : {} },
              disabled: busyId === p.id,
              "aria-label": p.open ? `Clock ${p.name} out now` : `Clock ${p.name} in now`,
              onKeyDown: (ev) => ev.stopPropagation(),
              onClick: (ev) => {
                ev.stopPropagation();
                if (p.open) run(p.id, (cur) => cur.map((s) => !s.out ? { ...s, out: Math.max(Date.now(), s.in + 1000) } : s));
                else clockInNow(p.id);
              }
            }, [h(Timer, { size: 13, key: "i" }), p.open ? " Clock out" : " Clock in"]),
            h("div", { key: "wk", style: { fontWeight: 800, fontSize: 15, color: legibleColor("#0B3C5D"), whiteSpace: "nowrap" } }, fmtDur(p.weekMs)),
            h(ChevronDown, { size: 16, key: "ch", style: { color: "var(--faint,#B9CDD3)", transform: expanded ? "rotate(180deg)" : "none", flexShrink: 0 } })
          ]),
          expanded && h("div", { key: "detail", style: { display: "flex", flexDirection: "column", gap: 7, borderTop: "1px solid var(--border-soft,#ECF1F2)", paddingTop: 9 } }, [
            weekShifts.length === 0 && h("div", { style: styles.acctMeta, key: "none" }, "No shifts this week."),
            ...weekShifts.map((s) => {
              if (editShift && editShift.shiftId === s.id) {
                return h("div", { key: s.id, style: { display: "flex", flexDirection: "column", gap: 7 } }, [
                  h("div", { key: "in", style: { display: "flex", gap: 7, alignItems: "center", flexWrap: "wrap" } }, [dateInput(editShift.day, (v) => setEditShift({ ...editShift, day: v })), timeInput(editShift.in, (v) => setEditShift({ ...editShift, in: v }), "Clock-in time"), timeInput(editShift.out, (v) => setEditShift({ ...editShift, out: v }), "Clock-out time")]),
                  h("div", { key: "ac", style: { display: "flex", gap: 7, justifyContent: "flex-end" } }, [
                    h("button", { key: "c", style: styles.addCancel, onClick: () => { setEditShift(null); setErr(""); } }, "Cancel"),
                    h("button", { key: "s", style: { ...styles.addSave, background: "#0E9F8E", ...busyId === p.id ? { opacity: 0.7 } : {} }, disabled: busyId === p.id, onClick: saveEdit }, "Save")
                  ])
                ]);
              }
              return h("div", { key: s.id, style: { display: "flex", alignItems: "center", gap: 8 } }, [
                h("div", { key: "t", style: { flex: 1, minWidth: 0, fontSize: 13, fontWeight: 600, color: "var(--text)" } }, [
                  s.manual
                    ? `${prettyDate(s.day)} \u00B7 Quick add`
                    : `${prettyDate(s.day)} \u00B7 ${fmtPunchTime(s.in)}\u2013${s.out ? fmtPunchTime(s.out) : "now"}`,
                  h("span", { key: "d", style: { color: "var(--muted,#5B7A88)", fontWeight: 700 } }, `  ${fmtDur(shiftMs(s, now))}`),
                  !s.out && h("span", { key: "o", style: { color: "#0E9F8E", fontWeight: 800 } }, "  \u00B7 open")
                ]),
                h("button", { key: "e", style: styles.iconBtn, "aria-label": "Edit shift", onClick: () => { setAdding(null); setErr(""); setEditShift({ userId: p.id, shiftId: s.id, day: s.day, in: msToDayTime(s.in), out: s.out ? msToDayTime(s.out) : "" }); } }, h(Pencil, { size: 15 })),
                h("button", { key: "x", style: styles.iconBtn, "aria-label": "Delete shift", onClick: () => { if (window.confirm("Delete this shift? This can't be undone.")) run(p.id, (cur) => cur.filter((c) => c.id !== s.id)); } }, h(Trash2, { size: 15 }))
              ]);
            }),
            (() => {
              const qDay = qDayFor[p.id] || pstDateKey();
              const dayTotal = shiftsMsForDay(p.list, qDay, now);
              const hasOpenThatDay = p.list.some((s) => s.day === qDay && !s.out);
              const chip = (label, ms, aria) => h("button", {
                key: label,
                style: { ...styles.addCancel, padding: "9px 4px", fontSize: 13, fontWeight: 900, flex: "1 1 0", minWidth: 0 },
                disabled: busyId === p.id || (ms < 0 && dayTotal <= 0),
                "aria-label": aria,
                onClick: () => {
                  setErr("");
                  if (ms < 0 && hasOpenThatDay && shiftsMsForDay(p.list.filter((s) => s.out > 0), qDay, now) < -ms) { setErr("Can't subtract from a running shift \u2014 clock them out first."); return; }
                  run(p.id, (cur) => ms > 0 ? quickAddBlock(cur, qDay, ms) : quickSubtract(cur, qDay, -ms));
                }
              }, label);
              return h("div", { key: "quick", style: { display: "flex", flexDirection: "column", gap: 7, borderTop: "1px solid var(--border-soft,#ECF1F2)", paddingTop: 9 } }, [
                h("div", { key: "l", style: { fontSize: 11.5, fontWeight: 900, letterSpacing: 0.4, textTransform: "uppercase", color: "var(--faint,#5E7884)" } }, "Quick hours"),
                h("div", { key: "row1", style: { display: "flex", alignItems: "center", gap: 7, flexWrap: "wrap" } }, [
                  h("input", { key: "d", style: { ...styles.keyInput, padding: "7px 9px", width: "auto", flex: "1 1 130px" }, type: "date", value: qDay, "aria-label": `Quick hours day for ${p.name}`, onChange: (ev) => setQDayFor((m) => ({ ...m, [p.id]: ev.target.value })) }),
                  h("span", { key: "t", style: { fontSize: 13, fontWeight: 900, color: "var(--heading,#0B3C5D)", whiteSpace: "nowrap" } }, `That day: ${fmtDur(dayTotal)}`)
                ]),
                h("div", { key: "row2", style: { display: "flex", gap: 6 } }, [
                  chip("+3.5h", 3.5 * 36e5, `Add 3.5 hours for ${p.name}`),
                  chip("+5.5h", 5.5 * 36e5, `Add 5.5 hours for ${p.name}`),
                  chip("+1h", 36e5, `Add 1 hour for ${p.name}`),
                  chip("+30m", 18e5, `Add 30 minutes for ${p.name}`)
                ]),
                h("div", { key: "row3", style: { display: "flex", gap: 6 } }, [
                  chip("\u22121h", -36e5, `Subtract 1 hour for ${p.name}`),
                  chip("\u221230m", -18e5, `Subtract 30 minutes for ${p.name}`)
                ])
              ]);
            })(),
            (() => {
              const DAYS = [["MO", "Mon"], ["TU", "Tue"], ["WE", "Wed"], ["TH", "Thu"], ["FR", "Fri"], ["SA", "Sat"]];
              // Migration read: a display label ("Name (you)") once leaked into
              // schedule keys — fold it under the raw name (raw values win).
              // The save path (setPersonSchedule) drops the decorated key.
              const legacySch = (schedule || {})[`${p.name} (you)`];
              const mySch = legacySch ? { ...legacySch, ...((schedule || {})[p.name] || {}) } : ((schedule || {})[p.name] || {});
              const setPart = (dk, which, val) => {
                const cur = mySch[dk] ? mySch[dk].split("-") : ["", ""];
                const next = which === 0 ? [val, cur[1]] : [cur[0], val];
                if (next[0] && next[1] && next[1] > next[0]) onSetSchedule(p.name, dk, `${next[0]}-${next[1]}`);
                else if (!val && !(which === 0 ? cur[1] : cur[0])) onSetSchedule(p.name, dk, "");
              };
              return h("div", { key: "sched", style: { display: "flex", flexDirection: "column", gap: 6, borderTop: "1px solid var(--border-soft,#ECF1F2)", paddingTop: 9 } }, [
                h("div", { style: { fontSize: 11.5, fontWeight: 900, letterSpacing: 0.4, textTransform: "uppercase", color: "var(--faint,#5E7884)" }, key: "l" }, "Weekly schedule"),
                ...DAYS.map(([dk, label]) => {
                  const [a, b] = (mySch[dk] || "-").split("-");
                  return h("div", { key: dk, style: { display: "flex", alignItems: "center", gap: 7 } }, [
                    h("span", { key: "d", style: { width: 34, fontSize: 12.5, fontWeight: 800, color: "var(--muted,#46606C)" } }, label),
                    h("input", { key: "a", style: { ...styles.keyInput, padding: "6px 8px", width: "auto", flex: 1, fontSize: 13 }, type: "time", value: a || "", "aria-label": `${p.name} ${label} start`, onChange: (ev) => setPart(dk, 0, ev.target.value) }),
                    h("input", { key: "b", style: { ...styles.keyInput, padding: "6px 8px", width: "auto", flex: 1, fontSize: 13 }, type: "time", value: b || "", "aria-label": `${p.name} ${label} end`, onChange: (ev) => setPart(dk, 1, ev.target.value) }),
                    (a || b) && h("button", { key: "x", style: { ...styles.iconBtn, flexShrink: 0 }, "aria-label": `Clear ${label} schedule`, onClick: () => onSetSchedule(p.name, dk, "") }, h(X, { size: 14 }))
                  ]);
                }),
                h("div", { style: styles.acctMeta, key: "hint" }, "Set a start and end \u2014 the Hours tab will flag anyone 15+ min late without a punch.")
              ]);
            })(),
            adding && adding.userId === p.id
              ? h("div", { key: "addrow", style: { display: "flex", flexDirection: "column", gap: 7 } }, [
                  h("div", { key: "in", style: { display: "flex", gap: 7, alignItems: "center", flexWrap: "wrap" } }, [dateInput(adding.day, (v) => setAdding({ ...adding, day: v })), timeInput(adding.in, (v) => setAdding({ ...adding, in: v }), "Clock-in time"), timeInput(adding.out, (v) => setAdding({ ...adding, out: v }), "Clock-out time")]),
                  h("div", { key: "ac", style: { display: "flex", gap: 7, justifyContent: "flex-end" } }, [
                    h("button", { key: "c", style: styles.addCancel, onClick: () => { setAdding(null); setErr(""); } }, "Cancel"),
                    h("button", { key: "s", style: { ...styles.addSave, background: "#0E9F8E", ...busyId === p.id ? { opacity: 0.7 } : {} }, disabled: busyId === p.id, onClick: saveAdd }, "Add")
                  ])
                ])
              : h("button", { key: "add", style: { ...styles.addCancel, alignSelf: "flex-start", display: "flex", alignItems: "center", gap: 6 }, onClick: () => { setEditShift(null); setErr(""); setAdding({ userId: p.id, day: weekDays.includes(todayKey) ? todayKey : wk, in: "10:00", out: "14:00" }); } }, [h(Plus, { size: 14, key: "i" }), " Add shift"])
          ])
        ]);
      }),
      h("p", { style: { ...styles.settingsText, marginTop: 4 }, key: "note" }, "Instructors clock in from My Lessons. Punches save instantly and reach every device within about 15 seconds.")
    ])
  ]);
}
function BackupsSection({ onRestore, busy }) {
  const [items, setItems] = useState(null);
  const [err, setErr] = useState("");
  const [confirmId, setConfirmId] = useState(null);
  useEffect(() => {
    let alive = true;
    listRosterBackups().then((rows) => { if (alive) setItems(rows); }).catch((e) => { if (alive) { setItems([]); setErr(String(e && e.message || e).slice(0, 120)); } });
    return () => { alive = false; };
  }, []);
  return h("div", { style: { marginTop: 18 } }, [
    h("div", { style: styles.reqSectionLbl, key: "l" }, "Backups"),
    h("p", { style: styles.settingsText, key: "p" }, "A snapshot of the whole roster is saved automatically each morning (kept ~30 days). Restoring replaces the current roster on every device \u2014 a safety copy of right-now is taken first, so a restore can itself be undone."),
    err && h("div", { style: styles.testFail, key: "e", role: "alert" }, err),
    items === null && h("div", { style: styles.acctMeta, key: "ld" }, "Loading backups\u2026"),
    items && items.length === 0 && !err && h("div", { style: styles.reqEmpty, key: "none" }, "No backups yet \u2014 the first one is written tomorrow morning."),
    ...(items || []).slice(0, 20).map((b) => h("div", { style: { ...styles.acctCard, flexDirection: "row", alignItems: "center", gap: 10 }, key: b.id }, [
      h("div", { key: "t", style: { flex: 1, minWidth: 0 } }, [
        h("div", { style: { fontWeight: 800, fontSize: 13.5, color: "var(--text)" }, key: "d" }, b.kind === "prerestore" ? "Safety copy" : prettyDate(b.day)),
        h("div", { style: styles.acctMeta, key: "m" }, b.kind === "prerestore" ? `Taken ${b.day.slice(0, 10)}` : `${(b.meta && b.meta.students) || 0} swimmers \u00B7 ${(b.meta && b.meta.weeks) || 0} weeks`)
      ]),
      confirmId === b.id
        ? h("div", { key: "cf", style: { display: "flex", gap: 6 } }, [
            h("button", { key: "n", style: styles.addCancel, onClick: () => setConfirmId(null) }, "Cancel"),
            h("button", { key: "y", style: { ...styles.addSave, background: "#B23A2C", ...busy ? { opacity: 0.7 } : {} }, disabled: busy, onClick: async () => { const r = await onRestore(b.id); if (r && r.ok) setConfirmId(null); else setErr((r && r.error) || "Restore failed."); } }, "Yes, replace")
          ])
        : h("button", { key: "r", style: { ...styles.addCancel, flexShrink: 0 }, onClick: () => { setErr(""); setConfirmId(b.id); } }, "Restore\u2026")
    ]))
  ]);
}
function AccountsDialog({ accounts, instructors, roster, freeSwim, onAdd, onUpdate, onRemove, onDelete, onRestoreBackup, backupBusy, onSeasonExport, onClose }) {
  const [pinFor, setPinFor] = useState(null);
  const [pinVal, setPinVal] = useState("");
  const [pinBusy, setPinBusy] = useState(false);
  const [pinMsg, setPinMsg] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [role, setRole] = useState("instructor");
  const [err, setErr] = useState("");
  const [okMsg, setOkMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [editId, setEditId] = useState(null);
  const [editName, setEditName] = useState("");
  const [editErr, setEditErr] = useState("");
  const [confirmDel, setConfirmDel] = useState(null);
  // delete account: per-row error, success msg, and in-flight id for the hard-delete.
  const [delErr, setDelErr] = useState({});
  const [delOk, setDelOk] = useState("");
  const [delBusy, setDelBusy] = useState(null);
  // Shared success note for rename / enable / disable actions.
  const [actionMsg, setActionMsg] = useState("");
  // Per-row in-flight id for the Disable/Enable toggle so its button can't be
  // double-clicked and never stays stuck.
  const [toggleBusy, setToggleBusy] = useState(null);
  const submitAdd = async () => {
    setErr(""); setOkMsg("");
    if (busy) return;
    if (role === "owner" && !window.confirm(`Make ${name.trim() || "this person"} an administrator? Admins can edit everything, approve requests, and manage accounts \u2014 the same as you.`)) return;
    setBusy(true);
    try {
      const res = await onAdd(name.trim(), email.trim(), pw, role);
      if (res && res.ok) {
        setOkMsg(`${role === "owner" ? "Administrator" : "Instructor"} account created for ${name.trim()}. Share the email + temporary password with them.`);
        setName(""); setEmail(""); setPw(""); setRole("instructor");
      } else {
        setErr((res && res.error) || "Couldn't create the account.");
      }
    } catch (e) {
      // Never leave a silent failure \u2014 surface whatever went wrong.
      setErr(String(e && e.message || e) || "Couldn't create the account.");
    } finally {
      // ALWAYS clear busy so the button can't stay stuck on "Creating\u2026".
      setBusy(false);
    }
  };
  // delete account: confirm, then hard-delete via onDelete. Refreshes the list
  // on success (onDelete reloads profiles); surfaces the server error per-row on
  // failure (e.g. the self-delete guard) instead of swallowing it.
  const removeForever = async (a) => {
    if (delBusy) return;
    if (!window.confirm(`Permanently delete ${a.name}'s account? This removes their login and can't be undone.`)) return;
    setDelErr((p) => ({ ...p, [a.id]: "" }));
    setDelOk(""); setActionMsg("");
    setDelBusy(a.id);
    try {
      const res = await onDelete(a.id);
      if (res && res.ok) {
        setDelOk(res.note || `${a.name}'s account was permanently deleted.`);
      } else {
        setDelErr((p) => ({ ...p, [a.id]: (res && res.error) || "Couldn't delete the account." }));
      }
    } catch (e) {
      setDelErr((p) => ({ ...p, [a.id]: String(e && e.message || e) || "Couldn't delete the account." }));
    } finally {
      // ALWAYS clear the in-flight flag so the Delete button can't stay stuck.
      setDelBusy(null);
    }
  };
  const startEdit = (a) => { setEditId(a.id); setEditName(a.name); setEditErr(""); };
  const [editBusy, setEditBusy] = useState(false);
  const saveEdit = async () => {
    if (!editName.trim()) { setEditErr("Enter a name."); return; }
    if (editBusy) return;
    setEditErr(""); setActionMsg("");
    setEditBusy(true);
    try {
      const res = await onUpdate(editId, { name: editName.trim() });
      if (res && res.ok) {
        setActionMsg(res.note || `Renamed to ${editName.trim()}.`);
        setEditId(null);
      } else {
        setEditErr((res && res.error) || "Couldn't save the new name.");
      }
    } catch (e) {
      setEditErr(String(e && e.message || e) || "Couldn't save the new name.");
    } finally {
      setEditBusy(false);
    }
  };
  // Enable/disable toggle with its own busy guard and friendly success/error.
  const toggleActive = async (a) => {
    if (toggleBusy) return;
    setDelErr((p) => ({ ...p, [a.id]: "" }));
    setActionMsg(""); setDelOk("");
    setToggleBusy(a.id);
    try {
      const res = await onUpdate(a.id, { active: !a.active });
      if (res && res.ok) {
        setActionMsg(res.note || (a.active ? `${a.name} disabled.` : `${a.name} enabled.`));
      } else {
        setDelErr((p) => ({ ...p, [a.id]: (res && res.error) || "Couldn't update the account." }));
      }
    } catch (e) {
      setDelErr((p) => ({ ...p, [a.id]: String(e && e.message || e) || "Couldn't update the account." }));
    } finally {
      setToggleBusy(null);
    }
  };
  const sorted = accounts.slice().sort((a, b) => a.name.localeCompare(b.name));
  // Which (normalized) names appear on more than one account? Those rows get a
  // disambiguation line (id + created date) so duplicate "Alex" rows from earlier
  // stuck-create retries are distinguishable and individually removable.
  const dupeNames = (() => {
    const counts = {};
    accounts.forEach((a) => { const k = normName(a.name); counts[k] = (counts[k] || 0) + 1; });
    return new Set(Object.keys(counts).filter((k) => counts[k] > 1));
  })();
  const shortId = (id) => String(id || "").slice(0, 6);
  const fmtCreated = (iso) => { if (!iso) return ""; const d = new Date(iso); return isNaN(d) ? "" : d.toLocaleDateString(); };
  return h(Modal, { onClose, labelledBy: "acctDialogTitle" }, [
    h("div", { style: styles.modalHead, key: "h" }, [
      h("div", { key: "t" }, [
        h("div", { style: styles.kicker, key: "k" }, "Owner"),
        h("h2", { id: "acctDialogTitle", style: styles.modalTitle, key: "ti" }, "Instructor accounts")
      ]),
      h("button", { style: styles.iconBtn, onClick: onClose, key: "x", "aria-label": "Close" }, h(X, { size: 18 }))
    ]),
    h("div", { style: { ...styles.settingsBody, overflowY: "auto" }, key: "b" }, [
      h("p", { style: styles.settingsText, key: "intro" }, "Create a real login for each person. Instructors take attendance and request trades; administrators have full control like you. They sign in with their email and the temporary password you set (they can change it later). For instructors, the name must match the name on their lessons \u2014 that's how their lessons link to them."),
      h("div", { style: styles.acctAddCard, key: "add" }, [
        h("input", { key: "n", style: styles.keyInput, value: name, placeholder: "Instructor name (must match the name on lessons)", "aria-label": "Instructor name (must match the name on lessons)", onChange: (e) => { setName(e.target.value); setErr(""); }, onKeyDown: (e) => e.key === "Enter" && submitAdd() }),
        h("input", { key: "em", style: { ...styles.keyInput, marginTop: 8 }, value: email, type: "email", placeholder: "Email", "aria-label": "Email", autoCapitalize: "off", autoCorrect: "off", spellCheck: false, inputMode: "email", onChange: (e) => { setEmail(e.target.value); setErr(""); }, onKeyDown: (e) => e.key === "Enter" && submitAdd() }),
        h("input", { key: "pw", style: { ...styles.keyInput, marginTop: 8 }, value: pw, placeholder: "Temporary password (6+ chars)", "aria-label": "Temporary password (6+ chars)", autoCapitalize: "off", autoCorrect: "off", spellCheck: false, onChange: (e) => { setPw(e.target.value); setErr(""); }, onKeyDown: (e) => e.key === "Enter" && submitAdd() }),
        h("div", { style: styles.roleToggle, key: "rt" }, [
          h("button", { key: "i", type: "button", onClick: () => setRole("instructor"), style: { ...styles.roleOpt, ...role === "instructor" ? styles.roleOptSel : {} } }, [h(Users, { size: 14, key: "ic" }), " Instructor"]),
          h("button", { key: "o", type: "button", onClick: () => setRole("owner"), style: { ...styles.roleOpt, ...role === "owner" ? styles.roleOptSelAdmin : {} } }, [h(Unlock, { size: 14, key: "ic" }), " Administrator"])
        ]),
        role === "owner" && h("div", { style: styles.roleWarn, key: "rw" }, "Administrators have full control \u2014 edit everything, approve requests, and manage accounts."),
        err && h("div", { style: styles.testFail, key: "e", role: "alert" }, err),
        okMsg && h("div", { style: styles.testOk, key: "ok", role: "status" }, okMsg),
        h("button", { key: "btn", style: { ...styles.acctAddBtn, ...busy ? { opacity: 0.7 } : {} }, onClick: submitAdd, disabled: busy }, [busy ? h(Loader2, { size: 15, key: "i", className: "spin" }) : h(UserPlus, { size: 15, key: "i" }), busy ? " Creating\u2026" : " Create login"])
      ]),
      h("div", { style: styles.reqSectionLbl, key: "lbl" }, `Accounts (${accounts.length})`),
      delOk && h("div", { style: styles.testOk, key: "lok", role: "status" }, delOk),
      actionMsg && h("div", { style: styles.testOk, key: "amok", role: "status" }, actionMsg),
      ...(() => {
        const amb = ambiguousLessonNames(accounts, instructors);
        return amb.length ? [h("div", { style: styles.ambWarn, key: "amb" }, [
          h("div", { style: styles.ambWarnHead, key: "h" }, [h(AlertCircle, { size: 15, key: "i" }), " Name clash \u2014 lessons may link to the wrong person"]),
          ...amb.map((a, i) => h("div", { style: styles.ambWarnRow, key: i }, `A lesson says "${a.lessonName}", which matches ${a.matches.join(" and ")}. Use a fuller name on the lesson (e.g. add a last initial) so it links to the right person.`))
        ])] : [];
      })(),
      accounts.length === 0 && h("div", { style: styles.reqEmpty, key: "empty" }, "No instructor accounts yet. Create your first above."),
      ...sorted.map((a) => {
        // Pass the active-week roster so the count reflects only REAL classes
        // (ones with students this week), not empty/stale class slots.
        const links = lessonsForName(a.name, instructors, roster);
        // Free-swim duty for this person, mirroring the lessons link above.
        const shifts = shiftsForName(a.name, freeSwim);
        const shiftCount = (shifts.onDuty ? 1 : 0) + shifts.stations.length;
        if (editId === a.id) {
          return h("div", { style: styles.acctCard, key: a.id }, [
            h("input", { key: "n", autoFocus: true, style: styles.keyInput, value: editName, "aria-label": "Account name", onChange: (e) => setEditName(e.target.value), onKeyDown: (e) => e.key === "Enter" && saveEdit() }),
            h("div", { style: styles.acctEditHint, key: "hint" }, "Renaming changes which lessons link to them. Make it match the name on their lessons."),
            editErr && h("div", { style: styles.testFail, key: "ee", role: "alert" }, editErr),
            h("div", { style: styles.acctActions, key: "ac" }, [
              h("button", { style: styles.addCancel, key: "c", onClick: () => { setEditId(null); setEditErr(""); }, disabled: editBusy }, "Cancel"),
              h("button", { style: { ...styles.addSave, background: "#0E9F8E", ...editBusy ? { opacity: 0.7 } : {} }, key: "s", onClick: saveEdit, disabled: editBusy }, [editBusy ? h(Loader2, { size: 15, key: "i", className: "spin" }) : h(Check, { size: 15, key: "i" }), editBusy ? " Saving…" : " Save"])
            ])
          ]);
        }
        return h("div", { style: styles.acctCard, key: a.id }, [
          h("div", { style: styles.acctCardTop, key: "top" }, [
            h("span", { style: { ...styles.acctAvatar, ...a.active ? {} : { opacity: 0.4 } }, key: "av" }, a.name.trim().charAt(0).toUpperCase()),
            h("div", { style: { flex: 1, minWidth: 0 }, key: "mid" }, [
              h("div", { style: styles.acctName, key: "n" }, [a.name, a.role === "owner" && h("span", { style: styles.acctAdmin, key: "ad" }, "Admin"), !a.active && h("span", { style: styles.acctOff, key: "o" }, "Disabled")]),
              // Duplicate name? Show id + created date so the two rows are
              // distinguishable and the owner can remove the right one.
              dupeNames.has(normName(a.name)) && h("div", { style: styles.acctMeta, key: "dup" }, `id ${shortId(a.id)}${fmtCreated(a.createdAt) ? ` · created ${fmtCreated(a.createdAt)}` : ""}`),
              h("div", { style: styles.acctMeta, key: "m" }, links.length ? `${links.length} lesson${links.length === 1 ? "" : "s"} linked` : "No lessons linked yet"),
              shiftCount > 0 && h("div", { style: styles.acctMeta, key: "fs" }, `${shiftCount} free-swim shift${shiftCount === 1 ? "" : "s"}`)
            ])
          ]),
          links.length > 0 && h("div", { style: styles.acctLinks, key: "links" }, links.sort().map((k) => {
            const [t, l] = k.split("|");
            const lc = levelColor(l) || legibleColor("#1D7A8C");
            return h("span", { style: { ...styles.acctLinkChip, borderColor: lc }, key: k }, [
              h("span", { style: { ...styles.acctLinkDot, background: lc }, key: "d" }),
              `${t} \xB7 ${l}`
            ]);
          })),
          shiftCount > 0 && h("div", { style: styles.acctLinks, key: "shifts" }, [
            shifts.onDuty && h("span", { style: { ...styles.acctLinkChip, borderColor: stationColor(0) }, key: "onduty" }, [
              h("span", { style: { ...styles.acctLinkDot, background: stationColor(0) }, key: "d" }),
              "On duty \xB7 free swim"
            ]),
            ...shifts.stations.map((st, si) => {
              const color = stationColor(si + 1);
              return h("span", { style: { ...styles.acctLinkChip, borderColor: color }, key: "st" + si }, [
                h("span", { style: { ...styles.acctLinkDot, background: color }, key: "d" }),
                st
              ]);
            })
          ]),
          confirmDel === a.id ? h("div", { style: styles.acctConfirm, key: "cf" }, [
            h("span", { style: styles.acctConfirmTxt, key: "t" }, "Disable this account? They won't be able to sign in until you re-enable it."),
            h("div", { style: styles.acctActions, key: "ac" }, [
              h("button", { style: styles.addCancel, key: "c", onClick: () => setConfirmDel(null) }, "Keep"),
              h("button", { style: styles.acctDelBtn, key: "d", onClick: () => { setConfirmDel(null); toggleActive(a); } }, [h(Lock, { size: 14, key: "i" }), " Disable"])
            ])
          ]) : h("div", { style: styles.acctActions, key: "ac" }, [
            h("button", { style: styles.acctToggleBtn, key: "tg", onClick: () => toggleActive(a), disabled: toggleBusy === a.id }, toggleBusy === a.id ? "Working…" : a.active ? "Disable" : "Enable"),
            h("button", { style: styles.acctEditBtn, key: "e", onClick: () => startEdit(a) }, [h(Pencil, { size: 14, key: "i" }), " Rename"]),
            // delete account: destructive hard-delete (red), guarded by window.confirm in removeForever.
            h("button", { style: { ...styles.acctEditBtn, color: "#B23A2C", borderColor: "#FFB4AC" }, key: "del", onClick: () => removeForever(a), disabled: delBusy === a.id }, [h(Trash2, { size: 14, key: "i" }), delBusy === a.id ? " Deleting…" : " Delete"]),
            h("button", { style: styles.acctEditBtn, key: "pin", onClick: () => { setPinFor(pinFor === a.id ? null : a.id); setPinVal(""); setPinMsg(""); } }, [h(Lock, { size: 14, key: "i" }), " Kiosk PIN"])
          ]),
          pinFor === a.id && h("div", { key: "pinrow", style: { display: "flex", gap: 7, alignItems: "center", marginTop: 6 } }, [
            h("input", { key: "pi", style: { ...styles.keyInput, padding: "8px 10px", width: "auto", flex: 1, letterSpacing: 4, fontWeight: 800 }, inputMode: "numeric", maxLength: 4, placeholder: "4 digits", value: pinVal, "aria-label": `Kiosk PIN for ${a.name}`, onChange: (ev) => setPinVal(ev.target.value.replace(/\D/g, "").slice(0, 4)) }),
            h("button", { key: "ps", style: { ...styles.addSave, background: "#0E9F8E", ...pinBusy ? { opacity: 0.7 } : {} }, disabled: pinBusy || pinVal.length !== 4, onClick: async () => { setPinBusy(true); setPinMsg(""); try { await ownerSetPin(a.id, pinVal); setPinMsg("PIN saved \u2713"); setPinVal(""); } catch (e) { setPinMsg(String(e && e.message || e).slice(0, 100)); } setPinBusy(false); } }, "Save PIN")
          ]),
          pinFor === a.id && pinMsg && h("div", { key: "pinmsg", style: { ...styles.acctMeta, marginTop: 4, fontWeight: 800 }, role: "status" }, pinMsg),
          // delete account: per-row error (e.g. the self-delete guard message).
          delErr[a.id] && h("div", { style: styles.testFail, key: "de", role: "alert" }, delErr[a.id])
        ]);
      }),
      onRestoreBackup && h(BackupsSection, { key: "backups", onRestore: onRestoreBackup, busy: backupBusy }),
      onSeasonExport && h("div", { key: "season", style: { marginTop: 16 } }, [
        h("div", { style: styles.reqSectionLbl, key: "l" }, "Season export"),
        h("p", { style: styles.settingsText, key: "p" }, "Package the whole summer: a printable report (rosters, attendance rates, staff hours) and the raw data file for safekeeping."),
        h("div", { key: "btns", style: { display: "flex", gap: 8, flexWrap: "wrap" } }, [
          h("button", { key: "r", style: styles.acctAddBtn, onClick: () => onSeasonExport("report"), "aria-label": "Download the season report" }, [h(Download, { size: 14, key: "i" }), " Season report"]),
          h("button", { key: "j", style: { ...styles.acctAddBtn, background: "var(--surface-2,#EAF1F2)", color: "var(--text)" }, onClick: () => onSeasonExport("data"), "aria-label": "Download the raw season data" }, [h(Download, { size: 14, key: "i" }), " Raw data"])
        ])
      ])
    ]),
    h("div", { style: styles.modalFoot, key: "f" }, [
      h("button", { style: styles.primaryBtn, onClick: onClose, key: "c" }, "Done")
    ])
  ]);
}
function ShiftBoard({ weeks, activeWeek, instructors, myName, isOwner, requests, onTrade }) {
  const [trade, setTrade] = useState(null);
  const dark = isDarkTheme();
  const wk = weeks[activeWeek] || { roster: [], instructors: {}, attendance: {} };
  const roster = Array.isArray(wk.roster) ? wk.roster : [];
  // Build every class that has either students or assigned instructors.
  const classMap = {};
  roster.forEach((s) => {
    const k = `${s.time}|${s.level}`;
    if (!classMap[k]) classMap[k] = { time: s.time, level: s.level, kids: 0 };
    classMap[k].kids++;
  });
  const classes = Object.entries(classMap).map(([k, v]) => ({ key: k, ...v, instr: instructors[k] || [] }))
    .sort((a, b) => TIME_SLOTS.indexOf(a.time) - TIME_SLOTS.indexOf(b.time) || LEVELS.indexOf(a.level) - LEVELS.indexOf(b.level));
  const bySlot = {};
  classes.forEach((c) => (bySlot[c.time] = bySlot[c.time] || []).push(c));
  const slots = TIME_SLOTS.filter((t) => bySlot[t]);
  // My own classes (the ones I can offer in a trade).
  const myKeys = lessonsForName(myName, instructors, roster);
  const isMine = (c) => myKeys.includes(c.key);
  // Pending trades, to mark classes already involved in a request.
  const pendingTrades = (requests || []).filter((r) => r.kind === "trade" && r.status === "pending");
  const inPendingTrade = (c) => pendingTrades.some((r) => `${r.fromTime}|${r.fromLevel}` === c.key || `${r.toTime}|${r.toLevel}` === c.key);

  return h("div", { style: styles.sbWrap }, [
    h("div", { style: styles.sbHead, key: "hd" }, [
      h("div", { key: "l" }, [
        h("div", { style: styles.kicker, key: "k" }, "Everyone's shifts"),
        h("h2", { style: styles.sbTitle, key: "t" }, "Shift board")
      ])
    ]),
    h("p", { style: styles.sbHelp, key: "help" }, isOwner
      ? "Every class this week and who's teaching it. Instructors can tap a class to propose a trade."
      : myKeys.length
        ? "Tap any class that isn't yours to propose a trade \u2014 you'll offer one of your shifts in return, and Peter approves it."
        : "You don't have any assigned shifts yet, so there's nothing to trade. This shows everyone's classes for the week."),

    ...slots.map((t) => h("div", { style: styles.sbSlot, key: t }, [
      h("div", { style: styles.sbSlotHead, key: "sh" }, t),
      h("div", { style: styles.sbClasses, key: "sc" }, bySlot[t].map((c) => {
        const mine = isMine(c);
        const pend = inPendingTrade(c);
        const canTrade = !isOwner && !mine && myKeys.length > 0 && !pend;
        return h("button", {
          key: c.key,
          disabled: !canTrade,
          onClick: canTrade ? () => setTrade(c) : void 0,
          style: {
            ...styles.sbClass,
            borderLeftColor: levelColor(c.level, dark),
            ...mine ? styles.sbClassMine : {},
            ...pend ? styles.sbClassPend : {},
            ...canTrade ? {} : { cursor: "default" }
          }
        }, [
          h("div", { style: styles.sbClassTop, key: "ct" }, [
            h("span", { style: { ...styles.sbClassLevel, color: levelColor(c.level, dark) }, key: "l" }, c.level),
            mine && h("span", { style: styles.sbMineTag, key: "m" }, "You"),
            pend && !mine && h("span", { style: styles.sbPendTag, key: "p" }, "Trade pending")
          ]),
          h("div", { style: styles.sbClassInstr, key: "ci" }, c.instr.length ? instrFirstNames(c.instr) : h("span", { style: { color: dark ? "#FFC861" : "#9A6212", fontWeight: 700 } }, "No instructor")),
          c.kids > 0 && h("div", { style: styles.sbClassKids, key: "k" }, `${c.kids} swimmer${c.kids === 1 ? "" : "s"}`),
          canTrade && h("div", { style: styles.sbTradeHint, key: "th" }, [h(ArrowRightLeft, { size: 12, key: "i" }), " Tap to trade"])
        ]);
      }))
    ])),

    trade && h(TradeModal, {
      target: trade,
      myName,
      myKeys,
      instructors,
      onClose: () => setTrade(null),
      onSubmit: (fromKey, reason) => {
        const [ft, fl] = fromKey.split("|");
        const withName = (instructors[trade.key] || [])[0] || "";
        onTrade(ft, fl, trade.time, trade.level, withName, reason);
        setTrade(null);
      }
    })
  ]);
}
function TradeModal({ target, myName, myKeys, instructors, onClose, onSubmit }) {
  const mineSorted = myKeys.slice().sort((a, b) => TIME_SLOTS.indexOf(a.split("|")[0]) - TIME_SLOTS.indexOf(b.split("|")[0]));
  const [fromKey, setFromKey] = useState(mineSorted[0] || "");
  const [reason, setReason] = useState("");
  const targetInstr = (instructors[target.key] || []);
  const [tt, tl] = [target.time, target.level];
  return h(Modal, { onClose, labelledBy: "tradeModalTitle" }, [
    h("div", { style: styles.modalHead, key: "h" }, [
      h("div", { key: "t" }, [
        h("div", { style: styles.kicker, key: "k" }, "Propose a trade"),
        h("h2", { id: "tradeModalTitle", style: styles.modalTitle, key: "ti" }, `${tt} \xB7 ${tl}`)
      ]),
      h("button", { style: styles.iconBtn, onClick: onClose, key: "x", "aria-label": "Close" }, h(X, { size: 18 }))
    ]),
    h("div", { style: { ...styles.settingsBody, overflowY: "auto" }, key: "b" }, [
      h("p", { style: styles.settingsText, key: "p1" }, targetInstr.length
        ? `You'd take ${tt} ${tl} from ${targetInstr.join(", ")}, and they'd take the shift you give up below.`
        : `You'd take ${tt} ${tl}. Pick one of your shifts to give up in return.`),
      h("label", { style: styles.fieldLabel, key: "l1" }, "Your shift to give up"),
      mineSorted.length === 0
        ? h("div", { style: styles.testFail, key: "none" }, "You have no shifts to offer.")
        : h("div", { style: styles.tradePick, key: "pick" }, mineSorted.map((k) => {
            const [t, l] = k.split("|");
            const sel = k === fromKey;
            return h("button", {
              key: k,
              onClick: () => setFromKey(k),
              style: { ...styles.tradeOpt, ...sel ? { ...styles.tradeOptSel, borderColor: levelColor(l) || legibleColor("#1D7A8C") } : {} }
            }, [
              h("span", { style: { ...styles.tradeOptDot, background: levelColor(l) || legibleColor("#1D7A8C") }, key: "d" }),
              `${t} \xB7 ${l}`,
              sel && h(Check, { size: 15, key: "c", style: { marginLeft: "auto", color: levelColor(l) || legibleColor("#1D7A8C") } })
            ]);
          })),
      h("div", { style: styles.tradePreview, key: "prev" }, [
        h("span", { style: styles.tradePrevChip, key: "a" }, fromKey ? fromKey.replace("|", " ") : "your shift"),
        h(ArrowRightLeft, { size: 16, key: "i", style: { color: "#0E9F8E", flexShrink: 0 } }),
        h("span", { style: styles.tradePrevChip, key: "b" }, `${tt} ${tl}`)
      ]),
      h("label", { style: styles.fieldLabel, key: "l2" }, "Note (optional)"),
      h("input", { key: "rsn", style: styles.keyInput, value: reason, placeholder: "Why you'd like to trade", "aria-label": "Why you'd like to trade", onChange: (e) => setReason(e.target.value) })
    ]),
    h("div", { style: styles.modalFoot, key: "f" }, [
      h("button", { style: styles.ghostBtn, onClick: onClose, key: "c" }, "Cancel"),
      h("button", { style: { ...styles.primaryBtn, ...!fromKey ? { opacity: 0.5 } : {} }, disabled: !fromKey, onClick: () => onSubmit(fromKey, reason), key: "go" }, [h(ArrowRightLeft, { size: 16, key: "i" }), " Send to Peter"])
    ])
  ]);
}
function OwnerDashboard({ weeks, activeWeek, activeDate, instructors, accounts, staffList, requests, freeSwim, nowSlot, isToday, onOpenSlot, onOpenRequests, onOpenAccounts, onOpenFree, hoursRows, schedule, myUserId, myName, onOpenHours }) {
  const dark = isDarkTheme();
  const wk = weeks[activeWeek] || { roster: [], instructors: {}, attendance: {} };
  const roster = Array.isArray(wk.roster) ? wk.roster : [];
  const dayMarks = (wk.attendance && wk.attendance[activeDate]) || {};
  const closed = isClosed(activeDate);
  const dateLabel = prettyDate(activeDate);
  // Only show REAL classes: a time|level that actually has swimmers enrolled.
  // (We don't invent classes just because a stale instructor key exists.)
  const classMap = {};
  roster.forEach((s) => {
    const k = `${s.time}|${s.level}`;
    if (!classMap[k]) classMap[k] = { time: s.time, level: s.level, kids: 0, present: 0 };
    classMap[k].kids++;
    if (dayMarks[s.id]) classMap[k].present++;
  });
  const classes = Object.entries(classMap).map(([k, v]) => ({
    key: k, ...v, instr: instructors[k] || []
  })).sort((a, b) => TIME_SLOTS.indexOf(a.time) - TIME_SLOTS.indexOf(b.time) || LEVELS.indexOf(a.level) - LEVELS.indexOf(b.level));
  const bySlot = {};
  classes.forEach((c) => (bySlot[c.time] = bySlot[c.time] || []).push(c));
  const slotsToday = TIME_SLOTS.filter((t) => bySlot[t]);
  // Is the current hour an actual lesson slot with classes? (only relevant today)
  const liveSlot = (isToday && !closed && TIME_SLOTS.includes(nowSlot) && bySlot[nowSlot]) ? nowSlot : null;
  const isFreeSwimSlot = isToday && !closed && nowSlot === FREE_SWIM;
  const gaps = classes.filter((c) => c.kids > 0 && c.instr.length === 0);
  const pending = (requests || []).filter((r) => r.status === "pending").sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  const activeInstr = (accounts || []).filter((a) => a.active);
  const onDuty = (freeSwim.onDuty || []);
  // Count people present right now (this hour only).
  const presentNow = liveSlot ? roster.filter((s) => s.time === liveSlot && dayMarks[s.id]).length : 0;
  const enrolledNow = liveSlot ? roster.filter((s) => s.time === liveSlot).length : 0;

  // --- Free-swim live state (mirrors the FreeSwimMini card math) ---------------
  const fsGuards = freeSwim.guards || [];
  const fsActiveGuards = fsGuards.filter((g) => onDuty.includes(g));
  const fsStations = freeSwim.stations && freeSwim.stations.length ? freeSwim.stations : DEFAULT_STATIONS;
  const fsBlockLen = freeSwim.groupMin === 15 ? 1 : 2;
  const fsNow = Date.now();
  const fsStartedAt = liveStartedAt(freeSwim.startedAt || 0, fsNow);
  const fsPeriod = freeSwimPeriodIndex(fsStartedAt, fsNow);
  const fsRunning = fsStartedAt > 0 && fsPeriod >= 0 && fsPeriod < FREE_SWIM_PERIODS;
  const fsPlan = fsRunning ? planForPeriod(freeSwim, fsActiveGuards, fsStations, fsPeriod, fsBlockLen) : null;
  // Unfilled free-swim stations right now (a station with no guard while running).
  const fsUnfilled = fsRunning ? (fsPlan.assign || []).filter((a) => !a.guard).map((a) => a.station) : [];

  // --- Staff hours + today's schedule, visible with no drill-down --------------
  const hrsTodayKey = pstDateKey();
  const hrsNow = Date.now();
  const hrsNameOf = (id) => {
    const a = (accounts || []).find((x) => x.id === id);
    if (a && a.name) return a.name;
    if (id === myUserId) return myName || "Me";
    const row = (hoursRows || []).find((r) => r && r.user_id === id);
    const trav = row && row.attendance && typeof row.attendance.__name === "string" ? row.attendance.__name.trim() : "";
    return trav || "Unknown";
  };
  const hoursPeople = (Array.isArray(hoursRows) ? hoursRows : [])
    .filter((r) => r && r.user_id)
    .map((r) => {
      const list = sanitizeShifts(r.shifts);
      const open = list.find((s) => !s.out) || null;
      // Shifts the 3:45 sweep force-closed today — surfaced so the admin
      // notices right here, not only in the Hours review list.
      const autoToday = list.some((s) => s.day === hrsTodayKey && s.auto);
      return { id: r.user_id, name: hrsNameOf(r.user_id), todayMs: shiftsMsForDay(list, hrsTodayKey, hrsNow), open, autoToday };
    })
    .filter((p) => p.open || p.todayMs > 0)
    .sort((a, b) => (b.open ? 1 : 0) - (a.open ? 1 : 0) || b.todayMs - a.todayMs);
  const onClockCount2 = hoursPeople.filter((p) => p.open).length;
  const schedToday = (() => {
    const dk = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"][new Date().getDay()];
    return Object.entries(schedule || {}).map(([name, days]) => {
      const range = days && typeof days === "object" ? days[dk] : null;
      if (!range || typeof range !== "string") return null;
      const [a, b] = range.split("-");
      const sp = (staffList || []).find((p) => nameMatchesAccount(name, p.name));
      const startMin = Number(String(a).split(":")[0]) * 60 + (Number(String(a).split(":")[1]) || 0);
      return {
        name, a, b,
        role: sp ? sp.role : "instructor",
        present: sp ? sp.present : true,
        onClock: hoursPeople.some((h2) => h2.open && nameMatchesAccount(h2.name, name)),
        startMin: Number.isFinite(startMin) ? startMin : 0
      };
    }).filter(Boolean).sort((x, y) => x.startMin - y.startMin || x.name.localeCompare(y.name));
  })();
  // If free swim is the current period of the day but nobody is on duty yet, the
  // whole free-swim block is "unfilled" \u2014 surface that too.
  const fsNoDuty = isFreeSwimSlot && onDuty.length === 0;

  // --- Coverage alerts (Part 5 group 2) ---------------------------------------
  const alerts = [];
  gaps.forEach((c) => alerts.push({ kind: "class", key: c.key, time: c.time, level: c.level, kids: c.kids }));
  if (fsRunning) fsUnfilled.forEach((st, i) => alerts.push({ kind: "fs", key: "fsu" + i, station: st }));
  if (fsNoDuty) alerts.push({ kind: "fsnone", key: "fsnone" });

  // --- Per-person roll-up (Part 5 group 3) ------------------------------------
  const people = (Array.isArray(staffList) ? staffList : []).map((p) => {
    const links = lessonsForName(p.name, instructors, roster).slice().sort((x, y) => TIME_SLOTS.indexOf(x.split("|")[0]) - TIME_SLOTS.indexOf(y.split("|")[0]));
    const shifts = shiftsForName(p.name, freeSwim);
    const onDutyFs = (onDuty || []).some((g) => nameMatchesAccount(g, p.name));
    return { ...p, links, shifts, onDutyFs };
  });

  // --- Attendance at a glance (Part 5 group 4) --------------------------------
  const totalKids = roster.length;
  const presentKids = closed ? 0 : roster.filter((s) => dayMarks[s.id]).length;
  const attnPct = totalKids ? Math.round((presentKids / totalKids) * 100) : 0;

  // Who is teaching right now + who is guarding right now (Part 5 group 1).
  const nowTeaching = liveSlot ? bySlot[liveSlot] : [];
  const nowGuarding = fsRunning
    ? (fsPlan.assign || []).filter((a) => a.guard).map((a) => ({ station: a.station, guard: a.guard }))
    : [];

  return h("div", { style: styles.dashWrap }, [
    h("div", { style: styles.dashHead, key: "hd" }, [
      h("div", { key: "l" }, [
        h("div", { style: styles.kicker, key: "k" }, "Owner dashboard"),
        h("h2", { style: styles.dashTitle, key: "t" }, dateLabel)
      ]),
      h("div", { style: styles.dashHeadBtns, key: "b" }, [
        h("button", { style: styles.dashHeadBtn, key: "acc", onClick: onOpenAccounts }, [h(Users, { size: 14, key: "i" }), " Accounts"]),
        pending.length > 0 && h("button", { style: { ...styles.dashHeadBtn, background: "#0E9F8E", color: "#fff", borderColor: "#0E9F8E" }, key: "rev", onClick: onOpenRequests }, [h(ArrowRightLeft, { size: 14, key: "i" }), ` ${pending.length} to review`])
      ])
    ]),

    closed && h("div", { style: styles.dashClosed, key: "cl" }, "Pool is closed today \u2014 showing the schedule for reference."),

    // ===== GROUP 1: Live "right now" ==========================================
    isToday && !closed && (liveSlot || fsRunning || isFreeSwimSlot) && h("section", { style: styles.dashNow, key: "now" }, [
      h("div", { style: styles.dashNowTop, key: "t" }, [
        h("span", { style: styles.dashNowDot, key: "d", className: "fspulse" }),
        h("span", { style: styles.dashNowLbl, key: "l" }, liveSlot ? `Happening now \xB7 ${liveSlot}` : "Free swim \xB7 happening now"),
        liveSlot && h("span", { style: styles.dashNowCount, key: "c" }, `${presentNow}/${enrolledNow} here`)
      ]),
      // Classes teaching this slot
      liveSlot && h("div", { style: styles.dashNowSub, key: "ts" }, "In the water"),
      liveSlot && h("div", { style: styles.dashSlotClasses, key: "cls" }, nowTeaching.map((c) => h("button", {
        style: { ...styles.dashClass, background: "var(--surface)", borderLeftColor: levelColor(c.level, dark) },
        key: c.key,
        onClick: () => onOpenSlot(c.time)
      }, [
        h("div", { style: styles.dashClassTop, key: "ct" }, [
          h("span", { style: { ...styles.dashClassLevel, color: levelColor(c.level, dark) }, key: "l" }, c.level),
          h("span", { style: styles.dashClassKids, key: "k" }, `${c.present}/${c.kids}`)
        ]),
        h("div", { style: styles.dashClassInstr, key: "ci" }, c.instr.length ? instrFirstNames(c.instr) : h("span", { style: { color: dark ? "#FFC861" : "#9A6212", fontWeight: 700 } }, "\u26A0 No instructor"))
      ]))),
      // Lifeguarding now
      (fsRunning || isFreeSwimSlot) && h("div", { style: styles.dashNowSub, key: "gs" }, [h(LifeBuoy, { size: 13, key: "i", style: { verticalAlign: "-2px", marginRight: 5 } }), "On the deck"]),
      fsRunning && h("div", { style: styles.dashNowGuards, key: "guards" }, nowGuarding.length ? nowGuarding.map((g, i) => h("button", { style: styles.dashGuardChip, key: i, onClick: onOpenFree }, [
        h("span", { style: { ...styles.dashGuardDot, background: stationColor(fsStations.indexOf(g.station) < 0 ? i : fsStations.indexOf(g.station), dark) }, key: "d" }),
        h("strong", { key: "n" }, g.guard),
        h("span", { style: styles.dashGuardStation, key: "s" }, g.station)
      ])) : h("span", { style: styles.dashEmpty, key: "e" }, "No guards assigned this rotation.")),
      isFreeSwimSlot && !fsRunning && h("button", { style: styles.dashNowIdle, key: "idle", onClick: onOpenFree }, [
        h("span", { key: "t" }, onDuty.length ? `${onDuty.length} on duty \xB7 tap to start the rotation` : "Tap to set who's on duty for free swim"),
        h(ChevronRight, { size: 15, key: "c" })
      ])
    ]),

    // ===== GROUP 2: Coverage alerts ===========================================
    h("section", { style: { ...styles.dashCard, ...alerts.length ? { borderColor: dark ? "#E8B84B" : "#E8B84B" } : {} }, key: "alerts" }, [
      h("div", { style: styles.dashCardHead, key: "h" }, [
        h(AlertCircle, { size: 15, key: "i", style: { color: alerts.length ? "#D9883B" : "#0E9F8E" } }),
        h("span", { key: "t" }, alerts.length ? `Needs attention (${alerts.length})` : "Coverage")
      ]),
      alerts.length === 0 && h("div", { style: styles.dashAllClear, key: "ok" }, [h(Check, { size: 15, key: "c" }), " All classes covered \u2713"]),
      alerts.length > 0 && h("div", { style: styles.dashGapGrid, key: "g" }, alerts.map((a) => {
        if (a.kind === "class") return h("button", { style: styles.dashGapChip, key: a.key, onClick: () => onOpenSlot(a.time) }, [
          h("span", { style: { ...styles.dashGapDot, background: levelColor(a.level, dark) }, key: "d" }),
          `${a.time} \xB7 ${a.level}`,
          h("span", { style: styles.dashGapKids, key: "k" }, `${a.kids} kid${a.kids === 1 ? "" : "s"} \xB7 no instructor`)
        ]);
        if (a.kind === "fs") return h("button", { style: styles.dashGapChip, key: a.key, onClick: onOpenFree }, [
          h(LifeBuoy, { size: 13, key: "d", style: { flexShrink: 0 } }),
          `${a.station} \xB7 unfilled`
        ]);
        return h("button", { style: styles.dashGapChip, key: a.key, onClick: onOpenFree }, [
          h(LifeBuoy, { size: 13, key: "d", style: { flexShrink: 0 } }),
          "Free swim \xB7 nobody on duty"
        ]);
      }))
    ]),

    // ===== Staff hours today (main info, no drill-down) =======================
    h("section", { style: styles.dashCard, key: "hrs" }, [
      h("div", { style: styles.dashCardHead, key: "h" }, [
        h(Timer, { size: 15, key: "i", style: { color: "#0E9F8E" } }),
        h("span", { key: "t" }, onClockCount2 > 0 ? `Staff hours today · ${onClockCount2} on the clock` : "Staff hours today")
      ]),
      hoursPeople.length === 0 && h("div", { style: styles.reqEmpty, key: "e" }, "No hours yet today."),
      ...hoursPeople.slice(0, 10).map((p, i) => h("div", { key: p.id, style: { display: "flex", alignItems: "center", gap: 9, padding: "7px 2px", borderTop: i === 0 ? "none" : "1px solid var(--border-soft,#ECF1F2)" } }, [
        h("span", { key: "d", style: { width: 8, height: 8, borderRadius: 99, background: p.open ? "#0E9F8E" : "var(--border,#DCE6E8)", flexShrink: 0, ...p.open ? { boxShadow: "0 0 0 3px rgba(14,159,142,.18)" } : {} } }),
        h("span", { key: "n", style: { flex: 1, minWidth: 0, fontWeight: 800, fontSize: 13.5, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, firstNameCap(p.name) || p.name),
        p.autoToday && h("span", { key: "au", style: { fontSize: 10.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "var(--ink-time,#8A6320)", background: "rgba(200,146,58,.16)", borderRadius: 999, padding: "2px 8px", whiteSpace: "nowrap" }, title: "Didn't clock out — closed automatically at 3:45. Check the time in Hours." }, "Auto out 3:45"),
        p.open && h("span", { key: "s", style: { fontSize: 12, fontWeight: 700, color: "var(--ink-ok,#0B6B5C)", whiteSpace: "nowrap" } }, `in since ${fmtPunchTime(p.open.in)}`),
        h("span", { key: "hm", style: { fontWeight: 800, fontSize: 13.5, color: "var(--heading)", fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" } }, fmtDur(p.todayMs))
      ])),
      hoursPeople.length > 10 && h("div", { style: styles.reqEmpty, key: "moreN" }, `+ ${hoursPeople.length - 10} more in Hours`),
      h("button", { style: styles.dashMoreBtn, key: "more", onClick: onOpenHours }, "Open staff hours →")
    ]),

    // ===== Today's schedule: who lifeguards/teaches when ======================
    h("section", { style: styles.dashCard, key: "sched" }, [
      h("div", { style: styles.dashCardHead, key: "h" }, [
        h(LifeBuoy, { size: 15, key: "i", style: { color: legibleColor("#1D7A8C", dark) } }),
        h("span", { key: "t" }, "Today's schedule")
      ]),
      schedToday.length === 0 && h("div", { style: styles.reqEmpty, key: "e" }, "No one is on the weekly schedule today — set times in Hours."),
      ...schedToday.map((p, i) => h("div", { key: p.name, style: { display: "flex", alignItems: "center", gap: 9, padding: "7px 2px", borderTop: i === 0 ? "none" : "1px solid var(--border-soft,#ECF1F2)" } }, [
        h("span", { key: "d", style: { width: 8, height: 8, borderRadius: 99, background: p.onClock ? "#0E9F8E" : "var(--border,#DCE6E8)", flexShrink: 0, ...p.onClock ? { boxShadow: "0 0 0 3px rgba(14,159,142,.18)" } : {} } }),
        h("span", { key: "n", style: { flex: 1, minWidth: 0, fontWeight: 800, fontSize: 13.5, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, firstNameCap(p.name) || p.name),
        (p.role === "lifeguard" || p.role === "both") && h("span", { key: "rb", style: { fontSize: 10.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "var(--teal-ink,#1D7A8C)", background: "rgba(29,122,140,.12)", borderRadius: 999, padding: "2px 8px", whiteSpace: "nowrap" } }, "Lifeguard"),
        !p.present && h("span", { key: "ab", style: { fontSize: 10.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "var(--ink-time,#8A6320)", background: "rgba(200,146,58,.16)", borderRadius: 999, padding: "2px 8px", whiteSpace: "nowrap" } }, "Absent"),
        h("span", { key: "rg", style: { fontWeight: 800, fontSize: 13, color: "var(--heading)", fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" } }, `${p.a}–${p.b}`)
      ])),
      h("button", { style: styles.dashMoreBtn, key: "more", onClick: onOpenHours }, "Edit the weekly schedule →")
    ]),

    // ===== Pending requests (action) ==========================================
    pending.length > 0 && h("section", { style: styles.dashCard, key: "pend" }, [
      h("div", { style: styles.dashCardHead, key: "h" }, [h(ArrowRightLeft, { size: 15, key: "i", style: { color: "#0E9F8E" } }), h("span", { key: "t" }, `Requests waiting on you (${pending.length})`)]),
      ...pending.slice(0, 5).map((r) => h("button", { style: styles.dashReqRow, key: r.id, onClick: onOpenRequests }, [
        h("span", { style: styles.dashReqWho, key: "w" }, r.by || "Instructor"),
        h("span", { style: styles.dashReqWhat, key: "x" }, reqLine(r))
      ])),
      pending.length > 5 && h("button", { style: styles.dashMoreBtn, key: "more", onClick: onOpenRequests }, `View all ${pending.length} requests \u2192`)
    ]),

    // ===== GROUP 4: Attendance at a glance ====================================
    h("section", { style: styles.dashCard, key: "attn" }, [
      h("div", { style: styles.dashCardHead, key: "h" }, [h(ClipboardCheck, { size: 15, key: "i", style: { color: legibleColor("#1D7A8C", dark) } }), h("span", { key: "t" }, "Attendance at a glance")]),
      h("div", { style: styles.dashAttnTop, key: "top" }, [
        h("div", { style: styles.dashAttnBig, key: "big" }, [
          h("span", { style: styles.dashAttnNum, key: "n" }, closed ? "\u2014" : `${presentKids}/${totalKids}`),
          h("span", { style: styles.dashAttnLbl, key: "l" }, closed ? "pool closed" : "swimmers here today")
        ]),
        !closed && h("div", { style: styles.dashAttnPctWrap, key: "pct" }, [
          h("div", { style: styles.dashAttnBarTrack, key: "tr" }, h("div", { style: { ...styles.dashAttnBarFill, width: `${attnPct}%` }, key: "f" })),
          h("span", { style: styles.dashAttnPct, key: "p" }, `${attnPct}%`)
        ])
      ]),
      !closed && classes.length > 0 && h("div", { style: styles.dashAttnList, key: "list" }, classes.map((c) => {
        const pct = c.kids ? Math.round((c.present / c.kids) * 100) : 0;
        return h("button", { style: styles.dashAttnRow, key: c.key, onClick: () => onOpenSlot(c.time) }, [
          h("span", { style: { ...styles.dashAttnDot, background: levelColor(c.level, dark) }, key: "d" }),
          h("span", { style: styles.dashAttnRowLbl, key: "l" }, `${c.time} \xB7 ${c.level}`),
          h("span", { style: styles.dashAttnRowTrack, key: "tr" }, h("span", { style: { ...styles.dashAttnRowFill, width: `${pct}%`, background: levelColor(c.level, dark) }, key: "f" })),
          h("span", { style: styles.dashAttnRowNum, key: "n" }, `${c.present}/${c.kids}`)
        ]);
      }))
    ]),

    // ===== Full-day schedule ==================================================
    h("section", { style: styles.dashCard, key: "cov" }, [
      h("div", { style: styles.dashCardHead, key: "h" }, [h(LayoutGrid, { size: 15, key: "i", style: { color: legibleColor("#1D7A8C", dark) } }), h("span", { key: "t" }, isToday && !closed ? "Full day schedule" : "Schedule")]),
      slotsToday.length === 0 && h("div", { style: styles.dashEmpty, key: "e" }, "No classes scheduled."),
      ...slotsToday.map((t) => h("div", { style: { ...styles.dashSlot, ...t === liveSlot ? styles.dashSlotLive : {} }, key: t }, [
        h("div", { style: { ...styles.dashSlotHead, ...t === liveSlot ? { color: "#0E9F8E" } : { color: legibleColor("#1D7A8C", dark) } }, key: "sh" }, [t, t === liveSlot && h("span", { style: styles.dashNowMini, key: "n" }, "now")]),
        h("div", { style: styles.dashSlotClasses, key: "sc" }, bySlot[t].map((c) => h("button", {
          style: { ...styles.dashClass, borderLeftColor: levelColor(c.level, dark) },
          key: c.key,
          onClick: () => onOpenSlot(c.time)
        }, [
          h("div", { style: styles.dashClassTop, key: "ct" }, [
            h("span", { style: { ...styles.dashClassLevel, color: levelColor(c.level, dark) }, key: "l" }, c.level),
            h("span", { style: styles.dashClassKids, key: "k" }, (isToday && !closed && t === liveSlot) ? `${c.present}/${c.kids}` : `${c.kids} kid${c.kids === 1 ? "" : "s"}`)
          ]),
          h("div", { style: styles.dashClassInstr, key: "ci" }, c.instr.length ? instrFirstNames(c.instr) : h("span", { style: { color: dark ? "#FFC861" : "#9A6212", fontWeight: 700 } }, "\u26A0 No instructor"))
        ])))
      ]))
    ]),

    // Free-swim duty today
    onDuty.length > 0 && h("section", { style: styles.dashCard, key: "fs" }, [
      h("div", { style: styles.dashCardHead, key: "h" }, [h(LifeBuoy, { size: 15, key: "i", style: { color: legibleColor("#1D7A8C", dark) } }), h("span", { key: "t" }, `Free-swim lifeguards on duty (${onDuty.length})`)]),
      h("div", { style: styles.dashTagWrap, key: "w" }, onDuty.map((g) => h("span", { style: styles.dashTag, key: g }, g)))
    ]),

    // ===== GROUP 3: Per-person view ===========================================
    h("section", { style: styles.dashCard, key: "people" }, [
      h("div", { style: styles.dashCardHead, key: "h" }, [h(Users, { size: 15, key: "i", style: { color: legibleColor("#1D7A8C", dark) } }), h("span", { key: "t" }, `Who's on what (${people.length})`)]),
      people.length === 0 && h("div", { style: styles.dashEmpty, key: "e" }, "No staff yet. Tap Accounts to add instructors and lifeguards."),
      ...people.map((p) => {
        const totalOn = p.links.length + (p.onDutyFs ? 1 : 0) + p.shifts.stations.length;
        return h("div", { style: styles.dashPersonRow, key: p.name }, [
          h("div", { style: styles.dashPersonTop, key: "t" }, [
            h("span", { style: { ...styles.dashAvatar, ...p.present ? {} : { opacity: 0.45 } }, key: "av" }, p.name.trim().charAt(0).toUpperCase()),
            h("div", { style: { flex: 1, minWidth: 0 }, key: "mid" }, [
              h("div", { style: styles.dashPersonName, key: "nm" }, p.name),
              h("div", { style: styles.dashPersonMeta, key: "ro" }, [
                h(StaffRoleBadge, { role: p.role, key: "rb" }),
                h("span", { style: { ...styles.dashPresentPill, ...closed ? styles.dashPresentClosed : p.present ? styles.dashPresentYes : styles.dashPresentNo }, key: "pp" }, closed ? "Off" : p.present ? "Present" : "Absent"),
                !closed && p.selfChecked && h("span", { style: styles.selfCheckTag, key: "sc", title: "Confirmed by the instructor's own check-in" }, "✓ Checked in")
              ])
            ]),
            totalOn > 0 && h("span", { style: styles.dashInstrCount, key: "ct" }, `${totalOn} assignment${totalOn === 1 ? "" : "s"}`)
          ]),
          (p.links.length > 0 || p.onDutyFs || p.shifts.stations.length > 0) && h("div", { style: styles.dashPersonChips, key: "ch" }, [
            ...p.links.map((k) => {
              const [t, l] = k.split("|");
              return h("button", { style: { ...styles.dashInstrChip, borderColor: levelColor(l, dark) }, key: k, onClick: () => onOpenSlot(t) }, [
                h("span", { style: { ...styles.acctLinkDot, background: levelColor(l, dark) }, key: "d" }),
                `${t} \xB7 ${l}`
              ]);
            }),
            p.onDutyFs && h("button", { style: { ...styles.dashInstrChip, borderColor: stationColor(0, dark) }, key: "onduty", onClick: onOpenFree }, [
              h("span", { style: { ...styles.acctLinkDot, background: stationColor(0, dark) }, key: "d" }),
              "On duty \xB7 free swim"
            ]),
            ...p.shifts.stations.map((st, si) => h("button", { style: { ...styles.dashInstrChip, borderColor: stationColor(si + 1, dark) }, key: "st" + si, onClick: onOpenFree }, [
              h("span", { style: { ...styles.acctLinkDot, background: stationColor(si + 1, dark) }, key: "d" }),
              st
            ]))
          ]),
          totalOn === 0 && h("div", { style: styles.dashPersonIdle, key: "idle" }, "No lessons or shifts assigned")
        ]);
      })
    ])
  ]);
}
function MyLessons({ user, weeks, activeWeek, activeDate, lessonKeys, freeSwim, requests, onOpenSlot, onOpenFree, onRequestPickup, onRequestDrop, onOpenRequests }) {
  const [picker, setPicker] = useState(null);
  const dark = isDarkTheme();
  const wk = weeks[activeWeek] || { roster: [], instructors: {}, attendance: {} };
  const roster = Array.isArray(wk.roster) ? wk.roster : [];
  const dayMarks = (wk.attendance && wk.attendance[activeDate]) || {};
  const closed = isClosed(activeDate);
  const firstName = user ? user.name.split(" ")[0] : "there";
  const myKeys = lessonKeys.slice().sort((a, b) => {
    const ta = a.split("|")[0], tb = b.split("|")[0];
    return TIME_SLOTS.indexOf(ta) - TIME_SLOTS.indexOf(tb) || a.localeCompare(b);
  });
  // My free-swim duty + station(s) for the day (manual rotation grid, if set).
  // shiftsForName uses the same first-name-tolerant matcher as the rest of the
  // app, so a guard entered as "Jordan" still counts for account "Jordan Lee" —
  // the old exact normName equality here hid the duty card from them.
  const myShifts = shiftsForName(user && user.name, freeSwim);
  const onDutyFree = myShifts.onDuty;
  const myPending = requests.filter((r) => r.byId === (user && user.id) && r.status === "pending").length;
  let totalSwimmers = 0, totalPresent = 0;
  const cards = myKeys.map((k) => {
    const parts = k.split("|"), t = parts[0], l = parts[1];
    const accent = levelColor(l, dark);
    const kids = roster.filter((s) => s.time === t && s.level === l);
    const present = closed ? 0 : kids.filter((s) => dayMarks[s.id]).length;
    const pct = kids.length ? Math.round((present / kids.length) * 100) : 0;
    totalSwimmers += kids.length; totalPresent += present;
    const co = (wk.instructors[k] || []).filter((n) => normName(n) !== normName(user && user.name));
    return h("div", { style: styles.mlCard, key: k }, [
      h("button", { style: styles.mlCardMain, onClick: () => onOpenSlot(t), key: "main" }, [
        h("div", { style: { ...styles.mlBar, background: accent }, key: "bar" }),
        h("div", { style: styles.mlCardBody, key: "body" }, [
          h("div", { style: styles.mlCardTop, key: "top" }, [
            h("span", { style: { ...styles.mlLevelBadge, background: accent }, key: "lv" }, l),
            h("span", { style: styles.mlTime, key: "tm" }, t)
          ]),
          h("div", { style: styles.mlStat, key: "st" }, [
            h(Users, { size: 14, key: "i", style: { color: "var(--muted,#5B7A88)" } }),
            closed ? h("span", { key: "c" }, `${kids.length} enrolled`) : h("span", { key: "c" }, `${present}/${kids.length} here today`)
          ]),
          !closed && kids.length > 0 && h("div", { style: styles.mlProgTrack, key: "prog" }, h("div", { style: { ...styles.mlProgFill, width: `${pct}%`, background: accent }, key: "f" })),
          co.length > 0 && h("div", { style: styles.mlCo, key: "co" }, "with " + co.join(", "))
        ]),
        h(ChevronRight, { size: 18, key: "ch", style: { color: "var(--faint,#9DB4BF)", flexShrink: 0, alignSelf: "center", marginRight: 10 } })
      ]),
      h("button", { style: styles.mlDropBtn, key: "drop", onClick: () => setPicker({ kind: "drop", t, l }) }, "Request drop")
    ]);
  });
  const now = new Date();
  const hr = now.getHours();
  const greet = hr < 12 ? "Good morning" : hr < 17 ? "Good afternoon" : "Good evening";
  const todayLabel = now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });
  return h("div", { style: styles.mlWrap }, [
    h("div", { style: styles.mlHero, key: "hero" }, [
      h("div", { style: styles.mlHeroText, key: "tx" }, [
        h("div", { style: styles.mlHeroDate, key: "dt" }, todayLabel),
        h("div", { style: styles.mlHi, key: "hi" }, `${greet}, ${firstName}`),
        h("div", { style: styles.mlHeroSub, key: "sub" }, myKeys.length ? `You're assigned to ${myKeys.length} lesson${myKeys.length === 1 ? "" : "s"} this week.` : "You have no lessons assigned this week yet.")
      ]),
      h(Waves, { size: 30, key: "w", style: { color: "rgba(255,255,255,.9)", flexShrink: 0 } })
    ]),
    !closed && myKeys.length > 0 && h("div", { style: styles.mlSummary, key: "sum" }, [
      h("div", { style: styles.mlSumItem, key: "1" }, [h("div", { style: styles.mlSumNum, key: "n" }, myKeys.length), h("div", { style: styles.mlSumLbl, key: "l" }, "Lessons")]),
      h("div", { style: styles.mlSumDiv, key: "d1" }),
      h("div", { style: styles.mlSumItem, key: "2" }, [h("div", { style: styles.mlSumNum, key: "n" }, totalSwimmers), h("div", { style: styles.mlSumLbl, key: "l" }, "Swimmers")]),
      h("div", { style: styles.mlSumDiv, key: "d2" }),
      h("div", { style: styles.mlSumItem, key: "3" }, [h("div", { style: styles.mlSumNum, key: "n" }, `${totalPresent}/${totalSwimmers}`), h("div", { style: styles.mlSumLbl, key: "l" }, "Here now")])
    ]),
    closed && h("div", { style: styles.mlClosed, key: "cl" }, [h(Coffee, { size: 16, key: "i" }), " The pool is closed on this day \u2014 enjoy the day off."]),
    myPending > 0 && h("button", { style: styles.mlReqBanner, key: "rb", onClick: onOpenRequests }, [
      h(ArrowRightLeft, { size: 15, key: "i" }),
      h("span", { key: "t", style: { flex: 1 } }, `${myPending} request${myPending === 1 ? "" : "s"} waiting for admin approval`),
      h(ChevronRight, { size: 16, key: "c" })
    ]),
    onDutyFree && h("button", { style: styles.mlDutyCard, key: "duty", onClick: onOpenFree }, [
      h(LifeBuoy, { size: 18, key: "i" }),
      h("div", { key: "t", style: { flex: 1, textAlign: "left" } }, [
        h("strong", { key: "s" }, "You're on free-swim duty"),
        h("div", { style: { fontSize: 12.5, opacity: 0.9 }, key: "d" }, myShifts.stations.length ? `2:00\u20133:25pm \u2014 ${myShifts.stations.join(", ")}` : "2:00\u20133:25pm \u2014 tap for your rotation"),
        myShifts.stations.length > 0 && h("div", { style: styles.mlDutyStations, key: "st" }, myShifts.stations.map((st, i) => h("span", { style: styles.mlDutyStationTag, key: i }, st)))
      ]),
      h(ChevronRight, { size: 18, key: "c" })
    ]),
    myKeys.length > 0 ? h("div", { style: styles.mlList, key: "list" }, cards) : h("div", { style: styles.mlEmpty, key: "empty" }, [
      h(Waves, { size: 28, key: "i", style: { color: "var(--faint,#9DB4BF)" } }),
      h("p", { style: styles.mlEmptyTitle, key: "t" }, "No lessons assigned"),
      h("p", { style: styles.mlEmptySub, key: "s" }, "When the owner adds your name to a lesson it'll appear here. Want a class? Request to pick one up below.")
    ]),
    h("button", { style: styles.mlPickupBtn, key: "pickup", onClick: () => setPicker({ kind: "pickup" }) }, [h(Plus, { size: 16, key: "i" }), " Request to pick up a lesson"]),
    picker && h(ShiftRequestModal, {
      mode: picker,
      onClose: () => setPicker(null),
      onSubmit: (t, l, reason) => {
        if (picker.kind === "pickup") onRequestPickup(t, l, reason);
        else onRequestDrop(t, l, reason);
        setPicker(null);
      }
    })
  ]);
}
function ShiftRequestModal({ mode, onClose, onSubmit }) {
  const isDrop = mode.kind === "drop";
  const [time, setTime] = useState(isDrop ? mode.t : TIME_SLOTS[0]);
  const [level, setLevel] = useState(isDrop ? mode.l : null);
  const [reason, setReason] = useState("");
  const canSend = !!time && !!level;
  return h(Modal, { onClose, labelledBy: "shiftReqTitle" }, [
    h("div", { style: styles.modalHead, key: "h" }, [
      h("div", { key: "t" }, [
        h("div", { style: styles.kicker, key: "k" }, "Request"),
        h("h2", { id: "shiftReqTitle", style: styles.modalTitle, key: "ti" }, isDrop ? "Request to drop a lesson" : "Request to pick up a lesson")
      ]),
      h("button", { style: styles.iconBtn, onClick: onClose, key: "x", "aria-label": "Close" }, h(X, { size: 18 }))
    ]),
    h("div", { style: styles.settingsBody, key: "b" }, [
      h("p", { style: styles.settingsText, key: "p" }, isDrop ? "This asks the owner to take you off this lesson. They'll review before anything changes." : "Pick the time and level you'd like to take on. The owner approves before you're added."),
      isDrop ? h("div", { style: styles.mlDropInfo, key: "info" }, [
        h("span", { style: { ...styles.mlLevelBadge, background: levelColor(mode.l) || legibleColor("#1D7A8C") }, key: "lv" }, mode.l),
        h("span", { key: "t", style: { fontWeight: 700 } }, mode.t)
      ]) : h(Fragment, { key: "pick" }, [
        h("label", { style: styles.fieldLabel, key: "lt" }, "Time"),
        h("div", { style: styles.moveRow, key: "times" }, TIME_SLOTS.map((t) => h("button", { key: t, style: { ...styles.moveChip, ...time === t ? styles.moveChipOn : {} }, onClick: () => setTime(t) }, t))),
        h("label", { style: { ...styles.fieldLabel, marginTop: 8 }, key: "ll" }, "Level"),
        h("div", { style: styles.moveLevels, key: "levels" }, LEVELS.map((l) => h("button", {
          key: l,
          style: { ...styles.moveLevelBtn, ...level === l ? styles.moveLevelPicked : {}, borderColor: levelColor(l) },
          onClick: () => setLevel(l)
        }, [h("span", { style: { ...styles.moveDot, background: levelColor(l) }, key: "d" }), l, level === l && h(Check, { size: 14, key: "c", style: { marginLeft: "auto", color: legibleColor("#1D7A8C") } })])))
      ]),
      h("label", { style: { ...styles.fieldLabel, marginTop: 8 }, key: "lr" }, "Note (optional)"),
      h("textarea", { key: "rea", style: styles.reqReasonInput, value: reason, rows: 2, placeholder: isDrop ? "Why you need to drop it\u2026" : "Anything the owner should know\u2026", onChange: (e) => setReason(e.target.value) })
    ]),
    h("div", { style: styles.modalFoot, key: "f" }, [
      h("button", { style: styles.ghostBtn, onClick: onClose, key: "c" }, "Cancel"),
      h("button", { style: { ...styles.primaryBtn, ...canSend ? {} : { background: "var(--surface-3,#EAF1F2)", color: "var(--faint,#9DB4BF)", cursor: "default" } }, disabled: !canSend, onClick: () => canSend && onSubmit(time, level, reason), key: "s" }, [h(ArrowRightLeft, { size: 16, key: "i" }), isDrop ? " Send drop request" : " Send pick-up request"])
    ])
  ]);
}
var styles = {
  // Safe-area aware: bottom padding clears the iPhone home indicator when the
  // app runs standalone (viewport-fit=cover exposes the inset variables).
  page: { minHeight: "100vh", background: "var(--page-bg)", fontFamily: "'Hanken Grotesk', system-ui, -apple-system, sans-serif", color: "var(--text,#0A2233)", paddingBottom: "calc(60px + env(safe-area-inset-bottom))" },
  gateScene: { position: "relative", minHeight: "100vh", overflow: "hidden", isolation: "isolate", background: "linear-gradient(165deg, #06283A 0%, #0B3C5D 38%, #11697A 78%, #1D7A8C 100%)", fontFamily: "'Hanken Grotesk', system-ui, -apple-system, sans-serif" },
  gateBgOrb1: { position: "absolute", top: "-14%", left: "-10%", width: 460, height: 460, borderRadius: "50%", background: "radial-gradient(circle at 38% 36%, rgba(255,222,150,.62), rgba(232,162,60,.20) 48%, transparent 70%)", filter: "blur(46px)", pointerEvents: "none", zIndex: 0 },
  gateBgOrb2: { position: "absolute", bottom: "-18%", right: "-12%", width: 520, height: 520, borderRadius: "50%", background: "radial-gradient(circle at 50% 50%, rgba(86,228,213,.42), rgba(45,212,191,.16) 50%, transparent 72%)", filter: "blur(54px)", pointerEvents: "none", zIndex: 0 },
  gateRipple: { position: "absolute", bottom: "12%", left: "50%", width: 760, height: 200, transform: "translateX(-50%)", background: "repeating-linear-gradient(180deg, transparent 0 16px, rgba(180,236,238,.06) 16px 17px)", maskImage: "radial-gradient(ellipse 60% 100% at 50% 100%, #000 30%, transparent 75%)", WebkitMaskImage: "radial-gradient(ellipse 60% 100% at 50% 100%, #000 30%, transparent 75%)", pointerEvents: "none", zIndex: 0 },
  gateGrain: { position: "absolute", inset: 0, pointerEvents: "none", zIndex: 0, opacity: 0.5, mixBlendMode: "overlay", backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E\")" },
  gateWrap: { position: "relative", zIndex: 1, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 14, padding: 24 },
  gateCard: { position: "relative", zIndex: 1, width: "100%", maxWidth: 392, background: "rgba(255,255,255,.10)", backdropFilter: "blur(22px) saturate(140%)", WebkitBackdropFilter: "blur(22px) saturate(140%)", border: "1px solid rgba(255,255,255,.22)", borderTop: "1px solid rgba(255,255,255,.45)", borderRadius: 24, padding: "34px 28px 28px", boxShadow: "0 24px 70px rgba(4,22,34,.55), inset 0 1px 0 rgba(255,255,255,.25)", textAlign: "center", overflow: "hidden" },
  gateWave: { position: "absolute", top: 0, left: 0, right: 0, height: 6, background: "linear-gradient(90deg, #0B3C5D, #2DD4BF)" },
  gateTitle: { fontSize: 30, fontWeight: 800, color: "#FBFEFE", margin: "2px 0 0", letterSpacing: -0.7, lineHeight: 1.05, fontFamily: "var(--display)", textShadow: "0 2px 18px rgba(4,22,34,.45)" },
  gateUnderline: { width: 54, height: 3, borderRadius: 3, margin: "12px auto 0", background: "linear-gradient(90deg, var(--accent-gold), #F6C56B)", boxShadow: "0 0 12px rgba(232,162,60,.6)" },
  gateSub: { fontSize: 14.5, color: "rgba(233,243,244,.82)", margin: "14px 0 20px", lineHeight: 1.5 },
  gateBtn: { display: "flex", alignItems: "center", justifyContent: "center", gap: 7, width: "100%", marginTop: 14, background: "linear-gradient(180deg, #EFB055 0%, #E8A23C 100%)", color: "#3A2206", border: "none", borderRadius: 13, padding: "14px", fontSize: 15.5, fontWeight: 800, cursor: "pointer", fontFamily: "var(--display)", letterSpacing: 0.2, boxShadow: "0 8px 22px rgba(232,162,60,.34)" },
  // Safe-area aware: the dark band extends under the notch/status bar instead
  // of leaving content pinched behind it (viewport-fit=cover is already set).
  header: { background: "var(--hd-bg,#0B3C5D)", color: "#fff", padding: "0 16px", paddingTop: "env(safe-area-inset-top)", paddingLeft: "max(16px, env(safe-area-inset-left))", paddingRight: "max(16px, env(safe-area-inset-right))" },
  headerInner: { maxWidth: "var(--maxw)", margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, padding: "16px 0", flexWrap: "wrap" },
  brand: { display: "flex", alignItems: "center", gap: 12 },
  wave: { width: 38, height: 38, borderRadius: 11, flexShrink: 0, background: "radial-gradient(circle at 30% 30%, #2DD4BF, #1D7A8C 70%)", boxShadow: "inset 0 -6px 10px rgba(11,60,93,.4)" },
  // Kicker ink must read on WHITE modal surfaces (6.67:1); the navy-header
  // instance overrides its own color inline, so it keeps its light tint.
  kicker: { fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--muted,#46606C)", fontWeight: 600, fontFamily: "var(--display)" },
  h1: { margin: 0, fontSize: 22, fontWeight: 800, letterSpacing: -0.3, fontFamily: "var(--display)" },
  headerClock: { display: "flex", alignItems: "center", gap: 6, marginTop: 3, fontSize: 13, fontWeight: 700, color: "#8FC9CE", fontVariantNumeric: "tabular-nums", letterSpacing: 0.3 },
  clockDot: { width: 6, height: 6, borderRadius: "50%", background: "#2DD4BF", flexShrink: 0, boxShadow: "0 0 0 3px rgba(45,212,191,.25)" },
  headerActions: { display: "flex", alignItems: "center", gap: 8, rowGap: 6, flexWrap: "wrap", justifyContent: "flex-end" },
  gearBtn: { display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(255,255,255,.12)", color: "#fff", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer" },
  addSwimmerBtn: { display: "flex", alignItems: "center", gap: 6, width: "100%", justifyContent: "center", marginTop: 8, border: "1.5px dashed var(--faint,#B9CDD3)", background: "transparent", color: "var(--muted,#5B7A88)", fontSize: 13.5, fontWeight: 700, padding: "10px", borderRadius: 10, cursor: "pointer", fontFamily: "inherit" },
  addForm: { marginTop: 8, background: "var(--surface-3,#F7FAFA)", border: "1px solid var(--border-soft,#E3EBEC)", borderRadius: 12, padding: 12, display: "flex", flexDirection: "column", gap: 8 },
  editRow: { background: "var(--surface-3,#F7FAFA)", border: "1.5px solid #2DD4BF", borderRadius: 12, padding: 12, display: "flex", flexDirection: "column", gap: 8, marginBottom: 8 },
  addInput: { flex: 1, border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 9, padding: "10px 11px", fontSize: 14.5, fontFamily: "inherit", minWidth: 0, boxSizing: "border-box", background: "var(--surface)", color: "var(--text)" },
  addRow: { display: "flex", gap: 8 },
  addBtns: { display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 2 },
  addCancel: { border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--muted,#5B7A88)", borderRadius: 9, padding: "8px 14px", fontSize: 13.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  addSave: { display: "flex", alignItems: "center", gap: 6, color: "#fff", border: "none", borderRadius: 9, padding: "8px 14px", fontSize: 13.5, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" },
  unlockedBtn: { display: "flex", alignItems: "center", gap: 5, background: "#2DD4BF", color: "#06283A", border: "none", borderRadius: 10, padding: "9px 12px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap" },
  pwDivider: { height: 1, background: "var(--border-soft,#F0F0EC)", margin: "12px 0 4px" },
  settingsBody: { padding: "0 18px 4px", display: "flex", flexDirection: "column", gap: 8 },
  installBtn: { display: "flex", alignItems: "center", gap: 12, width: "100%", textAlign: "left", background: "var(--surface-3,#F7FAFA)", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 14, padding: "12px 14px", cursor: "pointer", fontFamily: "inherit", color: "var(--text,#0A2233)" },
  installBtnDone: { borderColor: "#2DD4BF", background: "rgba(45,212,191,.12)" },
  installIconWrap: { display: "flex", alignItems: "center", justifyContent: "center", width: 38, height: 38, borderRadius: 11, background: "#0B3C5D", color: "#fff", flexShrink: 0 },
  installTextWrap: { display: "flex", flexDirection: "column", gap: 2, flex: 1, minWidth: 0 },
  installTitle: { fontSize: 14.5, fontWeight: 800, color: "var(--heading)" },
  installSub: { fontSize: 12.5, color: "var(--muted,#5B7A88)", lineHeight: 1.35 },
  installSteps: { margin: "2px 0 4px", paddingLeft: 20, display: "flex", flexDirection: "column", gap: 8, fontSize: 13.5, color: "var(--text,#0A2233)", lineHeight: 1.5 },
  settingsText: { fontSize: 13.5, color: "var(--muted,#5B7A88)", lineHeight: 1.5, margin: "0 0 4px" },
  fieldLabel: { fontSize: 11, textTransform: "uppercase", letterSpacing: 1, color: "var(--muted,#5B7A88)", fontWeight: 700, marginTop: 4 },
  keyInput: { border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 10, padding: "11px 12px", fontSize: 14, fontFamily: "inherit", minWidth: 0, width: "100%", boxSizing: "border-box", background: "var(--surface)", color: "var(--text)" },
  testOk: { fontSize: 13, color: "#19B6A0", fontWeight: 600, background: "rgba(45,212,191,.16)", borderRadius: 8, padding: "8px 12px" },
  testFail: { fontSize: 12.5, color: "#E2725B", fontWeight: 500, background: "rgba(178,58,44,.16)", borderRadius: 8, padding: "8px 12px", wordBreak: "break-word" },
  syncBadge: { display: "flex", alignItems: "center", gap: 5, fontSize: 12.5, fontWeight: 600, whiteSpace: "nowrap" },
  rail: { maxWidth: "var(--maxw)", margin: "18px auto 0", padding: "0 16px", display: "flex", gap: 8, overflowX: "auto", alignItems: "center" },
  railDivider: { width: 1, height: 28, background: "var(--border,#DCE6E8)", flexShrink: 0, margin: "0 2px" },
  slot: { display: "flex", alignItems: "center", gap: 7, background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 12, padding: "9px 13px", cursor: "pointer", fontFamily: "inherit", flexShrink: 0, transition: "all .15s" },
  slotActive: { background: "#0B3C5D", borderColor: "#0B3C5D", color: "#fff" },
  slotTime: { fontWeight: 700, fontSize: 14.5 },
  slotCount: { fontSize: 12, fontWeight: 700, background: "var(--surface-2,#EAF1F2)", color: "var(--muted,#5B7A88)", borderRadius: 20, padding: "1px 8px", minWidth: 22, textAlign: "center" },
  slotCountActive: { background: "#2DD4BF", color: "#06283A" },
  dateWrap: { maxWidth: "var(--maxw)", margin: "12px auto 0", padding: "0 16px", display: "flex", flexDirection: "column", gap: 8 },
  weekRow: { display: "flex", alignItems: "center", gap: 8 },
  weekMid: { flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 11, padding: "9px 12px", minWidth: 0 },
  weekLabel: { fontSize: 14.5, fontWeight: 800, color: "var(--heading)", whiteSpace: "nowrap" },
  dayPicker: { display: "flex", gap: 6 },
  dayChip: { flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2, position: "relative", background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 11, padding: "8px 4px", cursor: "pointer", fontFamily: "inherit", color: "var(--heading)" },
  dayChipSel: { background: "#0B3C5D", borderColor: "#0B3C5D", color: "#fff" },
  dayChipClosed: { background: "var(--surface-3,#F7F7F7)", color: "var(--faint)", borderStyle: "dashed" },
  dayChipDow: { fontSize: 11, fontWeight: 700, opacity: 0.8 },
  dayChipNum: { fontSize: 16, fontWeight: 800, lineHeight: 1 },
  dayChipDot: { width: 5, height: 5, borderRadius: "50%", position: "absolute", bottom: 4 },
  dateNav: { display: "flex", alignItems: "center", justifyContent: "center", width: 38, height: 38, borderRadius: 11, border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--teal-ink,#1D7A8C)", cursor: "pointer", flex: "0 0 auto" },
  todayTag: { fontSize: 11, fontWeight: 800, color: "#19B6A0", background: "rgba(14,124,102,.18)", borderRadius: 999, padding: "2px 8px" },
  todayBtn: { flex: "0 0 auto", border: "1.5px solid #2DD4BF", background: "var(--surface)", color: "#0E7C66", fontWeight: 800, fontSize: 13, borderRadius: 11, padding: "9px 12px", cursor: "pointer", fontFamily: "inherit" },
  closedWrap: { maxWidth: 520, margin: "40px auto", padding: "36px 24px", textAlign: "center", background: "var(--surface)", border: "1.5px solid rgba(210,74,57,.3)", borderRadius: 18 },
  closedIcon: { width: 60, height: 60, borderRadius: "50%", background: "rgba(210,74,57,.14)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" },
  closedTitle: { fontSize: 19, fontWeight: 800, color: "var(--heading)", margin: "0 0 6px" },
  closedSub: { fontSize: 14.5, color: "var(--muted,#5B7A88)", margin: "0 0 10px" },
  closedHint: { fontSize: 13, color: "var(--muted,#5B7A88)", margin: 0 },
  searchWrap: { maxWidth: "var(--maxw)", margin: "16px auto 0", padding: "0 16px", display: "flex", alignItems: "center", gap: 10, background: "var(--surface)", borderRadius: 12, border: "1.5px solid var(--border,#DCE6E8)" },
  toolbar: { maxWidth: "var(--maxw)", margin: "14px auto 0", padding: "0 16px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" },
  toolbarLabel: { fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "var(--muted,#5B7A88)", fontWeight: 700 },
  toolbarBtns: { display: "flex", gap: 8 },
  toolBtn: { display: "flex", alignItems: "center", gap: 6, background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", color: "var(--heading)", borderRadius: 9, padding: "7px 12px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  movePop: { marginTop: 8, background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 12, padding: 10, boxShadow: "0 8px 24px rgba(11,60,93,.16)", maxWidth: 300 },
  moveHead: { display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 11, textTransform: "uppercase", letterSpacing: 1, color: "var(--muted,#5B7A88)", fontWeight: 700, marginBottom: 8 },
  // padding 10 / margin -8 grows the tap target to ~33px without moving pixels —
  // mis-taps on this X were landing on the level buttons underneath.
  moveClose: { border: "none", background: "transparent", color: "var(--faint,#9DB4BF)", cursor: "pointer", padding: 10, margin: -8, borderRadius: 8, display: "flex" },
  addClassWrap: { marginTop: 4 },
  addClassBtn: { display: "flex", alignItems: "center", justifyContent: "center", gap: 6, width: "100%", border: "1.5px dashed var(--faint,#B9CDD3)", background: "var(--surface)", color: "var(--teal-ink,#1D7A8C)", fontSize: 14, fontWeight: 800, padding: "13px", borderRadius: 14, cursor: "pointer", fontFamily: "inherit" },
  addClassPanel: { background: "var(--surface)", border: "1px solid var(--border-soft,#E3EBEC)", borderRadius: 14, padding: 14, boxShadow: "0 2px 10px rgba(11,60,93,.05)" },
  addClassHead: { display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 13.5, fontWeight: 800, color: "var(--heading)", marginBottom: 10 },
  addClassLevels: { display: "flex", flexWrap: "wrap", gap: 8 },
  addClassLevel: { display: "flex", alignItems: "center", gap: 7, border: "1.5px solid", background: "var(--surface)", color: "var(--text)", borderRadius: 10, padding: "9px 13px", fontSize: 13.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  moveRow: { display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 8 },
  moveChip: { border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--muted,#5B7A88)", borderRadius: 8, padding: "4px 10px", fontSize: 12.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  moveChipOn: { background: "#0B3C5D", borderColor: "#0B3C5D", color: "#fff" },
  moveLevels: { display: "flex", flexDirection: "column", gap: 4 },
  moveLevelBtn: { display: "flex", alignItems: "center", gap: 8, border: "1.5px solid", background: "var(--surface)", borderRadius: 8, padding: "8px 10px", fontSize: 13.5, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", color: "var(--text,#0A2233)", textAlign: "left" },
  moveLevelCurrent: { opacity: 0.5, cursor: "default", background: "var(--surface-3,#F4EFE6)" },
  moveDot: { width: 9, height: 9, borderRadius: "50%", flexShrink: 0 },
  moveHere: { marginLeft: "auto", fontSize: 11, color: "var(--muted,#5B7A88)", fontWeight: 600 },
  moveLevelPicked: { background: "var(--surface-2,#EAF1F2)", boxShadow: "inset 0 0 0 1.5px #1D7A8C" },
  reqPickSub: { fontSize: 12, color: "var(--muted,#5B7A88)", lineHeight: 1.45, margin: "2px 0 8px" },
  reqReasonInput: { width: "100%", boxSizing: "border-box", marginTop: 8, border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 8, padding: "8px 10px", fontSize: 13, fontFamily: "inherit", resize: "vertical", background: "var(--surface)", color: "var(--text,#0A2233)" },
  reqSendBtn: { width: "100%", marginTop: 8, display: "flex", alignItems: "center", justifyContent: "center", gap: 7, background: "#0B3C5D", color: "#fff", border: "none", borderRadius: 9, padding: "10px 12px", fontWeight: 700, fontSize: 13.5, cursor: "pointer", fontFamily: "inherit" },
  reqSendBtnOff: { background: "var(--surface-3,#EAF1F2)", color: "var(--faint,#9DB4BF)", cursor: "default" },
  instNone: { fontSize: 13, color: "var(--faint,#9DB4BF)", fontWeight: 600 },
  pendingTag: { display: "inline-flex", alignItems: "center", gap: 4, marginTop: 4, fontSize: 11, fontWeight: 700, color: "var(--ink-wait,#5B4B9E)", background: "rgba(124,92,255,.16)", border: "1px solid rgba(124,92,255,.35)", borderRadius: 999, padding: "2px 9px" },
  reqBadge: { position: "absolute", top: -5, right: -5, minWidth: 18, height: 18, padding: "0 5px", boxSizing: "border-box", background: "#C93A26", color: "#fff", fontSize: 11, fontWeight: 800, borderRadius: 999, display: "flex", alignItems: "center", justifyContent: "center", lineHeight: 1, boxShadow: "0 0 0 2px var(--hd-bg,#0B3C5D)" },
  instructorBtn: { display: "flex", alignItems: "center", gap: 5, background: "rgba(45,212,191,.18)", color: "#BFF3EC", border: "1px solid rgba(45,212,191,.4)", borderRadius: 10, padding: "9px 12px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap" },
  reqSectionLbl: { fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.6, color: "var(--muted,#5B7A88)", margin: "4px 0 2px" },
  reqEmpty: { fontSize: 13.5, color: "var(--faint,#9DB4BF)", fontStyle: "italic", padding: "6px 0" },
  reqCard: { display: "flex", flexDirection: "column", gap: 7, background: "var(--surface-3,#FAFCFC)", border: "1px solid var(--border-soft,#ECF1F2)", borderRadius: 12, padding: "11px 13px" },
  reqTop: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 },
  reqName: { fontSize: 15, fontWeight: 800, color: "var(--heading)" },
  reqMove: { display: "flex", alignItems: "center", gap: 7, fontSize: 13.5, fontWeight: 700, color: "var(--text,#0A2233)" },
  reqBy: { display: "flex", alignItems: "center", gap: 5, fontSize: 12.5, color: "var(--muted,#5B7A88)", fontWeight: 600 },
  reqReason: { fontSize: 12.5, color: "var(--muted,#5B7A88)", fontStyle: "italic", lineHeight: 1.45 },
  reqActions: { display: "flex", gap: 8, marginTop: 2 },
  reqApprove: { flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, background: "#0E9F8E", color: "#fff", border: "none", borderRadius: 9, padding: "9px 12px", fontWeight: 700, fontSize: 13.5, cursor: "pointer", fontFamily: "inherit" },
  reqReject: { display: "flex", alignItems: "center", justifyContent: "center", gap: 6, background: "var(--surface)", color: "#D24A39", border: "1.5px solid #FFD9D0", borderRadius: 9, padding: "9px 14px", fontWeight: 700, fontSize: 13.5, cursor: "pointer", fontFamily: "inherit" },
  reqStatus: { display: "inline-flex", alignItems: "center", gap: 4, fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, borderRadius: 999, padding: "3px 9px", flexShrink: 0 },
  reqStatusOk: { background: "rgba(11,122,102,.18)", color: "var(--ink-ok,#0B6B5C)" },
  reqStatusNo: { background: "rgba(178,58,44,.18)", color: "var(--ink-no,#9E3023)" },
  reqStatusWait: { background: "rgba(124,92,255,.2)", color: "var(--ink-wait,#5B4B9E)" },
  reqTopLeft: { display: "flex", alignItems: "center", gap: 8, minWidth: 0, flexWrap: "wrap" },
  reqKind: { display: "inline-flex", alignItems: "center", fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, borderRadius: 999, padding: "3px 9px", flexShrink: 0 },
  reqKindSwitch: { background: "rgba(29,122,140,.16)", color: "var(--heading)" },
  reqKindPickup: { background: "rgba(14,159,142,.16)", color: "var(--ink-ok,#0B6B5C)" },
  reqKindDrop: { background: "rgba(210,74,57,.16)", color: "var(--ink-no,#9E3023)" },
  reqKindTime: { background: "rgba(200,146,58,.18)", color: "var(--ink-time,#8A6320)" },
  slotMine: { background: "linear-gradient(135deg, #0B3C5D 0%, #1D7A8C 100%)", borderColor: "transparent", color: "#fff" },
  slotMineActive: { boxShadow: "0 0 0 2.5px #2DD4BF", borderColor: "transparent" },
  acctAvatar: { width: 34, height: 34, borderRadius: "50%", background: "linear-gradient(135deg, #0B3C5D 0%, #6D54E0 100%)", color: "#fff", fontSize: 15, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  acctAddCard: { background: "var(--surface-3,#F7FAFA)", border: "1px solid var(--border-soft,#E3EBEC)", borderRadius: 14, padding: 12, display: "flex", flexDirection: "column", gap: 8, marginBottom: 4 },
  acctAddBtn: { display: "flex", alignItems: "center", justifyContent: "center", gap: 7, background: "#0B3C5D", color: "#fff", border: "none", borderRadius: 10, padding: "10px 14px", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" },
  acctCard: { background: "var(--surface)", border: "1px solid var(--border-soft,#ECF1F2)", borderRadius: 14, padding: "12px 13px", display: "flex", flexDirection: "column", gap: 10, boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  acctCardTop: { display: "flex", alignItems: "center", gap: 10 },
  acctName: { display: "flex", alignItems: "center", gap: 8, fontSize: 15.5, fontWeight: 800, color: "var(--heading)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  acctOff: { fontSize: 10.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "#C8923A", background: "rgba(200,146,58,.16)", borderRadius: 999, padding: "2px 8px" },
  acctAdmin: { fontSize: 10.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "#fff", background: "linear-gradient(135deg, #0B3C5D 0%, #6D54E0 100%)", borderRadius: 999, padding: "2px 8px" },
  roleToggle: { display: "flex", gap: 8, marginTop: 8 },
  roleOpt: { flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 5, padding: "10px", borderRadius: 10, border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--muted,#5B7A88)", fontSize: 13.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  roleOptSel: { borderColor: "#1D7A8C", background: "rgba(29,122,140,.16)", color: "var(--heading)", borderWidth: 2 },
  roleOptSelAdmin: { borderColor: "#6D54E0", background: "rgba(124,92,255,.16)", color: "#A99AFF", borderWidth: 2 },
  roleWarn: { fontSize: 12.5, fontWeight: 600, color: "#A99AFF", background: "rgba(124,92,255,.14)", border: "1px solid rgba(124,92,255,.32)", borderRadius: 10, padding: "9px 12px", marginTop: 8, lineHeight: 1.4 },
  ambWarn: { background: "rgba(200,146,58,.14)", border: "1px solid rgba(200,146,58,.4)", borderRadius: 12, padding: "11px 13px", margin: "0 0 10px", display: "flex", flexDirection: "column", gap: 6 },
  ambWarnHead: { display: "flex", alignItems: "center", gap: 6, fontSize: 13, fontWeight: 800, color: "#C8923A" },
  ambWarnRow: { fontSize: 12.5, fontWeight: 600, color: "var(--muted)", lineHeight: 1.45 },
  acctMeta: { fontSize: 12.5, color: "var(--muted,#5B7A88)", fontWeight: 600, marginTop: 1 },
  acctLinks: { display: "flex", flexWrap: "wrap", gap: 6 },
  acctLinkChip: { display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 700, color: "var(--text,#0A2233)", background: "var(--surface-3,#FAFCFC)", border: "1px solid", borderRadius: 999, padding: "3px 10px" },
  acctLinkDot: { width: 8, height: 8, borderRadius: "50%", flexShrink: 0 },
  acctActions: { display: "flex", alignItems: "center", gap: 8 },
  acctToggleBtn: { border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--muted,#5B7A88)", borderRadius: 9, padding: "7px 12px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  acctEditBtn: { display: "flex", alignItems: "center", gap: 5, border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--teal-ink,#1D7A8C)", borderRadius: 9, padding: "7px 12px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  acctDelBtn: { display: "flex", alignItems: "center", gap: 5, border: "none", background: "rgba(178,58,44,.16)", color: "#E2725B", borderRadius: 9, padding: "8px 14px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  acctEditHint: { fontSize: 12, color: "var(--muted,#5B7A88)", fontWeight: 600 },
  acctConfirm: { display: "flex", flexDirection: "column", gap: 8, background: "rgba(210,74,57,.14)", border: "1px solid rgba(210,74,57,.32)", borderRadius: 10, padding: "10px 12px" },
  acctConfirmTxt: { fontSize: 13, fontWeight: 600, color: "#E2725B" },
  mlWrap: { maxWidth: "var(--maxw)", margin: "16px auto 0", padding: "0 16px", display: "flex", flexDirection: "column", gap: 14 },
  mlHero: { display: "flex", alignItems: "center", gap: 12, background: "linear-gradient(135deg, #0B3C5D 0%, #6D54E0 100%)", borderRadius: 18, padding: "18px 20px", color: "#fff", boxShadow: "0 8px 24px rgba(11,60,93,.16)" },
  mlHeroText: { flex: 1, minWidth: 0 },
  mlHi: { fontSize: 21, fontWeight: 800, letterSpacing: -0.3 },
  mlHeroDate: { fontSize: 11.5, fontWeight: 700, letterSpacing: 0.8, textTransform: "uppercase", color: "rgba(255,255,255,.72)", marginBottom: 3 },
  mlHeroSub: { fontSize: 13.5, fontWeight: 500, opacity: 0.92, marginTop: 2, lineHeight: 1.4 },
  mlSummary: { display: "flex", alignItems: "center", justifyContent: "space-around", background: "var(--surface)", borderRadius: 16, padding: "14px 12px", boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  mlSumItem: { display: "flex", flexDirection: "column", alignItems: "center", gap: 2, minWidth: 0 },
  mlSumNum: { fontSize: 21, fontWeight: 800, color: "var(--heading)", letterSpacing: -0.4, fontVariantNumeric: "tabular-nums" },
  mlSumLbl: { fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.4, color: "var(--muted,#5B7A88)" },
  mlSumDiv: { width: 1, alignSelf: "stretch", background: "var(--border-soft,#ECF1F2)", margin: "2px 0" },
  mlClosed: { display: "flex", alignItems: "center", gap: 8, background: "rgba(200,146,58,.14)", border: "1px solid rgba(200,146,58,.35)", color: "#C8923A", fontSize: 13.5, fontWeight: 600, borderRadius: 12, padding: "11px 14px" },
  mlReqBanner: { display: "flex", alignItems: "center", gap: 10, background: "rgba(124,92,255,.14)", border: "1px solid rgba(124,92,255,.32)", color: "#A99AFF", fontSize: 13.5, fontWeight: 700, borderRadius: 12, padding: "11px 14px", cursor: "pointer", fontFamily: "inherit", textAlign: "left", width: "100%" },
  mlDutyCard: { display: "flex", alignItems: "center", gap: 10, background: "linear-gradient(135deg, #7C5CFF 0%, #5B4B9E 100%)", border: "none", color: "#fff", borderRadius: 14, padding: "13px 15px", cursor: "pointer", fontFamily: "inherit", width: "100%", boxShadow: "0 6px 16px rgba(124,92,255,.28)" },
  mlList: { display: "flex", flexDirection: "column", gap: 10 },
  mlCard: { display: "flex", alignItems: "stretch", background: "var(--surface)", borderRadius: 14, overflow: "hidden", boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  mlCardMain: { flex: 1, display: "flex", alignItems: "stretch", gap: 0, background: "transparent", border: "none", cursor: "pointer", fontFamily: "inherit", padding: 0, minWidth: 0, textAlign: "left" },
  mlBar: { width: 5, flexShrink: 0 },
  mlCardBody: { flex: 1, display: "flex", flexDirection: "column", gap: 5, padding: "12px 14px", minWidth: 0 },
  mlCardTop: { display: "flex", alignItems: "center", gap: 8 },
  mlLevelBadge: { fontSize: 12.5, fontWeight: 800, color: "#fff", borderRadius: 7, padding: "3px 10px", whiteSpace: "nowrap" },
  mlTime: { fontSize: 14, fontWeight: 800, color: "var(--heading)" },
  mlStat: { display: "flex", alignItems: "center", gap: 6, fontSize: 13.5, fontWeight: 600, color: "var(--muted,#5B7A88)" },
  mlCo: { fontSize: 12.5, color: "var(--faint,#9DB4BF)", fontWeight: 600 },
  mlProgTrack: { height: 6, borderRadius: 999, background: "var(--surface-2,#EAF1F2)", overflow: "hidden", marginTop: 2 },
  mlProgFill: { height: "100%", borderRadius: 999, transition: "width .3s ease" },
  mlDutyStations: { display: "flex", flexWrap: "wrap", gap: 5, marginTop: 6 },
  mlDutyStationTag: { fontSize: 11, fontWeight: 700, color: "#fff", background: "rgba(255,255,255,.20)", border: "1px solid rgba(255,255,255,.28)", borderRadius: 999, padding: "2px 9px" },
  mlDropBtn: { flexShrink: 0, border: "none", borderLeft: "1px solid var(--border-soft,#ECF1F2)", background: "var(--surface)", color: "#D24A39", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", padding: "0 14px", writingMode: "horizontal-tb" },
  mlDropInfo: { display: "flex", alignItems: "center", gap: 8, background: "var(--surface-3,#FAFCFC)", border: "1px solid var(--border-soft,#ECF1F2)", borderRadius: 10, padding: "10px 12px" },
  mlPickupBtn: { display: "flex", alignItems: "center", justifyContent: "center", gap: 6, width: "100%", border: "1.5px dashed var(--faint,#B9CDD3)", background: "var(--surface)", color: "var(--teal-ink,#1D7A8C)", fontSize: 14, fontWeight: 800, padding: "13px", borderRadius: 14, cursor: "pointer", fontFamily: "inherit" },
  mlEmpty: { display: "flex", flexDirection: "column", alignItems: "center", gap: 8, textAlign: "center", background: "var(--surface)", borderRadius: 16, padding: "32px 20px", boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  mlEmptyTitle: { fontSize: 16, fontWeight: 800, color: "var(--heading)", margin: 0 },
  mlEmptySub: { fontSize: 13.5, color: "var(--muted,#5B7A88)", margin: 0, lineHeight: 1.5, maxWidth: 300 },
  search: { flex: 1, border: "none", padding: "12px 0", fontSize: 15, fontFamily: "inherit", background: "transparent", color: "var(--text)" },
  clearSearch: { border: "none", background: "transparent", color: "var(--muted,#5B7A88)", cursor: "pointer", padding: 6, display: "flex" },
  main: { maxWidth: "var(--maxw)", margin: "18px auto 0", padding: "0 16px", display: "flex", flexDirection: "column", gap: 18 },
  statBand: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12 },
  stat: { background: "var(--surface)", borderRadius: 16, padding: "16px 14px", textAlign: "center", border: "1px solid var(--border-soft,#E6EEF0)", boxShadow: "0 1px 3px rgba(11,60,93,.06)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 78 },
  statValue: { fontSize: 24, fontWeight: 800, color: "var(--heading)", lineHeight: 1.05, letterSpacing: -0.5 },
  statLabel: { fontSize: 10.5, color: "var(--muted,#5B7A88)", fontWeight: 700, marginTop: 6, textTransform: "uppercase", letterSpacing: 0.6, lineHeight: 1.2 },
  attWrap: { background: "var(--surface)", borderRadius: 12, padding: "12px 14px", display: "flex", alignItems: "center", gap: 12, boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  attTrack: { flex: 1, height: 9, background: "var(--surface-2,#EAF1F2)", borderRadius: 20, overflow: "hidden" },
  attFill: { height: "100%", background: "linear-gradient(90deg, #2DD4BF, #1D7A8C)", borderRadius: 20, transition: "width .4s ease" },
  attText: { fontSize: 12.5, color: "var(--muted,#5B7A88)", fontWeight: 600, whiteSpace: "nowrap" },
  levelDist: { display: "flex", flexWrap: "wrap", gap: 8 },
  distChip: { display: "flex", alignItems: "center", gap: 7, background: "var(--surface)", borderRadius: 999, padding: "6px 13px 6px 11px", fontSize: 13, fontWeight: 600, color: "var(--text,#0A2233)", border: "1px solid var(--border-soft,#E6EEF0)" },
  distDot: { width: 9, height: 9, borderRadius: "50%", flexShrink: 0 },
  distNum: { fontWeight: 800, color: "var(--heading)" },
  searchResults: { display: "flex", flexDirection: "column", gap: 6 },
  resultRow: { display: "flex", alignItems: "center", gap: 10, background: "var(--surface)", border: "none", borderRadius: 10, padding: "11px 14px", cursor: "pointer", fontFamily: "inherit", textAlign: "left", boxShadow: "0 1px 2px rgba(11,60,93,.05)" },
  resultName: { fontWeight: 700, fontSize: 14.5, color: "var(--text,#0A2233)" },
  resultMeta: { marginLeft: "auto", fontSize: 12.5, color: "var(--muted,#5B7A88)", fontWeight: 600 },
  timeRow: { background: "var(--surface)", borderRadius: 14, padding: "12px 14px", boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  timeRowLive: { boxShadow: "0 0 0 2px #7C5CFF", background: "rgba(124,92,255,.08)" },
  timeRowDone: { opacity: 0.55 },
  doneTag: { marginLeft: "auto", fontSize: 11, fontWeight: 800, color: "var(--muted,#5B7A88)", background: "var(--surface-2,#EBF0F1)", borderRadius: 999, padding: "2px 9px" },
  overBanner: { maxWidth: "var(--maxw)", margin: "12px auto 0", padding: "12px 16px", display: "flex", alignItems: "center", gap: 10, background: "var(--surface-2,#EBF0F1)", color: "var(--muted,#3F5560)", borderRadius: 12, fontSize: 14 },
  liveTag: { marginLeft: "auto", fontSize: 11, fontWeight: 800, color: "#fff", background: "#7C5CFF", borderRadius: 999, padding: "2px 9px" },
  freeBanner: { maxWidth: "var(--maxw)", width: "100%", margin: "12px auto 0", padding: "13px 16px", display: "flex", alignItems: "center", gap: 10, background: "#7C5CFF", color: "#fff", border: "none", borderRadius: 12, fontSize: 14, cursor: "pointer", fontFamily: "inherit", textAlign: "left", boxShadow: "0 6px 18px rgba(124,92,255,.28)" },
  timeRowHead: { display: "flex", alignItems: "center", gap: 8, marginBottom: 10 },
  timeRowLabel: { fontWeight: 800, fontSize: 16, color: "var(--heading)" },
  timeRowCount: { marginLeft: "auto", fontSize: 12.5, color: "var(--muted,#5B7A88)", fontWeight: 600 },
  gap: { display: "flex", alignItems: "center", gap: 7, fontSize: 13, color: "#C8923A", background: "rgba(200,146,58,.14)", borderRadius: 9, padding: "9px 12px", fontWeight: 600 },
  classCells: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 10 },
  cell: { background: "var(--surface-3,#FAFCFC)", border: "1px solid var(--border-soft,#ECF1F2)", borderLeft: "3px solid", borderRadius: 12, padding: "11px 13px", cursor: "pointer", fontFamily: "inherit", textAlign: "left", transition: "transform .12s, box-shadow .12s" },
  cellTop: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 },
  cellLevel: { fontWeight: 800, fontSize: 13.5 },
  cellCount: { fontWeight: 800, fontSize: 14, color: "var(--heading)", background: "var(--surface-2,#EAF1F2)", borderRadius: 7, padding: "1px 9px", minWidth: 26, textAlign: "center" },
  cellFull: { background: "rgba(178,58,44,.18)", color: "#E2725B" },
  cellInst: { fontSize: 12, color: "var(--muted,#5B7A88)", marginTop: 5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  cellBar: { height: 5, background: "var(--surface-2,#EAF1F2)", borderRadius: 20, overflow: "hidden", marginTop: 8 },
  cellBarFill: { height: "100%", borderRadius: 20, transition: "width .4s ease" },
  card: { display: "flex", background: "var(--surface)", borderRadius: 16, overflow: "hidden", boxShadow: "0 1px 3px rgba(11,60,93,.08), 0 8px 24px rgba(11,60,93,.05)" },
  cardBar: { width: 6, flexShrink: 0 },
  cardBody: { flex: 1, padding: "14px 16px 8px", minWidth: 0 },
  cardHead: { display: "flex", alignItems: "center", justifyContent: "space-between" },
  cardTitleBtn: { display: "flex", alignItems: "center", gap: 10, background: "none", border: "none", cursor: "pointer", fontFamily: "inherit", padding: 0 },
  levelBadge: { color: "#fff", fontWeight: 800, fontSize: 13, padding: "4px 11px", borderRadius: 8, letterSpacing: 0.2 },
  cardCount: { fontSize: 13, color: "var(--muted,#5B7A88)", fontWeight: 600 },
  instRow: { display: "flex", alignItems: "center", gap: 7, flexWrap: "wrap", margin: "12px 0 4px" },
  instLabel: { fontSize: 11, textTransform: "uppercase", letterSpacing: 1, color: "var(--muted,#5B7A88)", fontWeight: 700 },
  instChip: { display: "flex", alignItems: "center", gap: 4, background: "var(--surface-2,#EAF1F2)", color: "var(--heading)", fontSize: 13, fontWeight: 600, padding: "4px 6px 4px 10px", borderRadius: 20 },
  chipX: { border: "none", background: "rgba(128,128,128,.22)", borderRadius: "50%", width: 16, height: 16, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "var(--heading)", padding: 0 },
  instAdd: { display: "flex", alignItems: "center", gap: 4, border: "1.5px dashed var(--faint,#B9CDD3)", background: "transparent", color: "var(--muted,#5B7A88)", fontSize: 12.5, fontWeight: 600, padding: "4px 10px", borderRadius: 20, cursor: "pointer", fontFamily: "inherit" },
  instAddWrap: { display: "flex" },
  instInput: { border: "1.5px solid #2DD4BF", borderRadius: 20, padding: "4px 12px", fontSize: 13, fontFamily: "inherit", width: 110, background: "var(--surface)", color: "var(--text)" },
  list: { listStyle: "none", padding: 0, margin: "8px 0 0" },
  row: { display: "flex", alignItems: "flex-start", gap: 12, padding: "11px 4px", borderTop: "1px solid var(--border-soft,#F0F0EC)" },
  rowPresent: { background: "linear-gradient(90deg, rgba(45,212,191,.07), transparent)" },
  check: { width: 26, height: 26, borderRadius: 8, border: "2px solid #C9D6DA", background: "var(--surface)", cursor: "pointer", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", marginTop: 1, transition: "all .12s" },
  rName: { fontWeight: 700, fontSize: 15.5, display: "flex", alignItems: "center", gap: 8 },
  ageTag: { fontSize: 11, fontWeight: 700, color: "var(--muted,#5B7A88)", background: "var(--surface-2,#EAF1F2)", borderRadius: 6, padding: "1px 7px" },
  rSub: { fontSize: 13, color: "var(--muted,#5B7A88)", marginTop: 1 },
  noteInput: { marginTop: 6, border: "1.5px solid #2DD4BF", borderRadius: 8, padding: "5px 9px", fontSize: 13, fontFamily: "inherit", width: "100%", maxWidth: 280, background: "var(--surface)", color: "var(--text)" },
  noteTag: { marginTop: 5, display: "inline-block", background: "rgba(200,146,58,.16)", color: "#C8923A", border: "none", fontSize: 12.5, fontWeight: 600, padding: "3px 9px", borderRadius: 7, cursor: "pointer", fontFamily: "inherit" },
  noteAdd: { marginTop: 4, border: "none", background: "transparent", color: "var(--muted,#5B7A88)", fontSize: 12.5, cursor: "pointer", fontFamily: "inherit", padding: 0, fontWeight: 600 },
  balance: { fontSize: 13, fontWeight: 700, color: "#FF6B5C", flexShrink: 0, marginTop: 2 },
  iconBtn: { border: "none", background: "transparent", color: "var(--faint,#B9CDD3)", cursor: "pointer", padding: 10, display: "flex", borderRadius: 8, flexShrink: 0 },
  empty: { textAlign: "center", padding: "56px 20px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8 },
  emptyTitle: { fontWeight: 700, fontSize: 17, margin: 0 },
  emptySub: { color: "var(--muted,#5B7A88)", fontSize: 14, margin: 0 },
  modalWrap: { position: "fixed", inset: 0, background: "rgba(10,34,51,.55)", display: "flex", alignItems: "flex-end", justifyContent: "center", padding: 0, zIndex: 50 },
  modal: { background: "var(--surface)", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 560, maxHeight: "86vh", display: "flex", flexDirection: "column", boxShadow: "0 -10px 40px rgba(0,0,0,.2)" },
  modalHead: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "18px 18px 10px" },
  modalTitle: { margin: 0, fontSize: 19, fontWeight: 800, fontFamily: "var(--display)" },
  modalFoot: { display: "flex", gap: 10, padding: 16, borderTop: "1px solid var(--border-soft,#F0F0EC)" },
  ghostBtn: { flex: "0 0 auto", border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--muted,#5B7A88)", borderRadius: 10, padding: "11px 18px", fontWeight: 700, fontSize: 14.5, cursor: "pointer", fontFamily: "inherit" },
  primaryBtn: { flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: "#2DD4BF", color: "#06283A", border: "none", borderRadius: 10, padding: "11px 18px", fontWeight: 800, fontSize: 14.5, cursor: "pointer", fontFamily: "inherit" },
  gateIcon: { width: 62, height: 62, borderRadius: "50%", background: "radial-gradient(circle at 38% 32%, #8BE9DC, #2DD4BF 62%, #1D7A8C 100%)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", boxShadow: "0 8px 22px rgba(45,212,191,.4), inset 0 -6px 12px rgba(6,40,58,.32), inset 0 2px 4px rgba(255,255,255,.5)" },
  gateKicker: { fontSize: 11, letterSpacing: 2, textTransform: "uppercase", color: "#FFD79A", fontWeight: 700, marginBottom: 8, fontFamily: "var(--display)" },
  gateInput: { width: "100%", border: "1.5px solid rgba(255,255,255,.45)", borderRadius: 13, padding: "14px 15px", fontSize: 16, fontFamily: "inherit", textAlign: "center", letterSpacing: 0.6, marginTop: 6, boxSizing: "border-box", background: "rgba(6,40,58,.34)", color: "#F4FBFB", transition: "border-color .15s, background .15s" },
  gateErr: { fontSize: 13, color: "#FFC9BC", fontWeight: 600, background: "rgba(178,58,44,.28)", border: "1px solid rgba(255,150,130,.32)", borderRadius: 9, padding: "9px 12px", marginTop: 12 },
  gateFoot: { fontSize: 12, color: "rgba(213,231,234,.62)", marginTop: 18, marginBottom: 0 },
  slotFree: { borderColor: "#D9CEFF" },
  slotFreeActive: { background: "#7C5CFF", borderColor: "#7C5CFF", color: "#fff" },
  fsRailDot: { width: 8, height: 8, borderRadius: "50%", background: "#7C5CFF", flexShrink: 0 },
  freeRowBtn: { display: "flex", alignItems: "center", gap: 8, width: "100%", marginTop: 8, padding: "10px 12px", background: "rgba(124,92,255,.14)", border: "1px solid rgba(124,92,255,.32)", borderRadius: 10, fontSize: 13.5, color: "#A99AFF", fontWeight: 600, cursor: "pointer", fontFamily: "inherit" },
  fsMain: { maxWidth: "var(--maxw)", margin: "16px auto 0", padding: "0 16px", display: "flex", flexDirection: "column", gap: 14 },
  fsHero: { background: "var(--surface)", borderRadius: 18, padding: 16, display: "flex", flexDirection: "column", gap: 14, boxShadow: "0 1px 3px rgba(11,60,93,.08), 0 12px 30px rgba(124,92,255,.10)", border: "1px solid #ECE7FB" },
  fsHeroBar: { background: "linear-gradient(135deg, #0B3C5D 0%, #6D54E0 100%)", borderRadius: 14, padding: "14px 16px", color: "#fff", display: "flex", flexDirection: "column", gap: 12 },
  fsHeroTitleRow: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 },
  fsHeroTitleWrap: { display: "flex", alignItems: "center", gap: 8 },
  fsHeroTitle: { fontSize: 16, fontWeight: 800, letterSpacing: -0.2 },
  fsPillLive: { display: "flex", alignItems: "center", gap: 6, background: "rgba(255,255,255,.18)", color: "#fff", fontWeight: 800, fontSize: 12.5, padding: "4px 10px", borderRadius: 999, whiteSpace: "nowrap" },
  fsLiveDot: { width: 8, height: 8, borderRadius: "50%", background: "#7CFFB2", flexShrink: 0 },
  fsPillDone: { display: "flex", alignItems: "center", gap: 5, background: "rgba(255,255,255,.18)", color: "#D9FBE7", fontWeight: 800, fontSize: 12.5, padding: "4px 10px", borderRadius: 999, whiteSpace: "nowrap" },
  fsPillIdle: { display: "flex", alignItems: "center", gap: 5, background: "rgba(255,255,255,.18)", color: "#fff", fontWeight: 700, fontSize: 12.5, padding: "4px 10px", borderRadius: 999, whiteSpace: "nowrap" },
  fsHeroTop: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 },
  fsHeroLeft: { display: "flex", flexDirection: "column", gap: 2, minWidth: 0 },
  fsKicker: { fontSize: 11, letterSpacing: 1.2, textTransform: "uppercase", color: "rgba(255,255,255,.75)", fontWeight: 700 },
  fsWindow: { fontSize: 17, fontWeight: 800, color: "#fff", letterSpacing: -0.2 },
  fsCountWrap: { display: "flex", flexDirection: "column", alignItems: "flex-end", flexShrink: 0 },
  fsCountNum: { fontSize: 32, fontWeight: 800, color: "#fff", lineHeight: 1, fontVariantNumeric: "tabular-nums", letterSpacing: 0.5 },
  fsCountLbl: { fontSize: 10.5, color: "rgba(255,255,255,.8)", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, marginTop: 4 },
  fsStationGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 10 },
  fsStation: { background: "var(--surface-3,#FAFCFC)", border: "1px solid var(--border-soft,#ECF1F2)", borderTop: "4px solid", borderRadius: 12, padding: "12px 14px" },
  fsStationHead: { display: "flex", alignItems: "center", gap: 7, marginBottom: 8 },
  fsStationDot: { width: 9, height: 9, borderRadius: "50%", flexShrink: 0 },
  fsStationName: { fontSize: 12, fontWeight: 800, color: "var(--muted,#5B7A88)", textTransform: "uppercase", letterSpacing: 0.4 },
  fsStationGuard: { fontSize: 22, fontWeight: 800, lineHeight: 1.1, letterSpacing: -0.3, wordBreak: "break-word" },
  fsStationNext: { display: "flex", alignItems: "center", gap: 4, fontSize: 12, color: "#5B4B9E", fontWeight: 600, marginTop: 6 },
  fsBreakRow: { display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", background: "rgba(200,146,58,.14)", border: "1px solid rgba(200,146,58,.35)", borderRadius: 10, padding: "8px 12px" },
  fsBreakLbl: { fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.6, color: "#C8923A" },
  fsBreakChip: { background: "var(--surface)", border: "1px solid rgba(200,146,58,.45)", color: "#C8923A", fontSize: 13, fontWeight: 700, padding: "3px 10px", borderRadius: 999 },
  fsWarn: { display: "flex", alignItems: "center", gap: 8, background: "rgba(210,74,57,.14)", border: "1px solid rgba(210,74,57,.32)", color: "#E2725B", fontSize: 13, fontWeight: 600, borderRadius: 10, padding: "9px 12px" },
  fsEndNote: { fontSize: 12.5, color: "var(--muted,#5B7A88)", fontWeight: 600, textAlign: "center" },
  fsControls: { display: "flex", gap: 10, flexWrap: "wrap" },
  fsStartBtn: { flex: 1, minWidth: 180, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: "#7C5CFF", color: "#fff", border: "none", borderRadius: 12, padding: "13px 16px", fontWeight: 800, fontSize: 15, cursor: "pointer", fontFamily: "inherit", boxShadow: "0 6px 16px rgba(124,92,255,.3)" },
  fsTimeBtn: { display: "flex", alignItems: "center", justifyContent: "center", gap: 6, background: "var(--surface)", color: "#5B4B9E", border: "1.5px solid #D9CEFF", borderRadius: 12, padding: "13px 16px", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" },
  fsResetBtn: { flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 7, background: "var(--surface)", color: "var(--muted,#5B7A88)", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 12, padding: "12px 16px", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" },
  fsSched: { background: "var(--surface)", borderRadius: 16, padding: "8px 10px", boxShadow: "0 1px 3px rgba(11,60,93,.06)", overflowX: "auto" },
  fsSchedHead: { display: "flex", alignItems: "center", gap: 6, padding: "8px 8px", borderBottom: "2px solid var(--surface-2,#EAF1F2)", minWidth: 380 },
  fsSchedTime: { width: 92, flexShrink: 0, fontSize: 13, fontWeight: 800, color: "var(--heading)", display: "flex", flexDirection: "column" },
  fsSchedTime2: { fontSize: 11, fontWeight: 600, color: "var(--faint,#9DB4BF)" },
  fsSchedCol: { flex: 1, fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.3, minWidth: 64 },
  fsSchedColBreak: { flex: 1, fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.3, color: "#9A6212", minWidth: 56 },
  fsSchedRow: { display: "flex", alignItems: "center", gap: 6, padding: "10px 8px", borderRadius: 10, borderBottom: "1px solid var(--border-soft,#F0F4F4)", minWidth: 380 },
  fsSchedRowNow: { background: "rgba(124,92,255,.12)", boxShadow: "inset 0 0 0 1.5px #C9B8FF" },
  fsSchedRowPast: { opacity: 0.5 },
  fsSchedCell: { flex: 1, fontSize: 14, fontWeight: 700, color: "var(--text,#0A2233)", minWidth: 64 },
  fsSchedCellBreak: { flex: 1, fontSize: 12.5, fontWeight: 600, color: "#9A6212", minWidth: 56 },
  fsCrew: { background: "var(--surface)", borderRadius: 16, padding: "14px 16px", boxShadow: "0 1px 3px rgba(11,60,93,.06)", display: "flex", flexDirection: "column", gap: 12 },
  fsCrewHead: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 },
  fsCrewTitle: { display: "flex", alignItems: "center", gap: 6, fontSize: 14.5, fontWeight: 800, color: "var(--heading)" },
  fsCrewEdit: { border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--teal-ink,#1D7A8C)", borderRadius: 9, padding: "6px 12px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  fsCrewList: { display: "flex", flexWrap: "wrap", gap: 8 },
  fsCrewEmpty: { fontSize: 13.5, color: "var(--muted,#5B7A88)", fontStyle: "italic" },
  fsCrewSub: { fontSize: 12.5, color: "var(--muted,#5B7A88)", margin: "-2px 0 2px", lineHeight: 1.45 },
  fsQuickWrap: { display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" },
  fsQuickBtn: { border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "#5B4B9E", borderRadius: 9, padding: "6px 10px", fontSize: 12.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  fsDutyItem: { display: "flex", alignItems: "center", gap: 2 },
  fsDutyChip: { display: "flex", alignItems: "center", gap: 8, background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 999, padding: "6px 12px 6px 8px", cursor: "pointer", fontFamily: "inherit", color: "var(--muted,#5B7A88)" },
  fsDutyChipOn: { background: "#7C5CFF", borderColor: "#7C5CFF", color: "#fff", boxShadow: "0 2px 8px rgba(124,92,255,.28)" },
  fsDutyNum: { width: 20, height: 20, borderRadius: "50%", background: "var(--surface)", color: "#5B4B9E", fontSize: 11.5, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  fsDutyDot: { width: 11, height: 11, borderRadius: "50%", border: "2px solid #C9D6DA", flexShrink: 0 },
  fsGuardName2: { fontSize: 14, fontWeight: 700 },
  fsNoneOnDuty: { display: "flex", alignItems: "center", gap: 8, background: "rgba(124,92,255,.14)", border: "1px solid rgba(124,92,255,.32)", color: "#A99AFF", fontSize: 13.5, fontWeight: 600, borderRadius: 10, padding: "10px 12px" },
  miniCard: { display: "flex", flexDirection: "column", gap: 10, width: "100%", background: "var(--surface)", border: "1.5px solid #E2D9FF", borderRadius: 14, padding: "13px 15px", cursor: "pointer", fontFamily: "inherit", textAlign: "left", color: "var(--text,#0A2233)", boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  miniCardLive: { background: "linear-gradient(135deg, #0B3C5D 0%, #6D54E0 100%)", border: "none", color: "#fff", boxShadow: "0 8px 24px rgba(124,92,255,.28)" },
  miniTop: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 },
  miniTitleWrap: { display: "flex", alignItems: "center", gap: 7 },
  miniTitle: { fontSize: 14.5, fontWeight: 800, letterSpacing: -0.2 },
  miniLive: { display: "flex", alignItems: "center", gap: 6, background: "rgba(255,255,255,.18)", color: "#fff", fontWeight: 800, fontSize: 12.5, padding: "4px 10px", borderRadius: 999, fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" },
  miniLiveDot: { width: 8, height: 8, borderRadius: "50%", background: "#7CFFB2", flexShrink: 0 },
  miniWhen: { fontSize: 12.5, fontWeight: 800, color: "#A99AFF", background: "rgba(124,92,255,.16)", padding: "4px 10px", borderRadius: 999, whiteSpace: "nowrap" },
  miniStations: { display: "grid", gap: 8 },
  miniStation: { display: "flex", alignItems: "center", gap: 7, background: "rgba(255,255,255,.14)", borderRadius: 9, padding: "7px 9px", minWidth: 0 },
  miniDot: { width: 8, height: 8, borderRadius: "50%", flexShrink: 0 },
  miniStName: { fontSize: 9.5, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.3, opacity: 0.82, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  miniStGuard: { fontSize: 14.5, fontWeight: 800, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  miniIdle: { fontSize: 13, color: "#5B4B9E", fontWeight: 600, lineHeight: 1.4 },
  miniFoot: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, fontSize: 12.5, fontWeight: 700, color: "rgba(255,255,255,.92)" },
  miniFootIdle: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, fontSize: 12.5, fontWeight: 700, color: "#7C5CFF" },
  miniNext: { fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,.9)", background: "rgba(255,255,255,.12)", borderRadius: 8, padding: "6px 10px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  nnCard: { display: "flex", alignItems: "stretch", gap: 8, background: "var(--surface)", borderRadius: 16, padding: "12px 14px", boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  nnCol: { flex: 1, display: "flex", flexDirection: "column", gap: 8, minWidth: 0 },
  nnHead: { display: "flex", alignItems: "center", gap: 6, fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.5, color: "var(--muted,#5B7A88)" },
  nnHeadNow: { width: 8, height: 8, borderRadius: "50%", background: "#2DD4BF", flexShrink: 0 },
  nnHeadNext: { width: 8, height: 8, borderRadius: "50%", background: "#7C5CFF", flexShrink: 0 },
  nnList: { display: "flex", flexDirection: "column", gap: 6 },
  nnChip: { display: "flex", alignItems: "center", gap: 8, background: "var(--surface-3,#FAFCFC)", border: "1px solid var(--border-soft,#ECF1F2)", borderLeft: "3px solid", borderRadius: 9, padding: "6px 10px", minWidth: 0 },
  nnGuard: { fontSize: 14, fontWeight: 800, color: "var(--text,#0A2233)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  nnStation: { fontSize: 11, fontWeight: 600, color: "var(--muted,#5B7A88)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  nnIn: { marginLeft: "auto", fontSize: 10, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "#fff", background: "#7C5CFF", borderRadius: 999, padding: "2px 7px", flexShrink: 0 },
  nnArrow: { display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, alignSelf: "center" },
  nnEmpty: { fontSize: 13, color: "var(--faint,#9DB4BF)" },
  nnEndNote: { fontSize: 13, color: "#A99AFF", fontWeight: 600, background: "rgba(124,92,255,.14)", borderRadius: 9, padding: "10px 12px" },
  fsGuardTools: { display: "flex", alignItems: "center", gap: 2, marginLeft: 2 },
  fsGuardBtn: { border: "none", background: "rgba(124,92,255,.12)", color: "#5B4B9E", borderRadius: 6, width: 22, height: 22, fontSize: 13, fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", padding: 0 },
  fsGuardX: { border: "none", background: "rgba(255,107,92,.14)", color: "#D24A39", borderRadius: 6, width: 22, height: 22, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", padding: 0 },
  fsAddRow: { display: "flex", gap: 8 },
  fsAddInput: { flex: 1, border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 10, padding: "10px 12px", fontSize: 14.5, fontFamily: "inherit", minWidth: 0, background: "var(--surface)", color: "var(--text)" },
  fsAddBtn: { display: "flex", alignItems: "center", gap: 6, background: "#0B3C5D", color: "#fff", border: "none", borderRadius: 10, padding: "10px 16px", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit", flexShrink: 0 },
  fsLockHint: { display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: "var(--muted,#5B7A88)", fontWeight: 600, background: "var(--surface-3,#F7FAFA)", border: "1px solid var(--border-soft,#E3EBEC)", borderRadius: 10, padding: "10px 12px" },
  fsModeRow: { display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" },
  fsModeLbl: { fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.6, color: "var(--muted,#5B7A88)" },
  fsModeBtn: { border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--muted,#5B7A88)", borderRadius: 9, padding: "7px 12px", fontSize: 12.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  fsModeBtnOn: { background: "#0B3C5D", borderColor: "#0B3C5D", color: "#fff" },
  fsCellSelect: { width: "100%", maxWidth: 130, border: "1px solid var(--border,#DCE6E8)", borderRadius: 7, padding: "5px 6px", fontSize: 13, fontFamily: "inherit", fontWeight: 700, background: "var(--surface)", color: "var(--text,#0A2233)", cursor: "pointer" },
  fsManualBar: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, padding: "4px 8px 8px", flexWrap: "wrap" },
  fsManualHint: { fontSize: 12, fontWeight: 600, color: "var(--muted,#5B7A88)" },
  fsExplain: { background: "var(--surface)", borderRadius: 14, padding: "4px 16px", boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  fsExplainSum: { cursor: "pointer", fontSize: 14, fontWeight: 800, color: "var(--heading)", padding: "12px 0", listStyle: "none" },
  fsExplainBody: { paddingBottom: 12 },
  fsExplainP: { fontSize: 13.5, color: "var(--muted,#5B7A88)", lineHeight: 1.55, margin: "0 0 8px" },
  dashWrap: { maxWidth: "var(--maxw)", margin: "18px auto 0", padding: "0 16px", display: "flex", flexDirection: "column", gap: 16 },
  dashHead: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12, flexWrap: "wrap" },
  dashTitle: { fontSize: 21, fontWeight: 800, color: "var(--heading)", margin: "2px 0 0", letterSpacing: -0.3, fontFamily: "var(--display)" },
  dashHeadBtns: { display: "flex", gap: 8, flexWrap: "wrap" },
  dashHeadBtn: { display: "flex", alignItems: "center", gap: 5, background: "var(--surface)", border: "1px solid var(--border,#DCE6E8)", color: "var(--heading)", fontSize: 13, fontWeight: 700, padding: "8px 12px", borderRadius: 10, cursor: "pointer", fontFamily: "inherit" },
  dashClosed: { background: "rgba(200,146,58,.14)", border: "1px solid rgba(200,146,58,.35)", color: "#C8923A", fontSize: 13.5, fontWeight: 600, padding: "10px 14px", borderRadius: 12 },
  dashCard: { background: "var(--surface)", borderRadius: 16, padding: 14, border: "1px solid var(--border-soft,#E6EEF0)", boxShadow: "0 1px 3px rgba(11,60,93,.06)", display: "flex", flexDirection: "column", gap: 10 },
  dashCardHead: { display: "flex", alignItems: "center", gap: 7, fontSize: 14.5, fontWeight: 800, color: "var(--heading)" },
  dashEmpty: { fontSize: 13.5, color: "var(--muted,#5B7A88)", padding: "4px 2px" },
  dashReqRow: { display: "flex", flexDirection: "column", gap: 2, width: "100%", textAlign: "left", background: "var(--surface-2,#F6FAFB)", border: "1px solid var(--border-soft,#E6EEF0)", borderRadius: 10, padding: "10px 12px", cursor: "pointer", fontFamily: "inherit" },
  dashReqWho: { fontSize: 13.5, fontWeight: 800, color: "var(--heading)" },
  dashReqWhat: { fontSize: 13, color: "var(--muted,#5B7A88)", lineHeight: 1.4 },
  dashMoreBtn: { background: "none", border: "none", color: "#0E9F8E", fontSize: 13, fontWeight: 700, padding: "4px 2px", textAlign: "left", cursor: "pointer", fontFamily: "inherit" },
  dashGapGrid: { display: "flex", flexWrap: "wrap", gap: 8 },
  dashGapChip: { display: "flex", alignItems: "center", gap: 7, background: "rgba(200,146,58,.14)", border: "1px solid rgba(200,146,58,.35)", borderRadius: 999, padding: "7px 12px", fontSize: 13, fontWeight: 700, color: "#C8923A", cursor: "pointer", fontFamily: "inherit" },
  dashGapDot: { width: 8, height: 8, borderRadius: "50%", flexShrink: 0 },
  dashGapKids: { fontSize: 11.5, fontWeight: 700, color: "#C8923A", background: "rgba(200,146,58,.2)", borderRadius: 999, padding: "1px 7px" },
  dashSlot: { display: "flex", gap: 10, alignItems: "flex-start" },
  dashSlotHead: { fontSize: 13, fontWeight: 800, color: "var(--teal-ink,#1D7A8C)", minWidth: 44, paddingTop: 9, flexShrink: 0 },
  dashSlotClasses: { display: "flex", flexWrap: "wrap", gap: 8, flex: 1 },
  dashClass: { display: "flex", flexDirection: "column", gap: 3, minWidth: 130, flex: "1 1 130px", textAlign: "left", background: "var(--surface-3,#FAFCFC)", border: "1px solid var(--border-soft,#E6EEF0)", borderLeft: "3px solid #1D7A8C", borderRadius: 12, padding: "10px 12px", cursor: "pointer", fontFamily: "inherit" },
  dashClassTop: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 6 },
  dashClassLevel: { fontSize: 13, fontWeight: 800 },
  dashClassKids: { fontSize: 11.5, fontWeight: 700, color: "var(--muted,#5B7A88)", background: "var(--surface)", borderRadius: 999, padding: "1px 7px", fontVariantNumeric: "tabular-nums" },
  dashClassInstr: { fontSize: 12.5, color: "var(--text,#0A2233)", lineHeight: 1.35 },
  dashTagWrap: { display: "flex", flexWrap: "wrap", gap: 6 },
  dashTag: { fontSize: 12.5, fontWeight: 700, color: "#A99AFF", background: "rgba(124,92,255,.14)", border: "1px solid rgba(124,92,255,.3)", borderRadius: 999, padding: "4px 11px" },
  dashInstrRow: { display: "flex", flexDirection: "column", gap: 7, paddingBottom: 10, borderBottom: "1px solid var(--border-soft,#EEF3F5)" },
  dashInstrTop: { display: "flex", alignItems: "center", gap: 9 },
  dashAvatar: { width: 30, height: 30, borderRadius: "50%", background: "linear-gradient(135deg, #0B3C5D 0%, #6D54E0 100%)", color: "#fff", fontSize: 13.5, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  dashInstrName: { fontSize: 14, fontWeight: 700, color: "var(--heading)", flex: 1, minWidth: 0 },
  dashInstrCount: { fontSize: 12, fontWeight: 700, color: "var(--muted,#5B7A88)", background: "var(--surface-2,#F6FAFB)", borderRadius: 999, padding: "2px 9px", flexShrink: 0 },
  dashInstrChips: { display: "flex", flexWrap: "wrap", gap: 6, paddingLeft: 39 },
  dashInstrChip: { display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 700, color: "var(--heading)", background: "var(--surface)", border: "1.5px solid #1D7A8C", borderRadius: 999, padding: "3px 10px", cursor: "pointer", fontFamily: "inherit" },
  dashNow: { background: "linear-gradient(135deg, #0E9F8E 0%, #1D7A8C 100%)", borderRadius: 16, padding: 14, display: "flex", flexDirection: "column", gap: 10, boxShadow: "0 6px 20px rgba(14,159,142,.22)" },
  dashNowTop: { display: "flex", alignItems: "center", gap: 8 },
  dashNowDot: { width: 9, height: 9, borderRadius: "50%", background: "#7CFFB2", flexShrink: 0, boxShadow: "0 0 0 4px rgba(124,255,178,.25)" },
  dashNowLbl: { fontSize: 14.5, fontWeight: 800, color: "#fff", flex: 1, minWidth: 0 },
  dashNowCount: { fontSize: 13, fontWeight: 800, color: "#fff", background: "rgba(255,255,255,.18)", borderRadius: 999, padding: "3px 11px", whiteSpace: "nowrap", fontVariantNumeric: "tabular-nums" },
  dashSlotLive: { background: "rgba(14,159,142,.12)", borderRadius: 10, padding: "4px 6px", margin: "0 -6px" },
  dashNowMini: { fontSize: 10, fontWeight: 800, color: "#19B6A0", background: "rgba(14,159,142,.2)", borderRadius: 999, padding: "1px 6px", marginLeft: 5, textTransform: "uppercase", letterSpacing: 0.5 },
  // --- Live "right now" (Part 5 group 1) ---
  dashNowSub: { fontSize: 11, fontWeight: 800, letterSpacing: 0.6, textTransform: "uppercase", color: "rgba(255,255,255,.78)", marginTop: 2 },
  dashNowGuards: { display: "flex", flexWrap: "wrap", gap: 8 },
  dashGuardChip: { display: "flex", alignItems: "center", gap: 7, background: "rgba(255,255,255,.16)", border: "1px solid rgba(255,255,255,.22)", color: "#fff", borderRadius: 12, padding: "7px 11px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", minWidth: 0 },
  dashGuardDot: { width: 9, height: 9, borderRadius: "50%", flexShrink: 0, boxShadow: "0 0 0 2px rgba(255,255,255,.25)" },
  dashGuardStation: { fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,.75)", marginLeft: 2, whiteSpace: "nowrap" },
  dashNowIdle: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, width: "100%", background: "rgba(255,255,255,.14)", border: "1px solid rgba(255,255,255,.22)", color: "#fff", borderRadius: 12, padding: "10px 13px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", textAlign: "left" },
  // --- Coverage alerts (Part 5 group 2) ---
  dashAllClear: { display: "flex", alignItems: "center", gap: 6, fontSize: 13.5, fontWeight: 700, color: "#0E9F8E", background: "rgba(14,159,142,.12)", border: "1px solid rgba(14,159,142,.28)", borderRadius: 10, padding: "9px 12px" },
  // --- Attendance at a glance (Part 5 group 4) ---
  dashAttnTop: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14, flexWrap: "wrap" },
  dashAttnBig: { display: "flex", flexDirection: "column", gap: 1, minWidth: 0 },
  dashAttnNum: { fontSize: 26, fontWeight: 800, color: "var(--heading)", letterSpacing: -0.6, fontVariantNumeric: "tabular-nums", lineHeight: 1 },
  dashAttnLbl: { fontSize: 12, fontWeight: 600, color: "var(--muted,#5B7A88)" },
  dashAttnPctWrap: { display: "flex", alignItems: "center", gap: 9, flex: "1 1 140px", minWidth: 120 },
  dashAttnBarTrack: { flex: 1, height: 9, borderRadius: 999, background: "var(--surface-2,#EAF1F2)", overflow: "hidden" },
  dashAttnBarFill: { height: "100%", borderRadius: 999, background: "linear-gradient(90deg, #0E9F8E, #2DD4BF)", transition: "width .3s ease" },
  dashAttnPct: { fontSize: 14, fontWeight: 800, color: "var(--heading)", fontVariantNumeric: "tabular-nums", minWidth: 38, textAlign: "right" },
  dashAttnList: { display: "flex", flexDirection: "column", gap: 7, marginTop: 4 },
  dashAttnRow: { display: "flex", alignItems: "center", gap: 9, width: "100%", background: "transparent", border: "none", padding: "2px 0", cursor: "pointer", fontFamily: "inherit", textAlign: "left" },
  dashAttnDot: { width: 8, height: 8, borderRadius: "50%", flexShrink: 0 },
  dashAttnRowLbl: { fontSize: 12.5, fontWeight: 700, color: "var(--text,#0A2233)", flex: "0 0 118px", minWidth: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  dashAttnRowTrack: { flex: 1, height: 7, borderRadius: 999, background: "var(--surface-2,#EAF1F2)", overflow: "hidden", minWidth: 40 },
  dashAttnRowFill: { display: "block", height: "100%", borderRadius: 999, transition: "width .3s ease" },
  dashAttnRowNum: { fontSize: 12, fontWeight: 700, color: "var(--muted,#5B7A88)", fontVariantNumeric: "tabular-nums", minWidth: 34, textAlign: "right", flexShrink: 0 },
  // --- Per-person view (Part 5 group 3) ---
  dashPersonRow: { display: "flex", flexDirection: "column", gap: 8, paddingBottom: 11, borderBottom: "1px solid var(--border-soft,#EEF3F5)" },
  dashPersonTop: { display: "flex", alignItems: "center", gap: 10 },
  dashPersonName: { fontSize: 14.5, fontWeight: 800, color: "var(--heading)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  dashPersonMeta: { display: "flex", alignItems: "center", flexWrap: "wrap", gap: 6, marginTop: 3, flexWrap: "wrap" },
  dashPresentPill: { fontSize: 10.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, borderRadius: 999, padding: "2px 8px" },
  dashPresentYes: { color: "#0E9F8E", background: "rgba(14,159,142,.16)" },
  dashPresentNo: { color: "#E2725B", background: "rgba(226,114,91,.18)" },
  dashPresentClosed: { color: "var(--muted,#5B7A88)", background: "var(--surface-2,#EAF1F2)" },
  dashPersonChips: { display: "flex", flexWrap: "wrap", gap: 6, paddingLeft: 40 },
  dashPersonIdle: { fontSize: 12, color: "var(--faint,#9DB4BF)", fontWeight: 600, paddingLeft: 40 },
  sbWrap: { maxWidth: "var(--maxw)", margin: "14px auto 0", padding: "0 16px", display: "flex", flexDirection: "column", gap: 12 },
  sbHead: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 },
  sbTitle: { fontSize: 21, fontWeight: 800, color: "var(--heading)", margin: "2px 0 0", letterSpacing: -0.3, fontFamily: "var(--display)" },
  sbHelp: { fontSize: 13.5, color: "var(--muted,#5B7A88)", lineHeight: 1.5, margin: "0 2px", background: "var(--surface-2,#F6FAFB)", border: "1px solid var(--border-soft,#E6EEF0)", borderRadius: 12, padding: "11px 14px" },
  sbSlot: { display: "flex", gap: 10, alignItems: "flex-start" },
  sbSlotHead: { fontSize: 13, fontWeight: 800, color: "var(--teal-ink,#1D7A8C)", minWidth: 44, paddingTop: 11, flexShrink: 0 },
  sbClasses: { display: "flex", flexWrap: "wrap", gap: 8, flex: 1 },
  sbClass: { display: "flex", flexDirection: "column", gap: 4, minWidth: 150, flex: "1 1 150px", textAlign: "left", background: "var(--surface)", border: "1px solid var(--border-soft,#E6EEF0)", borderLeft: "3px solid #1D7A8C", borderRadius: 12, padding: "11px 13px", cursor: "pointer", fontFamily: "inherit", boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  sbClassMine: { background: "var(--surface-2,#F1F8FA)", borderStyle: "dashed" },
  sbClassPend: { opacity: 0.65 },
  sbClassTop: { display: "flex", alignItems: "center", gap: 7 },
  sbClassLevel: { fontSize: 13.5, fontWeight: 800, flex: 1, minWidth: 0 },
  sbMineTag: { fontSize: 10.5, fontWeight: 800, color: "#19B6A0", background: "rgba(29,122,140,.2)", borderRadius: 999, padding: "1px 8px", textTransform: "uppercase", letterSpacing: 0.5 },
  sbPendTag: { fontSize: 10.5, fontWeight: 800, color: "#C8923A", background: "rgba(200,146,58,.2)", borderRadius: 999, padding: "1px 8px" },
  sbClassInstr: { fontSize: 13, color: "var(--text,#0A2233)", fontWeight: 600, lineHeight: 1.35 },
  sbClassKids: { fontSize: 12, color: "var(--muted,#5B7A88)" },
  sbTradeHint: { display: "flex", alignItems: "center", gap: 4, fontSize: 11.5, fontWeight: 700, color: "#0E9F8E", marginTop: 2 },
  tradePick: { display: "flex", flexDirection: "column", gap: 8, marginTop: 4 },
  tradeOpt: { display: "flex", alignItems: "center", gap: 9, width: "100%", textAlign: "left", background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 12, padding: "12px 14px", fontSize: 14, fontWeight: 700, color: "var(--heading)", cursor: "pointer", fontFamily: "inherit" },
  tradeOptSel: { background: "var(--surface-2,#F1F8FA)", borderWidth: 2 },
  tradeOptDot: { width: 10, height: 10, borderRadius: "50%", flexShrink: 0 },
  tradePreview: { display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginTop: 14, padding: "12px", background: "var(--surface-2,#F6FAFB)", borderRadius: 12 },
  tradePrevChip: { fontSize: 13, fontWeight: 800, color: "var(--heading)", background: "var(--surface)", border: "1px solid var(--border,#DCE6E8)", borderRadius: 999, padding: "5px 12px", textAlign: "center" },
  // ---- Today: staff coverage & daily attendance ----
  stHeadRow: { display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 12, flexWrap: "wrap" },
  stTitle: { margin: "2px 0 0", fontSize: 19, fontWeight: 800, color: "var(--heading)", fontFamily: "var(--display)" },
  stCount: { fontSize: 13, fontWeight: 800, color: "var(--muted,#5B7A88)", background: "var(--surface-2,#EAF1F2)", borderRadius: 999, padding: "4px 12px" },
  stGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 8, marginTop: 4 },
  stCard: { display: "flex", flexDirection: "column", gap: 7, background: "var(--surface)", border: "1px solid var(--border-soft,#ECF1F2)", borderRadius: 13, padding: "10px 11px", boxShadow: "0 1px 3px rgba(11,60,93,.06)", minWidth: 0 },
  stCardAbsent: { borderColor: "#FFD9D0", background: "rgba(255,107,92,.06)" },
  stCardTop: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 6, flexWrap: "wrap" },
  stName: { fontSize: 15, fontWeight: 800, color: "var(--heading)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  stRoleBadge: { fontSize: 9.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.3, borderRadius: 999, padding: "2px 7px", flexShrink: 0 },
  selfCheckTag: { fontSize: 9.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.3, borderRadius: 999, padding: "2px 7px", flexShrink: 0, color: "#0E7C6B", background: "rgba(45,212,191,.16)", whiteSpace: "nowrap" },
  stRoleInstr: { color: "var(--heading)", background: "rgba(29,122,140,.16)" },
  stRoleGuard: { color: "#19B6A0", background: "rgba(14,159,142,.16)" },
  stRoleBoth: { color: "#A99AFF", background: "rgba(124,92,255,.18)" },
  stToggle: { display: "flex", alignItems: "center", justifyContent: "center", gap: 5, border: "none", borderRadius: 9, padding: "7px 10px", fontWeight: 800, fontSize: 12.5, cursor: "pointer", fontFamily: "inherit" },
  stTogglePresent: { background: "#0E9F8E", color: "#fff" },
  stToggleAbsent: { background: "var(--surface)", color: "#D24A39", border: "1.5px solid #FFD9D0" },
  stToggleDisabled: { cursor: "default", opacity: 0.7 },
  stCoverGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 12, marginTop: 4 },
  stCoverCol: { display: "flex", flexDirection: "column", gap: 8, background: "var(--surface)", border: "1px solid var(--border-soft,#ECF1F2)", borderRadius: 14, padding: "12px 13px", boxShadow: "0 1px 3px rgba(11,60,93,.06)" },
  stColHead: { display: "flex", alignItems: "center", gap: 6, fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.6, color: "var(--muted,#5B7A88)", marginBottom: 2 },
  stCoverRow: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, flexWrap: "wrap", padding: "7px 0", borderTop: "1px solid var(--border-soft,#ECF1F2)" },
  stCoverMeta: { display: "flex", flexDirection: "column", gap: 1, minWidth: 0 },
  stCoverWhen: { fontSize: 13.5, fontWeight: 700, color: "var(--text,#0A2233)" },
  stCoverWho: { display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" },
  stWhoChip: { display: "inline-flex", alignItems: "center", gap: 6, fontSize: 13, fontWeight: 700, color: "var(--heading)", background: "var(--surface-2,#EAF1F2)", borderRadius: 999, padding: "3px 10px" },
  stWhoChipAbsent: { color: "#D24A39", background: "rgba(255,107,92,.12)", border: "1px solid #FFD9D0" },
  stReplaceBtn: { border: "none", background: "#FF6B5C", color: "#fff", borderRadius: 999, padding: "2px 9px", fontSize: 11, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" },
  stAbsentTag: { fontSize: 10.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "#D24A39" },
  stRoleSeg: { display: "flex", gap: 4 },
  stRoleSegBtn: { flex: 1, border: "1.5px solid var(--border,#DCE6E8)", background: "var(--surface)", color: "var(--muted,#5B7A88)", borderRadius: 8, padding: "6px 4px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  stRoleSegBtnOn: { background: "#0B3C5D", borderColor: "#0B3C5D", color: "#fff" },
  stPickRow: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, width: "100%", textAlign: "left", background: "var(--surface)", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 12, padding: "11px 13px", marginBottom: 6, cursor: "pointer", fontFamily: "inherit" },
  scanError: { fontSize: 13, color: "#B23A2C", fontWeight: 600, background: "rgba(178,58,44,.10)", border: "1px solid rgba(178,58,44,.22)", borderRadius: 9, padding: "9px 12px", marginTop: 6 },
  scanWarn: { fontSize: 13, color: "var(--heading)", background: "rgba(232,160,44,.12)", border: "1px solid rgba(232,160,44,.32)", borderRadius: 9, padding: "9px 12px", marginTop: 2 },
  scanSelect: { width: "100%", border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 10, padding: "10px 12px", fontSize: 14, fontFamily: "inherit", background: "var(--surface)", color: "var(--heading)", boxSizing: "border-box", marginBottom: 4 },
  scanGroup: { border: "1px solid var(--border-soft,#ECF1F2)", borderRadius: 12, padding: "10px 12px", marginTop: 8, background: "var(--surface-3,#FAFCFC)" },
  scanGroupHead: { fontSize: 12.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "var(--muted,#5B7A88)", marginBottom: 8 },
  scanRow: { display: "flex", flexDirection: "column", gap: 6, padding: "8px 0", borderTop: "1px solid var(--border-soft,#ECF1F2)" },
  scanRowSub: { display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" },
  scanInput: { flex: 1, minWidth: 90, border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 9, padding: "8px 10px", fontSize: 14, fontFamily: "inherit", background: "var(--surface)", color: "var(--heading)", boxSizing: "border-box" },
  scanSelectSm: { border: "1.5px solid var(--border,#DCE6E8)", borderRadius: 9, padding: "8px 8px", fontSize: 13, fontFamily: "inherit", background: "var(--surface)", color: "var(--heading)" },
  scanRemove: { border: "none", background: "rgba(255,107,92,.12)", color: "#D24A39", borderRadius: 9, padding: "8px 9px", cursor: "pointer", display: "flex", alignItems: "center", flexShrink: 0 }
};

// src/main.jsx
import { jsx as jsx2 } from "react/jsx-runtime";
var APP_BUILD = "sync-39";
try { console.info("AG Lifeguard \u00B7 build " + APP_BUILD); } catch {}
// App-shell service worker: makes reopening the app instant (shell serves from
// cache) and offline-capable, and surfaces a one-tap update when a new build
// is deployed. Feature-detected so nothing here can ever block the app.
if (typeof navigator !== "undefined" && "serviceWorker" in navigator) {
  try {
    window.addEventListener("load", () => { navigator.serviceWorker.register("/sw.js").catch(() => {}); });
    navigator.serviceWorker.addEventListener("message", (e) => {
      if (e && e.data && e.data.type === "ag-update-ready") {
        try { window.dispatchEvent(new CustomEvent("ag-update-ready")); } catch {}
      }
    });
  } catch {}
}
var IS_KIOSK = typeof location !== "undefined" && /[?&]kiosk\b/.test(location.search);
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsx2(IS_KIOSK ? KioskApp : App, {}));
