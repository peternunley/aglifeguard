// AG Lifeguard app-shell service worker (v: ag-shell-39).
// Goal: reopening the app is INSTANT — the shell (html/js) serves from cache,
// so iOS killing the page in the background no longer means a full re-download.
// Designed to be un-pinnable (the old cache once pinned devices to a stale
// build): navigations are NETWORK-FIRST with a short timeout, so any device
// that is online always gets the latest index.html; the cache is only the
// fallback for offline/slow starts. Static assets are cache-first with a
// background refresh, and when a new app.js lands, open tabs are notified so
// the app can offer a one-tap update.
const CACHE = "ag-shell-39";
const SHELL = [
  "/", "/index.html", "/app.js", "/manifest.json", "/favicon.svg",
  "/vendor/react.js", "/vendor/react-dom-client.js", "/vendor/jsx-runtime.js",
  "/vendor/lucide-react.js", "/vendor/supabase-js.js",
  // node-buffer is a static import of supabase-js — omitting it made offline
  // reopen white-screen when it wasn't in the runtime cache.
  "/vendor/node-buffer.js",
  // Self-hosted fonts: cached shell must render with the real typefaces offline.
  "/fonts.css",
  "/fonts/bricolage-grotesque-latin.woff2", "/fonts/bricolage-grotesque-latin-ext.woff2",
  "/fonts/hanken-grotesk-latin.woff2", "/fonts/hanken-grotesk-latin-ext.woff2",
  "/icon-192.png", "/icon-512.png", "/icon-180.png", "/apple-touch-icon.png"
];
self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    // Add files individually so one miss can't brick the whole install.
    await Promise.all(SHELL.map((u) => cache.add(u).catch(() => {})));
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});
async function notifyUpdate() {
  try {
    const clients = await self.clients.matchAll({ type: "window" });
    for (const c of clients) c.postMessage({ type: "ag-update-ready" });
  } catch (e) {}
}
function networkFirst(request, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(async () => {
      if (settled) return;
      const cached = await caches.match("/index.html");
      if (cached) { settled = true; resolve(cached); }
    }, timeoutMs);
    fetch(request).then(async (res) => {
      clearTimeout(timer);
      if (res && res.ok) {
        try { const c = await caches.open(CACHE); c.put("/index.html", res.clone()); } catch (e) {}
      } else if (!settled) {
        // A 5xx from the CDN is not the app — prefer the cached shell over an
        // error page; fall through to the error only when there's no cache.
        const cached = await caches.match("/index.html");
        if (cached) { settled = true; resolve(cached); return; }
      }
      if (!settled) { settled = true; resolve(res); }
    }).catch(async () => {
      clearTimeout(timer);
      if (settled) return;
      const cached = await caches.match("/index.html");
      settled = true;
      resolve(cached || Response.error());
    });
  });
}
self.addEventListener("push", (event) => {
  // Show whatever the server sent; a malformed payload still shows SOMETHING
  // rather than being silently dropped.
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (e) { data = { title: "AG Lifeguard", body: event.data ? event.data.text() : "" }; }
  const title = data.title || "AG Lifeguard";
  const opts = { body: data.body || "", icon: "/icon-192.png", badge: "/icon-192.png", data: { url: data.url || "/" } };
  event.waitUntil(self.registration.showNotification(title, opts));
});
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil((async () => {
    const clients = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const c of clients) { if ("focus" in c) return c.focus(); }
    return self.clients.openWindow(event.notification.data && event.notification.data.url || "/");
  })());
});
self.addEventListener("message", (event) => {
  // Page asked us to pre-download the new build so the update tap is instant.
  if (!event.data || event.data.type !== "ag-refresh-shell") return;
  // waitUntil keeps the browser from killing the SW mid-download (iOS is
  // aggressive about this); announce ONLY a complete, consistent pre-download —
  // a half-fetched update made the banner reload into the same old build.
  event.waitUntil((async () => {
    try {
      const cache = await caches.open(CACHE);
      const [app, idx] = await Promise.all([
        fetch("/app.js", { cache: "no-store" }),
        fetch("/index.html", { cache: "no-store" })
      ]);
      if (app && app.ok) await cache.put("/app.js", app.clone());
      if (idx && idx.ok) await cache.put("/index.html", idx.clone());
      if (app && app.ok && idx && idx.ok) notifyUpdate();
    } catch (e) {}
  })());
});
self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // Supabase etc: untouched
  if (url.pathname === "/version.txt") return;      // version probe is always live
  if (req.mode === "navigate") {
    event.respondWith(networkFirst(req, 2500));
    return;
  }
  // Static assets: serve cached instantly, refresh in the background, and
  // announce when a NEW app.js has been fetched so tabs can offer an update.
  event.respondWith((async () => {
    const cached = await caches.match(req);
    const refresh = fetch(req).then(async (res) => {
      if (res && res.ok) {
        try {
          const cache = await caches.open(CACHE);
          if (cached && url.pathname === "/app.js") {
            const a = cached.headers.get("etag") || cached.headers.get("last-modified") || "";
            const b = res.headers.get("etag") || res.headers.get("last-modified") || "";
            if (a && b && a !== b) notifyUpdate();
          }
          await cache.put(req, res.clone());
        } catch (e) {}
      }
      return res;
    }).catch(() => null);
    if (cached) { event.waitUntil(refresh); return cached; }
    const fresh = await refresh;
    return fresh || Response.error();
  })());
});
